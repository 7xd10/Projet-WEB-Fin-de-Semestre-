<?php
require_once 'config.php';
verifierConnexion();

$user_id = $_SESSION['user_id'];
$role = $_SESSION['user_role'];

$succes = '';
$erreur = '';

if (isset($_GET['action']) && $_GET['action'] === 'supprimer' && isset($_GET['id'])) {
    $demande_id = (int)$_GET['id'];
    
    $stmt = $pdo->prepare("SELECT * FROM demandes WHERE id = ? AND professeur_id = ?");
    $stmt->execute([$demande_id, $user_id]);
    $demande = $stmt->fetch();
    
    if (!$demande) {
        $erreur = "Demande introuvable.";
    } elseif ($demande['statut_assistante'] !== 'En attente') {
        $erreur = "Impossible de supprimer une demande déjà traitée.";
    } else {
        $stmt = $pdo->prepare("DELETE FROM demandes WHERE id = ?");
        if ($stmt->execute([$demande_id])) {
            logActivity($user_id, 'SUPPRESSION_DEMANDE', 'demandes', $demande_id);
            $succes = "La demande a été supprimée avec succès.";
        } else {
            $erreur = "Erreur lors de la suppression.";
        }
    }
}

if ($role === 'Professeur') {
    $stmt = $pdo->prepare("SELECT * FROM demandes WHERE professeur_id = ? ORDER BY date_creation DESC");
    $stmt->execute([$user_id]);
} elseif ($role === 'Assistante') {
    $stmt = $pdo->query("
        SELECT d.*, u.nom, u.prenom 
        FROM demandes d 
        JOIN utilisateurs u ON d.professeur_id = u.id 
        ORDER BY d.date_creation DESC
    ");
} else {
    $stmt = $pdo->query("
        SELECT d.*, u.nom, u.prenom 
        FROM demandes d 
        JOIN utilisateurs u ON d.professeur_id = u.id 
        WHERE d.statut_assistante = 'Validé'
        ORDER BY d.date_validation_assistante DESC
    ");
}
$demandes = $stmt->fetchAll();

$page_title = 'Mes demandes';
include 'includes/header.php';
?>

    <div class="container" style="margin-top: 40px;">
        <div class="page-header">
            <h1>
                <?php 
                if ($role === 'Professeur') echo 'Mes demandes';
                elseif ($role === 'Assistante') echo 'Toutes les demandes';
                else echo 'Demandes à valider';
                ?>
            </h1>
        </div>

        <?php if ($succes): ?>
            <div class="alert alert-success">
                <strong>Succès!</strong> <?php echo securiser($succes); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($erreur): ?>
            <div class="alert alert-error">
                <strong>Erreur!</strong> <?php echo securiser($erreur); ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <?php if (count($demandes) > 0): ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <?php if ($role !== 'Professeur'): ?>
                                    <th>Professeur</th>
                                <?php endif; ?>
                                <th>Type</th>
                                <th>Ancienne séance</th>
                                <th>Nouvelle séance</th>
                                <th>Statut</th>
                                <th>Date création</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($demandes as $d): ?>
                                <tr>
                                    <td>#<?php echo $d['id']; ?></td>
                                    <?php if ($role !== 'Professeur'): ?>
                                        <td><?php echo securiser($d['prenom'] . ' ' . $d['nom']); ?></td>
                                    <?php endif; ?>
                                    <td>
                                        <?php 
                                        if ($d['type_demande'] === 'modification') {
                                            echo '<span class="badge badge-info">Modification</span>';
                                        } else {
                                            echo '<span class="badge badge-warning">Annulation</span>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <strong><?php echo date('d/m/Y', strtotime($d['date_seance_originale'])); ?></strong><br>
                                        <?php echo date('H:i', strtotime($d['heure_debut_originale'])) . ' - ' . date('H:i', strtotime($d['heure_fin_originale'])); ?><br>
                                        <small>Salle: <?php echo securiser($d['salle_originale']); ?></small>
                                    </td>
                                    <td>
                                        <?php if ($d['type_demande'] === 'modification'): ?>
                                            <strong><?php echo date('d/m/Y', strtotime($d['date_seance_nouvelle'])); ?></strong><br>
                                            <?php echo date('H:i', strtotime($d['heure_debut_nouvelle'])) . ' - ' . date('H:i', strtotime($d['heure_fin_nouvelle'])); ?><br>
                                            <small>Salle: <?php echo securiser($d['salle_nouvelle']); ?></small>
                                        <?php else: ?>
                                            <span style="color: #dc3545; font-weight: bold;">Annulée</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                        if ($d['statut_directeur'] === 'Validé') {
                                            echo '<span class="badge badge-success">Validé</span>';
                                        } elseif ($d['statut_assistante'] === 'Refusé' || $d['statut_directeur'] === 'Refusé') {
                                            echo '<span class="badge badge-danger">Refusé</span>';
                                        } elseif ($d['statut_assistante'] === 'Validé') {
                                            echo '<span class="badge badge-info">Validé (Assistante)</span>';
                                        } else {
                                            echo '<span class="badge badge-warning">En attente</span>';
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo date('d/m/Y H:i', strtotime($d['date_creation'])); ?></td>
                                    <td style="display: flex; gap: 8px; flex-wrap: wrap;">
                                        <a href="<?php echo BASE_URL; ?>/detail_demande.php?id=<?php echo $d['id']; ?>" class="btn btn-sm btn-primary">Détails</a>
                                        
                                        <?php if ($role === 'Professeur' && $d['statut_assistante'] === 'En attente'): ?>
                                            <a href="<?php echo BASE_URL; ?>/demandes.php?action=supprimer&id=<?php echo $d['id']; ?>" 
                                               class="btn btn-sm btn-danger" 
                                               onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette demande ? Cette action est irréversible.')">
                                                Supprimer
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="text-center">Aucune demande à afficher</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php include 'includes/footer.php'; ?>
