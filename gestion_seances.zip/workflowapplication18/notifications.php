<?php
require_once 'config.php';
verifierConnexion();

$user_id = $_SESSION['user_id'];

if (isset($_GET['marquer_lues'])) {
    $stmt = $pdo->prepare("UPDATE notifications SET lu = 1 WHERE utilisateur_id = ?");
    $stmt->execute([$user_id]);
    header('Location: notifications.php');
    exit;
}

$stmt = $pdo->prepare("
    SELECT n.* 
    FROM notifications n
    WHERE n.utilisateur_id = ?
    ORDER BY n.date_creation DESC
");
$stmt->execute([$user_id]);
$notifications = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications - Gestion des Séances</title>
    <!-- Updated CSS link to use assets/css/style.css -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
   <?php include 'includes/header.php'; ?>

    <div class="container">
        <div class="page-header">
            <h1>Notifications</h1>
            <?php if (count($notifications) > 0): ?>
                <a href="?marquer_lues=1" class="btn btn-secondary">Marquer toutes comme lues</a>
            <?php endif; ?>
        </div>

        <div class="card">
            <div class="card-body">
                <?php if (count($notifications) > 0): ?>
                    <div class="notifications-list">
                        <?php foreach ($notifications as $n): ?>
                            <div class="notification-item <?php echo $n['lu'] ? '' : 'unread'; ?>">
                                <div class="notification-content">
                                    <p><?php echo securiser($n['message']); ?></p>
                                    <small><?php echo date('d/m/Y à H:i', strtotime($n['date_creation'])); ?></small>
                                </div>
                                <?php if ($n['demande_id']): ?>
                                    <a href="detail_demande.php?id=<?php echo $n['demande_id']; ?>" class="btn btn-sm">Voir</a>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="text-center">Aucune notification</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
