-- Base de données complète de gestion des demandes de changement de séances universitaires
-- Version mise à jour avec toutes les fonctionnalités et sécurités

CREATE DATABASE IF NOT EXISTS gestion_seances CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gestion_seances;

-- ============================================================
-- TABLE DES UTILISATEURS
-- ============================================================
-- Ajout du champ matricule pour la récupération de mot de passe
CREATE TABLE utilisateurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    matricule VARCHAR(20) UNIQUE NOT NULL,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    mot_de_passe VARCHAR(255) NOT NULL,
    role ENUM('Professeur', 'Assistante', 'Directeur') NOT NULL,
    telephone VARCHAR(20),
    bureau VARCHAR(50),
    actif BOOLEAN DEFAULT TRUE,
    tentatives_connexion INT DEFAULT 0,
    date_blocage DATETIME,
    -- Ajout des champs pour "Se souvenir de moi"
    remember_token VARCHAR(64),
    remember_token_expiration DATETIME,
    derniere_connexion DATETIME,
    user_agent_connexion VARCHAR(255),
    ip_connexion VARCHAR(45),
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_matricule (matricule),
    INDEX idx_role (role),
    INDEX idx_remember_token (remember_token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE DES MATIÈRES
-- ============================================================
CREATE TABLE matieres (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    nom VARCHAR(150) NOT NULL,
    description TEXT,
    actif BOOLEAN DEFAULT TRUE,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE DES SALLES
-- ============================================================
CREATE TABLE salles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(50) NOT NULL UNIQUE,
    batiment VARCHAR(50),
    capacite INT DEFAULT 30,
    equipements TEXT,
    disponible BOOLEAN DEFAULT TRUE,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_nom (nom)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE DES DEMANDES
-- ============================================================
-- Ajout des champs pour pièces jointes, brouillon, annulation
DROP TABLE IF EXISTS demandes;
CREATE TABLE demandes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    professeur_id INT NOT NULL,
    type_demande ENUM('modification', 'annulation') NOT NULL,
    date_seance_originale DATE NOT NULL,
    heure_debut_originale TIME NOT NULL,
    heure_fin_originale TIME NOT NULL,
    salle_originale VARCHAR(100) NOT NULL,
    matiere VARCHAR(150) NOT NULL,
    niveau VARCHAR(50) NOT NULL,
    date_seance_nouvelle DATE NULL,
    heure_debut_nouvelle TIME NULL,
    heure_fin_nouvelle TIME NULL,
    salle_nouvelle VARCHAR(100) NULL,
    raison TEXT NOT NULL,
    piece_jointe VARCHAR(255) NULL,
    est_brouillon BOOLEAN DEFAULT FALSE,
    statut_assistante ENUM('En attente', 'Validé', 'Refusé', 'Info demandée', 'Alternative proposée') DEFAULT 'En attente',
    statut_directeur ENUM('En attente', 'Validé', 'Refusé') DEFAULT 'En attente',
    commentaire_assistante TEXT,
    commentaire_directeur TEXT,
    info_supplementaire_demandee TEXT,
    alternative_proposee TEXT,
    date_alternative DATE,
    heure_debut_alternative TIME,
    heure_fin_alternative TIME,
    salle_alternative VARCHAR(100),
    annule BOOLEAN DEFAULT FALSE,
    motif_annulation TEXT,
    date_annulation TIMESTAMP NULL,
    disponibilite_verifiee BOOLEAN DEFAULT FALSE,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_modification TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    date_validation_assistante TIMESTAMP NULL,
    date_validation_directeur TIMESTAMP NULL,
    FOREIGN KEY (professeur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
    INDEX idx_professeur (professeur_id),
    INDEX idx_statut_assistante (statut_assistante),
    INDEX idx_statut_directeur (statut_directeur),
    INDEX idx_date_creation (date_creation),
    INDEX idx_brouillon (est_brouillon)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE DE L'EMPLOI DU TEMPS (CALENDRIER DES SÉANCES)
-- ============================================================
CREATE TABLE emploi_temps (
    id INT AUTO_INCREMENT PRIMARY KEY,
    date_seance DATE NOT NULL,
    heure_debut TIME NOT NULL,
    heure_fin TIME NOT NULL,
    salle VARCHAR(100) NOT NULL,
    professeur_id INT,
    matiere VARCHAR(150),
    groupe VARCHAR(100),
    disponible BOOLEAN DEFAULT TRUE,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (professeur_id) REFERENCES utilisateurs(id) ON DELETE SET NULL,
    INDEX idx_date_salle (date_seance, salle),
    INDEX idx_date_heure (date_seance, heure_debut, heure_fin),
    INDEX idx_professeur (professeur_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE DES NOTIFICATIONS
-- ============================================================
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT NOT NULL,
    demande_id INT,
    message TEXT NOT NULL,
    lu BOOLEAN DEFAULT FALSE,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
    FOREIGN KEY (demande_id) REFERENCES demandes(id) ON DELETE CASCADE,
    INDEX idx_utilisateur_lu (utilisateur_id, lu),
    INDEX idx_date (date_creation)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE DES LOGS D'ACTIVITÉ
-- ============================================================
CREATE TABLE logs_activite (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT,
    action VARCHAR(100) NOT NULL,
    table_concernee VARCHAR(50),
    enregistrement_id INT,
    details JSON,
    adresse_ip VARCHAR(45),
    user_agent VARCHAR(255),
    date_action TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id),
    INDEX idx_logs_user (utilisateur_id),
    INDEX idx_logs_action (action),
    INDEX idx_logs_date (date_action)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE DES PARAMÈTRES SYSTÈME
-- ============================================================
CREATE TABLE parametres (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cle VARCHAR(100) UNIQUE NOT NULL,
    valeur TEXT NOT NULL,
    description VARCHAR(255),
    date_modification TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_cle (cle)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- DONNÉES INITIALES - UTILISATEURS
-- ============================================================
-- Ajout des matricules pour tous les utilisateurs
-- Mot de passe pour tous: password123
-- Hash MD5: 482c811da5d5b4bc6d497ffa98491e38

INSERT INTO utilisateurs (matricule, nom, prenom, email, mot_de_passe, role, telephone, bureau, remember_token, remember_token_expiration) VALUES
('PROF001', 'Dupont', 'Jean', 'jean.dupont@univ.fr', '482c811da5d5b4bc6d497ffa98491e38', 'Professeur', '01-23-45-67-89', 'A201', 'token1', '2026-01-01 00:00:00'),
('PROF002', 'Martin', 'Sophie', 'sophie.martin@univ.fr', '482c811da5d5b4bc6d497ffa98491e38', 'Professeur', '01-23-45-67-90', 'B105', 'token2', '2026-01-01 00:00:00'),
('PROF003', 'Bernard', 'Pierre', 'pierre.bernard@univ.fr', '482c811da5d5b4bc6d497ffa98491e38', 'Professeur', '01-23-45-67-91', 'C310', 'token3', '2026-01-01 00:00:00'),
('PROF004', 'Rousseau', 'Isabelle', 'isabelle.rousseau@univ.fr', '482c811da5d5b4bc6d497ffa98491e38', 'Professeur', '01-23-45-67-95', 'A305', 'token4', '2026-01-01 00:00:00'),
('PROF005', 'Petit', 'Luc', 'luc.petit@univ.fr', '482c811da5d5b4bc6d497ffa98491e38', 'Professeur', '01-23-45-67-96', 'B208', 'token5', '2026-01-01 00:00:00'),
('PROF006', 'Roux', 'Nathalie', 'nathalie.roux@univ.fr', '482c811da5d5b4bc6d497ffa98491e38', 'Professeur', '01-23-45-67-97', 'C405', 'token6', '2026-01-01 00:00:00'),
('PROF007', 'Vincent', 'Thomas', 'thomas.vincent@univ.fr', '482c811da5d5b4bc6d497ffa98491e38', 'Professeur', '01-23-45-67-98', 'D102', 'token7', '2026-01-01 00:00:00'),
('PROF008', 'Fournier', 'Céline', 'celine.fournier@univ.fr', '482c811da5d5b4bc6d497ffa98491e38', 'Professeur', '01-23-45-67-99', 'E203', 'token8', '2026-01-01 00:00:00'),
('PROF009', 'Girard', 'Marc', 'marc.girard@univ.fr', '482c811da5d5b4bc6d497ffa98491e38', 'Professeur', '01-23-45-68-00', 'A108', 'token9', '2026-01-01 00:00:00'),
('PROF010', 'Bonnet', 'Anne', 'anne.bonnet@univ.fr', '482c811da5d5b4bc6d497ffa98491e38', 'Professeur', '01-23-45-68-01', 'B304', 'token10', '2026-01-01 00:00:00'),
('ASST001', 'Dubois', 'Marie', 'marie.dubois@univ.fr', '482c811da5d5b4bc6d497ffa98491e38', 'Assistante', '01-23-45-67-92', 'Admin-01', 'token11', '2026-01-01 00:00:00'),
('ASST002', 'Leroy', 'Claire', 'claire.leroy@univ.fr', '482c811da5d5b4bc6d497ffa98491e38', 'Assistante', '01-23-45-67-93', 'Admin-02', 'token12', '2026-01-01 00:00:00'),
('DIR001', 'Moreau', 'François', 'francois.moreau@univ.fr', '482c811da5d5b4bc6d497ffa98491e38', 'Directeur', '01-23-45-67-94', 'Direction', 'token13', '2026-01-01 00:00:00');

-- ============================================================
-- DONNÉES INITIALES - MATIÈRES
-- ============================================================
INSERT INTO matieres (code, nom, description) VALUES
('MATH101', 'Mathématiques Avancées', 'Cours de mathématiques niveau avancé'),
('MATH102', 'Algèbre Linéaire', 'Théorie et applications de l\'algèbre linéaire'),
('MATH103', 'Analyse Numérique', 'Méthodes numériques et calcul scientifique'),
('MATH104', 'Statistiques', 'Statistiques descriptives et inférentielles'),
('MATH105', 'Probabilités', 'Théorie des probabilités'),
('PHY101', 'Physique Quantique', 'Introduction à la physique quantique'),
('PHY102', 'Électromagnétisme', 'Étude des champs électromagnétiques'),
('PHY103', 'Thermodynamique', 'Principes de thermodynamique'),
('PHY104', 'Optique', 'Optique géométrique et physique'),
('INFO101', 'Programmation Web', 'Développement web moderne HTML/CSS/JavaScript'),
('INFO102', 'Base de données', 'Conception et gestion de bases de données'),
('INFO103', 'Intelligence Artificielle', 'Introduction à l\'IA et Machine Learning'),
('INFO104', 'Sécurité Informatique', 'Principes de cybersécurité'),
('INFO105', 'Systèmes d\'exploitation', 'Architecture et gestion des OS'),
('INFO106', 'Réseaux Informatiques', 'Protocoles et architectures réseau'),
('INFO107', 'Cloud Computing', 'Services cloud et virtualisation'),
('INFO108', 'Architecture Logicielle', 'Patterns et conception logicielle'),
('INFO109', 'DevOps', 'Intégration et déploiement continu'),
('INFO110', 'Blockchain', 'Technologie blockchain et cryptomonnaies'),
('INFO111', 'Développement Mobile', 'Applications iOS et Android'),
('INFO112', 'Big Data', 'Analyse et traitement de données massives'),
('ECON101', 'Microéconomie', 'Principes fondamentaux de microéconomie'),
('ECON102', 'Macroéconomie', 'Économie globale et politiques monétaires'),
('MNG101', 'Gestion de Projet', 'Méthodologies et outils de gestion'),
('MNG102', 'Management Stratégique', 'Stratégies d\'entreprise et leadership');

-- ============================================================
-- DONNÉES INITIALES - SALLES
-- ============================================================
-- Augmentation du nombre de salles à 20
INSERT INTO salles (nom, batiment, capacite, equipements) VALUES
('A101', 'Bâtiment A', 40, 'Projecteur HD, Tableau blanc interactif, WiFi'),
('A102', 'Bâtiment A', 35, 'Projecteur, 20 Ordinateurs, Climatisation'),
('A103', 'Bâtiment A', 30, 'Projecteur, Tableau blanc'),
('A104', 'Bâtiment A', 32, 'Projecteur, Tableau numérique, Sono'),
('B205', 'Bâtiment B', 50, 'Projecteur 4K, Tableau blanc, Système audio'),
('B206', 'Bâtiment B', 45, 'Projecteur, 25 Ordinateurs, Réseau haute vitesse'),
('B207', 'Bâtiment B', 40, 'Projecteur, Tableau numérique'),
('B208', 'Bâtiment B', 38, 'Projecteur, Écran tactile, WiFi 6'),
('C302', 'Bâtiment C', 30, 'Laboratoire, Projecteur, Équipements scientifiques'),
('C303', 'Bâtiment C', 25, '15 Stations de travail, Projecteur, Serveur local'),
('C304', 'Bâtiment C', 28, 'Laboratoire informatique, 18 PC'),
('C305', 'Bâtiment C', 26, 'Laboratoire physique, Équipements expérimentaux'),
('D104', 'Bâtiment D', 80, 'Amphithéâtre, Projecteur double écran, Sono professionnelle'),
('D105', 'Bâtiment D', 75, 'Amphithéâtre, Projecteur, Système audio, Enregistrement'),
('D106', 'Bâtiment D', 70, 'Amphithéâtre, Équipement multimédia complet'),
('E201', 'Bâtiment E', 35, 'Salle multimédia, Projecteur, 20 Tablettes'),
('E202', 'Bâtiment E', 33, 'Studio, Équipements audio-vidéo professionnels'),
('F101', 'Bâtiment F', 42, 'Salle de conférence, Visioconférence, Projecteur'),
('F102', 'Bâtiment F', 38, 'Salle de séminaire, Tableau interactif'),
('LAB01', 'Laboratoire', 20, 'Laboratoire de recherche, Équipements spécialisés');

-- ============================================================
-- DONNÉES INITIALES - DEMANDES
-- ============================================================
INSERT INTO demandes (professeur_id, type_demande, date_seance_originale, heure_debut_originale, heure_fin_originale, salle_originale, matiere, niveau) VALUES
(1, 'modification', '2026-01-20', '08:00:00', '10:00:00', 'A101', 'Mathématiques Avancées', 'L3-MATH-G1'),
(2, 'annulation', '2026-02-15', '14:00:00', '16:00:00', 'C302', 'Physique Quantique', 'L3-PHY-G1'),
(3, 'modification', '2026-03-10', '10:00:00', '12:00:00', 'D104', 'Base de données', 'L2-INFO-G1'),
(4, 'modification', '2026-04-05', '08:00:00', '10:00:00', 'A102', 'Algèbre Linéaire', 'L2-MATH-G1'),
(5, 'annulation', '2026-05-12', '14:00:00', '16:00:00', 'B206', 'Intelligence Artificielle', 'M1-INFO-G1');

-- ============================================================
-- DONNÉES INITIALES - EMPLOI DU TEMPS ENRICHI (Janvier à Juin 2026)
-- ============================================================
-- Ajout de centaines de séances réalistes pour semestre entier

-- JANVIER 2026 - Semaine 1 (5-9 janvier)
INSERT INTO `emploi_temps` (`date_seance`, `heure_debut`, `heure_fin`, `salle`, `professeur_id`, `matiere`, `groupe`, `disponible`) VALUES
('2026-01-05', '08:00:00', '10:00:00', 'A101', 1, 'Mathématiques Avancées', 'L3-MATH-G1', FALSE),
('2026-01-05', '08:00:00', '10:00:00', 'B205', 2, 'Physique Quantique', 'L3-PHY-G1', FALSE),
('2026-01-05', '08:00:00', '10:00:00', 'C302', 3, 'Programmation Web', 'L2-INFO-G1', FALSE),
('2026-01-05', '10:00:00', '12:00:00', 'A102', 4, 'Algèbre Linéaire', 'L2-MATH-G1', FALSE),
('2026-01-05', '10:00:00', '12:00:00', 'D104', 5, 'Intelligence Artificielle', 'M1-INFO-G1', FALSE),
('2026-01-05', '10:00:00', '12:00:00', 'E201', 6, 'Sécurité Informatique', 'M1-INFO-G2', FALSE),
('2026-01-05', '14:00:00', '16:00:00', 'A101', 7, 'Cloud Computing', 'M2-INFO-G1', FALSE),
('2026-01-05', '14:00:00', '16:00:00', 'B206', 8, 'Développement Mobile', 'L3-INFO-G1', FALSE),
('2026-01-05', '14:00:00', '16:00:00', 'C303', 9, 'Gestion de Projet', 'M2-MNG-G1', FALSE),
('2026-01-05', '16:00:00', '18:00:00', 'A103', 10, 'Big Data', 'M2-INFO-G2', FALSE),
('2026-01-05', '16:00:00', '18:00:00', 'D105', 1, 'Analyse Numérique', 'L3-MATH-G2', FALSE),

('2026-01-06', '08:00:00', '10:00:00', 'B205', 3, 'Base de données', 'L2-INFO-G2', FALSE),
('2026-01-06', '08:00:00', '10:00:00', 'A101', 1, 'Probabilités', 'L2-MATH-G2', FALSE),
('2026-01-06', '08:00:00', '10:00:00', 'C304', 6, 'Réseaux Informatiques', 'L3-INFO-G1', FALSE),
('2026-01-06', '10:00:00', '12:00:00', 'D104', 2, 'Thermodynamique', 'L2-PHY-G1', FALSE),
('2026-01-06', '10:00:00', '12:00:00', 'E201', 7, 'Architecture Logicielle', 'M1-INFO-G1', FALSE),
('2026-01-06', '10:00:00', '12:00:00', 'F101', 9, 'Management Stratégique', 'M1-MNG-G1', FALSE),
('2026-01-06', '14:00:00', '16:00:00', 'A102', 4, 'Statistiques', 'L2-MATH-G1', FALSE),
('2026-01-06', '14:00:00', '16:00:00', 'B207', 8, 'DevOps', 'M2-INFO-G1', FALSE),
('2026-01-06', '14:00:00', '16:00:00', 'C302', 5, 'Blockchain', 'M1-INFO-G2', FALSE),
('2026-01-06', '16:00:00', '18:00:00', 'D105', 2, 'Électromagnétisme', 'L3-PHY-G1', FALSE),
('2026-01-06', '16:00:00', '18:00:00', 'A101', 10, 'Microéconomie', 'L2-ECON-G1', FALSE),

('2026-01-07', '08:00:00', '10:00:00', 'C302', 3, 'Systèmes d\'exploitation', 'L2-INFO-G1', FALSE),
('2026-01-07', '08:00:00', '10:00:00', 'A103', 1, 'Mathématiques Avancées', 'L3-MATH-G1', FALSE),
('2026-01-07', '08:00:00', '10:00:00', 'B205', 6, 'Sécurité Informatique', 'M1-INFO-G1', FALSE),
('2026-01-07', '10:00:00', '12:00:00', 'D104', 5, 'Intelligence Artificielle', 'M1-INFO-G1', FALSE),
('2026-01-07', '10:00:00', '12:00:00', 'E201', 8, 'Développement Mobile', 'L3-INFO-G1', FALSE),
('2026-01-07', '10:00:00', '12:00:00', 'F102', 9, 'Gestion de Projet', 'M2-MNG-G1', FALSE),
('2026-01-07', '14:00:00', '16:00:00', 'A102', 4, 'Algèbre Linéaire', 'L2-MATH-G1', FALSE),
('2026-01-07', '14:00:00', '16:00:00', 'B206', 2, 'Optique', 'L3-PHY-G2', FALSE),
('2026-01-07', '14:00:00', '16:00:00', 'C303', 7, 'Cloud Computing', 'M2-INFO-G1', FALSE),
('2026-01-07', '16:00:00', '18:00:00', 'D105', 10, 'Big Data', 'M2-INFO-G2', FALSE),

('2026-01-08', '08:00:00', '10:00:00', 'A101', 1, 'Analyse Numérique', 'L3-MATH-G2', FALSE),
('2026-01-08', '08:00:00', '10:00:00', 'B205', 3, 'Programmation Web', 'L2-INFO-G2', FALSE),
('2026-01-08', '08:00:00', '10:00:00', 'C304', 6, 'Réseaux Informatiques', 'L3-INFO-G1', FALSE),
('2026-01-08', '10:00:00', '12:00:00', 'D104', 2, 'Physique Quantique', 'L3-PHY-G1', FALSE),
('2026-01-08', '10:00:00', '12:00:00', 'E201', 5, 'Blockchain', 'M1-INFO-G2', FALSE),
('2026-01-08', '10:00:00', '12:00:00', 'F101', 9, 'Management Stratégique', 'M1-MNG-G1', FALSE),
('2026-01-08', '14:00:00', '16:00:00', 'A102', 4, 'Probabilités', 'L2-MATH-G2', FALSE),
('2026-01-08', '14:00:00', '16:00:00', 'B207', 8, 'Architecture Logicielle', 'M1-INFO-G1', FALSE),
('2026-01-08', '14:00:00', '16:00:00', 'C302', 7, 'DevOps', 'M2-INFO-G1', FALSE),
('2026-01-08', '16:00:00', '18:00:00', 'D105', 2, 'Thermodynamique', 'L2-PHY-G1', FALSE),

('2026-01-09', '08:00:00', '10:00:00', 'A101', 1, 'Statistiques', 'L2-MATH-G1', FALSE),
('2026-01-09', '08:00:00', '10:00:00', 'B205', 3, 'Base de données', 'L2-INFO-G1', FALSE),
('2026-01-09', '08:00:00', '10:00:00', 'C303', 5, 'Intelligence Artificielle', 'M1-INFO-G1', FALSE),
('2026-01-09', '10:00:00', '12:00:00', 'D104', 6, 'Sécurité Informatique', 'M1-INFO-G2', FALSE),
('2026-01-09', '10:00:00', '12:00:00', 'E201', 8, 'Développement Mobile', 'L3-INFO-G1', FALSE),
('2026-01-09', '10:00:00', '12:00:00', 'F102', 10, 'Microéconomie', 'L2-ECON-G1', FALSE),
('2026-01-09', '14:00:00', '16:00:00', 'A102', 4, 'Mathématiques Avancées', 'L3-MATH-G2', FALSE),
('2026-01-09', '14:00:00', '16:00:00', 'B206', 2, 'Électromagnétisme', 'L3-PHY-G1', FALSE),
('2026-01-09', '14:00:00', '16:00:00', 'C302', NULL, NULL, NULL, TRUE),
('2026-01-09', '16:00:00', '18:00:00', 'D105', 7, 'Cloud Computing', 'M2-INFO-G1', FALSE),

-- JANVIER 2026 - Semaine 2 (12-16 janvier)
('2026-01-12', '08:00:00', '10:00:00', 'A101', 1, 'Analyse Numérique', 'L3-MATH-G1', FALSE),
('2026-01-12', '08:00:00', '10:00:00', 'B205', 2, 'Physique Quantique', 'L3-PHY-G1', FALSE),
('2026-01-12', '08:00:00', '10:00:00', 'C303', 3, 'Programmation Web', 'L2-INFO-G1', FALSE),
('2026-01-12', '10:00:00', '12:00:00', 'D104', 5, 'Intelligence Artificielle', 'M1-INFO-G1', FALSE),
('2026-01-12', '10:00:00', '12:00:00', 'E201', 6, 'Sécurité Informatique', 'M1-INFO-G2', FALSE),
('2026-01-12', '10:00:00', '12:00:00', 'F101', 9, 'Gestion de Projet', 'M2-MNG-G1', FALSE),
('2026-01-12', '14:00:00', '16:00:00', 'A102', 4, 'Algèbre Linéaire', 'L2-MATH-G1', FALSE),
('2026-01-12', '14:00:00', '16:00:00', 'B206', 7, 'Cloud Computing', 'M2-INFO-G1', FALSE),
('2026-01-12', '14:00:00', '16:00:00', 'C302', 8, 'Développement Mobile', 'L3-INFO-G2', FALSE),
('2026-01-12', '16:00:00', '18:00:00', 'D105', 10, 'Big Data', 'M2-INFO-G2', FALSE),

('2026-01-13', '08:00:00', '10:00:00', 'A101', 1, 'Probabilités', 'L2-MATH-G2', FALSE),
('2026-01-13', '08:00:00', '10:00:00', 'B205', 3, 'Base de données', 'L2-INFO-G2', FALSE),
('2026-01-13', '08:00:00', '10:00:00', 'C304', 6, 'Réseaux Informatiques', 'L3-INFO-G1', FALSE),
('2026-01-13', '10:00:00', '12:00:00', 'D104', 2, 'Thermodynamique', 'L2-PHY-G1', FALSE),
('2026-01-13', '10:00:00', '12:00:00', 'E201', 8, 'Architecture Logicielle', 'M1-INFO-G1', FALSE),
('2026-01-13', '10:00:00', '12:00:00', 'F102', 9, 'Management Stratégique', 'M1-MNG-G1', FALSE),
('2026-01-13', '14:00:00', '16:00:00', 'A102', 4, 'Statistiques', 'L2-MATH-G1', FALSE),
('2026-01-13', '14:00:00', '16:00:00', 'B207', 5, 'Blockchain', 'M1-INFO-G2', FALSE),
('2026-01-13', '16:00:00', '18:00:00', 'D105', 2, 'Électromagnétisme', 'L3-PHY-G1', FALSE),

('2026-01-14', '08:00:00', '10:00:00', 'A101', 1, 'Mathématiques Avancées', 'L3-MATH-G1', FALSE),
('2026-01-14', '08:00:00', '10:00:00', 'B205', 3, 'Systèmes d\'exploitation', 'L2-INFO-G1', FALSE),
('2026-01-14', '08:00:00', '10:00:00', 'C303', 6, 'Sécurité Informatique', 'M1-INFO-G1', FALSE),
('2026-01-14', '10:00:00', '12:00:00', 'D104', 5, 'Intelligence Artificielle', 'M1-INFO-G1', FALSE),
('2026-01-14', '10:00:00', '12:00:00', 'E201', 7, 'DevOps', 'M2-INFO-G1', FALSE),
('2026-01-14', '14:00:00', '16:00:00', 'A102', 4, 'Algèbre Linéaire', 'L2-MATH-G1', FALSE),
('2026-01-14', '14:00:00', '16:00:00', 'B206', 2, 'Optique', 'L3-PHY-G2', FALSE),
('2026-01-14', '16:00:00', '18:00:00', 'C302', 10, 'Big Data', 'M2-INFO-G2', FALSE),

('2026-01-15', '08:00:00', '10:00:00', 'A101', 1, 'Analyse Numérique', 'L3-MATH-G2', FALSE),
('2026-01-15', '08:00:00', '10:00:00', 'B205', 3, 'Programmation Web', 'L2-INFO-G2', FALSE),
('2026-01-15', '10:00:00', '12:00:00', 'D104', 2, 'Physique Quantique', 'L3-PHY-G1', FALSE),
('2026-01-15', '10:00:00', '12:00:00', 'E201', 8, 'Développement Mobile', 'L3-INFO-G1', FALSE),
('2026-01-15', '14:00:00', '16:00:00', 'A102', 4, 'Probabilités', 'L2-MATH-G2', FALSE),
('2026-01-15', '14:00:00', '16:00:00', 'B206', 2, 'Optique', 'L3-PHY-G2', FALSE),
('2026-01-15', '16:00:00', '18:00:00', 'C304', 6, 'Réseaux Informatiques', 'L3-INFO-G1', FALSE),

('2026-01-16', '08:00:00', '10:00:00', 'A101', 1, 'Statistiques', 'L2-MATH-G1', FALSE),
('2026-01-16', '08:00:00', '10:00:00', 'B205', 3, 'Base de données', 'L2-INFO-G1', FALSE),
('2026-01-16', '10:00:00', '12:00:00', 'D104', 5, 'Intelligence Artificielle', 'M1-INFO-G1', FALSE),
('2026-01-16', '10:00:00', '12:00:00', 'E201', 7, 'Cloud Computing', 'M2-INFO-G1', FALSE),
('2026-01-16', '14:00:00', '16:00:00', 'A102', 9, 'Gestion de Projet', 'M2-MNG-G1', FALSE),

-- JANVIER 2026 - Semaine 3 (19-23 janvier)
('2026-01-19', '08:00:00', '10:00:00', 'A101', 1, 'Mathématiques Avancées', 'L3-MATH-G1', FALSE),
('2026-01-19', '08:00:00', '10:00:00', 'B205', 2, 'Physique Quantique', 'L3-PHY-G1', FALSE),
('2026-01-19', '08:00:00', '10:00:00', 'C303', 3, 'Programmation Web', 'L2-INFO-G1', FALSE),
('2026-01-19', '10:00:00', '12:00:00', 'D104', 5, 'Intelligence Artificielle', 'M1-INFO-G1', FALSE),
('2026-01-19', '10:00:00', '12:00:00', 'E201', 6, 'Sécurité Informatique', 'M1-INFO-G2', FALSE),
('2026-01-19', '14:00:00', '16:00:00', 'A102', 4, 'Algèbre Linéaire', 'L2-MATH-G1', FALSE),
('2026-01-19', '14:00:00', '16:00:00', 'B206', 8, 'Développement Mobile', 'L3-INFO-G2', FALSE),
('2026-01-19', '16:00:00', '18:00:00', 'C302', 7, 'Cloud Computing', 'M2-INFO-G1', FALSE),

('2026-01-20', '08:00:00', '10:00:00', 'A101', 1, 'Analyse Numérique', 'L3-MATH-G1', FALSE),
('2026-01-20', '08:00:00', '10:00:00', 'B205', 3, 'Base de données', 'L2-INFO-G2', FALSE),
('2026-01-20', '10:00:00', '12:00:00', 'D104', 2, 'Thermodynamique', 'L2-PHY-G1', FALSE),
('2026-01-20', '10:00:00', '12:00:00', 'E201', 9, 'Gestion de Projet', 'M2-MNG-G1', FALSE),
('2026-01-20', '14:00:00', '16:00:00', 'A102', 4, 'Statistiques', 'L2-MATH-G1', FALSE),
('2026-01-20', '16:00:00', '18:00:00', 'C304', 6, 'Réseaux Informatiques', 'L3-INFO-G1', FALSE),

-- JANVIER 2026 - Semaine 4 (26-30 janvier)
('2026-01-26', '08:00:00', '10:00:00', 'A101', 1, 'Probabilités', 'L2-MATH-G2', FALSE),
('2026-01-26', '08:00:00', '10:00:00', 'B205', 2, 'Électromagnétisme', 'L3-PHY-G1', FALSE),
('2026-01-26', '08:00:00', '10:00:00', 'C303', 3, 'Systèmes d\'exploitation', 'L2-INFO-G1', FALSE),
('2026-01-26', '10:00:00', '12:00:00', 'D104', 5, 'Intelligence Artificielle', 'M1-INFO-G1', FALSE),
('2026-01-26', '10:00:00', '12:00:00', 'E201', 8, 'Architecture Logicielle', 'M1-INFO-G1', FALSE),
('2026-01-26', '14:00:00', '16:00:00', 'A102', 4, 'Algèbre Linéaire', 'L2-MATH-G1', FALSE),
('2026-01-26', '14:00:00', '16:00:00', 'B206', 7, 'DevOps', 'M2-INFO-G1', FALSE),
('2026-01-26', '16:00:00', '18:00:00', 'C302', 10, 'Big Data', 'M2-INFO-G2', FALSE),

('2026-01-27', '08:00:00', '10:00:00', 'A101', 1, 'Mathématiques Avancées', 'L3-MATH-G1', FALSE),
('2026-01-27', '08:00:00', '10:00:00', 'B205', 3, 'Programmation Web', 'L2-INFO-G1', FALSE),
('2026-01-27', '10:00:00', '12:00:00', 'D104', 2, 'Optique', 'L3-PHY-G2', FALSE),
('2026-01-27', '10:00:00', '12:00:00', 'E201', 6, 'Sécurité Informatique', 'M1-INFO-G2', FALSE),
('2026-01-27', '14:00:00', '16:00:00', 'A102', 4, 'Statistiques', 'L2-MATH-G1', FALSE),
('2026-01-27', '14:00:00', '16:00:00', 'C304', 5, 'Blockchain', 'M1-INFO-G2', FALSE),

('2026-01-28', '08:00:00', '10:00:00', 'A101', 1, 'Analyse Numérique', 'L3-MATH-G2', FALSE),
('2026-01-28', '08:00:00', '10:00:00', 'B205', 3, 'Base de données', 'L2-INFO-G2', FALSE),
('2026-01-28', '10:00:00', '12:00:00', 'D104', 2, 'Physique Quantique', 'L3-PHY-G1', FALSE),
('2026-01-28', '10:00:00', '12:00:00', 'E201', 8, 'Développement Mobile', 'L3-INFO-G1', FALSE),
('2026-01-28', '14:00:00', '16:00:00', 'A102', 9, 'Management Stratégique', 'M1-MNG-G1', FALSE),
('2026-01-28', '16:00:00', '18:00:00', 'C302', 7, 'Cloud Computing', 'M2-INFO-G1', FALSE),

-- FÉVRIER 2026 - Semaine 1 (2-6 février)
('2026-02-02', '08:00:00', '10:00:00', 'A101', 1, 'Probabilités', 'L2-MATH-G2', FALSE),
('2026-02-02', '08:00:00', '10:00:00', 'B205', 2, 'Thermodynamique', 'L2-PHY-G1', FALSE),
('2026-02-02', '08:00:00', '10:00:00', 'C303', 3, 'Programmation Web', 'L2-INFO-G1', FALSE),
('2026-02-02', '10:00:00', '12:00:00', 'D104', 5, 'Intelligence Artificielle', 'M1-INFO-G1', FALSE),
('2026-02-02', '10:00:00', '12:00:00', 'E201', 6, 'Réseaux Informatiques', 'L3-INFO-G1', FALSE),
('2026-02-02', '14:00:00', '16:00:00', 'A102', 4, 'Mathématiques Avancées', 'L3-MATH-G1', FALSE),
('2026-02-02', '14:00:00', '16:00:00', 'B206', 8, 'Développement Mobile', 'L3-INFO-G2', FALSE),
('2026-02-02', '16:00:00', '18:00:00', 'C302', 7, 'DevOps', 'M2-INFO-G1', FALSE),

('2026-02-03', '08:00:00', '10:00:00', 'A101', 1, 'Analyse Numérique', 'L3-MATH-G1', FALSE),
('2026-02-03', '08:00:00', '10:00:00', 'B205', 3, 'Base de données', 'L2-INFO-G2', FALSE),
('2026-02-03', '10:00:00', '12:00:00', 'D104', 2, 'Électromagnétisme', 'L3-PHY-G1', FALSE),
('2026-02-03', '10:00:00', '12:00:00', 'E201', 9, 'Gestion de Projet', 'M2-MNG-G1', FALSE),
('2026-02-03', '14:00:00', '16:00:00', 'A102', 4, 'Algèbre Linéaire', 'L2-MATH-G1', FALSE),
('2026-02-03', '16:00:00', '18:00:00', 'C304', 10, 'Macroéconomie', 'L2-ECON-G2', FALSE),

-- FÉVRIER 2026 - Semaine 2 (9-13 février)
('2026-02-09', '08:00:00', '10:00:00', 'A101', 1, 'Statistiques', 'L2-MATH-G1', FALSE),
('2026-02-09', '08:00:00', '10:00:00', 'B205', 2, 'Physique Quantique', 'L3-PHY-G1', FALSE),
('2026-02-09', '08:00:00', '10:00:00', 'C303', 3, 'Systèmes d\'exploitation', 'L2-INFO-G1', FALSE),
('2026-02-09', '10:00:00', '12:00:00', 'D104', 5, 'Intelligence Artificielle', 'M1-INFO-G1', FALSE),
('2026-02-09', '10:00:00', '12:00:00', 'E201', 6, 'Sécurité Informatique', 'M1-INFO-G2', FALSE),
('2026-02-09', '14:00:00', '16:00:00', 'A102', 4, 'Analyse Numérique', 'L3-MATH-G2', FALSE),
('2026-02-09', '14:00:00', '16:00:00', 'B206', 8, 'Architecture Logicielle', 'M1-INFO-G1', FALSE),
('2026-02-09', '16:00:00', '18:00:00', 'C302', 7, 'Cloud Computing', 'M2-INFO-G1', FALSE),

-- MARS 2026 - Semaine 1 (2-6 mars)
('2026-03-02', '08:00:00', '10:00:00', 'A101', 1, 'Mathématiques Avancées', 'L3-MATH-G1', FALSE),
('2026-03-02', '08:00:00', '10:00:00', 'B205', 2, 'Physique Quantique', 'L3-PHY-G1', FALSE),
('2026-03-02', '08:00:00', '10:00:00', 'C303', 3, 'Programmation Web', 'L2-INFO-G1', FALSE),
('2026-03-02', '10:00:00', '12:00:00', 'D104', 5, 'Intelligence Artificielle', 'M1-INFO-G1', FALSE),
('2026-03-02', '10:00:00', '12:00:00', 'E201', 6, 'Réseaux Informatiques', 'L3-INFO-G1', FALSE),
('2026-03-02', '14:00:00', '16:00:00', 'A102', 4, 'Statistiques', 'L2-MATH-G1', FALSE),
('2026-03-02', '14:00:00', '16:00:00', 'B206', 8, 'Développement Mobile', 'L3-INFO-G2', FALSE),
('2026-03-02', '16:00:00', '18:00:00', 'C302', 7, 'DevOps', 'M2-INFO-G1', FALSE),

('2026-03-03', '08:00:00', '10:00:00', 'A101', 1, 'Probabilités', 'L2-MATH-G2', FALSE),
('2026-03-03', '08:00:00', '10:00:00', 'B205', 3, 'Programmation Web', 'L2-INFO-G1', FALSE),
('2026-03-03', '10:00:00', '12:00:00', 'D104', 2, 'Électromagnétisme', 'L3-PHY-G1', FALSE),
('2026-03-03', '10:00:00', '12:00:00', 'E201', 9, 'Gestion de Projet', 'M2-MNG-G1', FALSE),
('2026-03-03', '14:00:00', '16:00:00', 'A102', 4, 'Algèbre Linéaire', 'L2-MATH-G1', FALSE),
('2026-03-03', '16:00:00', '18:00:00', 'C304', 10, 'Macroéconomie', 'L2-ECON-G2', FALSE),

-- MARS 2026 - Semaine 2 (9-13 mars)
('2026-03-09', '08:00:00', '10:00:00', 'A101', 1, 'Mathématiques Avancées', 'L3-MATH-G1', FALSE),
('2026-03-09', '08:00:00', '10:00:00', 'B205', 2, 'Physique Quantique', 'L3-PHY-G1', FALSE),
('2026-03-09', '08:00:00', '10:00:00', 'C303', 3, 'Systèmes d\'exploitation', 'L2-INFO-G1', FALSE),
('2026-03-09', '10:00:00', '12:00:00', 'D104', 5, 'Intelligence Artificielle', 'M1-INFO-G1', FALSE),
('2026-03-09', '10:00:00', '12:00:00', 'E201', 6, 'Sécurité Informatique', 'M1-INFO-G2', FALSE),
('2026-03-09', '14:00:00', '16:00:00', 'A102', 4, 'Analyse Numérique', 'L3-MATH-G2', FALSE),
('2026-03-09', '14:00:00', '16:00:00', 'B206', 7, 'DevOps', 'M2-INFO-G1', FALSE),
('2026-03-09', '16:00:00', '18:00:00', 'C302', 10, 'Big Data', 'M2-INFO-G2', FALSE),

-- MARS 2026 - Semaine 3 (16-20 mars)
('2026-03-16', '08:00:00', '10:00:00', 'A101', 1, 'Probabilités', 'L2-MATH-G2', FALSE),
('2026-03-16', '08:00:00', '10:00:00', 'B205', 2, 'Optique', 'L3-PHY-G2', FALSE),
('2026-03-16', '08:00:00', '10:00:00', 'C303', 3, 'Base de données', 'L2-INFO-G2', FALSE),
('2026-03-16', '10:00:00', '12:00:00', 'D104', 5, 'Blockchain', 'M1-INFO-G2', FALSE),
('2026-03-16', '10:00:00', '12:00:00', 'E201', 6, 'Réseaux Informatiques', 'L3-INFO-G1', FALSE),
('2026-03-16', '14:00:00', '16:00:00', 'A102', 4, 'Statistiques', 'L2-MATH-G1', FALSE),
('2026-03-16', '14:00:00', '16:00:00', 'B206', 8, 'Développement Mobile', 'L3-INFO-G2', FALSE),
('2026-03-16', '16:00:00', '18:00:00', 'C302', 10, 'Big Data', 'M2-INFO-G2', FALSE),

-- AVRIL 2026 - Semaine 1 (6-10 avril)
('2026-04-06', '08:00:00', '10:00:00', 'A101', 1, 'Analyse Numérique', 'L3-MATH-G1', FALSE),
('2026-04-06', '08:00:00', '10:00:00', 'B205', 2, 'Thermodynamique', 'L2-PHY-G1', FALSE),
('2026-04-06', '08:00:00', '10:00:00', 'C303', 3, 'Programmation Web', 'L2-INFO-G1', FALSE),
('2026-04-06', '10:00:00', '12:00:00', 'D104', 5, 'Intelligence Artificielle', 'M1-INFO-G1', FALSE),
('2026-04-06', '10:00:00', '12:00:00', 'E201', 6, 'Sécurité Informatique', 'M1-INFO-G2', FALSE),
('2026-04-06', '14:00:00', '16:00:00', 'A102', 4, 'Algèbre Linéaire', 'L2-MATH-G1', FALSE),
('2026-04-06', '14:00:00', '16:00:00', 'B206', 7, 'DevOps', 'M2-INFO-G1', FALSE),
('2026-04-06', '16:00:00', '18:00:00', 'C302', 9, 'Gestion de Projet', 'M2-MNG-G1', FALSE),

('2026-04-07', '08:00:00', '10:00:00', 'A101', 1, 'Mathématiques Avancées', 'L3-MATH-G1', FALSE),
('2026-04-07', '08:00:00', '10:00:00', 'B205', 3, 'Base de données', 'L2-INFO-G2', FALSE),
('2026-04-07', '10:00:00', '12:00:00', 'D104', 2, 'Électromagnétisme', 'L3-PHY-G1', FALSE),
('2026-04-07', '10:00:00', '12:00:00', 'E201', 8, 'Architecture Logicielle', 'M1-INFO-G1', FALSE),
('2026-04-07', '14:00:00', '16:00:00', 'A102', 4, 'Probabilités', 'L2-MATH-G2', FALSE),
('2026-04-07', '16:00:00', '18:00:00', 'C304', 10, 'Microéconomie', 'L2-ECON-G1', FALSE),

-- AVRIL 2026 - Semaine 2 (13-17 avril)
('2026-04-13', '08:00:00', '10:00:00', 'A101', 1, 'Statistiques', 'L2-MATH-G1', FALSE),
('2026-04-13', '08:00:00', '10:00:00', 'B205', 2, 'Physique Quantique', 'L3-PHY-G1', FALSE),
('2026-04-13', '08:00:00', '10:00:00', 'C303', 3, 'Systèmes d\'exploitation', 'L2-INFO-G1', FALSE),
('2026-04-13', '10:00:00', '12:00:00', 'D104', 5, 'Intelligence Artificielle', 'M1-INFO-G1', FALSE),
('2026-04-13', '10:00:00', '12:00:00', 'E201', 6, 'Réseaux Informatiques', 'L3-INFO-G1', FALSE),
('2026-04-13', '14:00:00', '16:00:00', 'A102', 4, 'Analyse Numérique', 'L3-MATH-G2', FALSE),
('2026-04-13', '14:00:00', '16:00:00', 'B206', 8, 'Développement Mobile', 'L3-INFO-G2', FALSE),
('2026-04-13', '16:00:00', '18:00:00', 'C302', 7, 'Cloud Computing', 'M2-INFO-G1', FALSE),

-- AVRIL 2026 - Semaine 3 (20-24 avril)
('2026-04-20', '08:00:00', '10:00:00', 'A101', 1, 'Probabilités', 'L2-MATH-G2', FALSE),
('2026-04-20', '08:00:00', '10:00:00', 'B205', 2, 'Optique', 'L3-PHY-G2', FALSE),
('2026-04-20', '08:00:00', '10:00:00', 'C303', 3, 'Programmation Web', 'L2-INFO-G1', FALSE),
('2026-04-20', '10:00:00', '12:00:00', 'D104', 5, 'Blockchain', 'M1-INFO-G2', FALSE),
('2026-04-20', '10:00:00', '12:00:00', 'E201', 9, 'Management Stratégique', 'M1-MNG-G1', FALSE),
('2026-04-20', '14:00:00', '16:00:00', 'A102', 4, 'Mathématiques Avancées', 'L3-MATH-G1', FALSE),
('2026-04-20', '14:00:00', '16:00:00', 'B206', 6, 'Sécurité Informatique', 'M1-INFO-G2', FALSE),
('2026-04-20', '16:00:00', '18:00:00', 'C302', 10, 'Big Data', 'M2-INFO-G2', FALSE),

-- MAI 2026 - Semaine 1 (4-8 mai)
('2026-05-04', '08:00:00', '10:00:00', 'A101', 1, 'Analyse Numérique', 'L3-MATH-G1', FALSE),
('2026-05-04', '08:00:00', '10:00:00', 'B205', 2, 'Thermodynamique', 'L2-PHY-G1', FALSE),
('2026-05-04', '08:00:00', '10:00:00', 'C303', 3, 'Base de données', 'L2-INFO-G2', FALSE),
('2026-05-04', '10:00:00', '12:00:00', 'D104', 5, 'Intelligence Artificielle', 'M1-INFO-G1', FALSE),
('2026-05-04', '10:00:00', '12:00:00', 'E201', 6, 'Réseaux Informatiques', 'L3-INFO-G2', FALSE),
('2026-05-04', '14:00:00', '16:00:00', 'A102', 4, 'Algèbre Linéaire', 'L2-MATH-G1', FALSE),
('2026-05-04', '14:00:00', '16:00:00', 'B206', 8, 'Architecture Logicielle', 'M1-INFO-G1', FALSE),
('2026-05-04', '16:00:00', '18:00:00', 'C302', 7, 'DevOps', 'M2-INFO-G1', FALSE),

('2026-05-05', '08:00:00', '10:00:00', 'A101', 1, 'Statistiques', 'L2-MATH-G1', FALSE),
('2026-05-05', '08:00:00', '10:00:00', 'B205', 3, 'Programmation Web', 'L2-INFO-G1', FALSE),
('2026-05-05', '10:00:00', '12:00:00', 'D104', 2, 'Physique Quantique', 'L3-PHY-G1', FALSE),
('2026-05-05', '10:00:00', '12:00:00', 'E201', 9, 'Gestion de Projet', 'M2-MNG-G1', FALSE),
('2026-05-05', '14:00:00', '16:00:00', 'A102', 4, 'Probabilités', 'L2-MATH-G2', FALSE),
('2026-05-05', '16:00:00', '18:00:00', 'C304', 10, 'Macroéconomie', 'L2-ECON-G2', FALSE),

-- MAI 2026 - Semaine 2 (11-15 mai)
('2026-05-11', '08:00:00', '10:00:00', 'A101', 1, 'Mathématiques Avancées', 'L3-MATH-G1', FALSE),
('2026-05-11', '08:00:00', '10:00:00', 'B205', 2, 'Électromagnétisme', 'L3-PHY-G1', FALSE),
('2026-05-11', '08:00:00', '10:00:00', 'C303', 3, 'Systèmes d\'exploitation', 'L2-INFO-G1', FALSE),
('2026-05-11', '10:00:00', '12:00:00', 'D104', 5, 'Intelligence Artificielle', 'M1-INFO-G1', FALSE),
('2026-05-11', '10:00:00', '12:00:00', 'E201', 6, 'Sécurité Informatique', 'M1-INFO-G2', FALSE),
('2026-05-11', '14:00:00', '16:00:00', 'A102', 4, 'Analyse Numérique', 'L3-MATH-G2', FALSE),
('2026-05-11', '14:00:00', '16:00:00', 'B206', 8, 'Développement Mobile', 'L3-INFO-G2', FALSE),
('2026-05-11', '16:00:00', '18:00:00', 'C302', 7, 'Cloud Computing', 'M2-INFO-G1', FALSE),

-- MAI 2026 - Semaine 3 (18-22 mai)
('2026-05-18', '08:00:00', '10:00:00', 'A101', 1, 'Probabilités', 'L2-MATH-G2', FALSE),
('2026-05-18', '08:00:00', '10:00:00', 'B205', 2, 'Optique', 'L3-PHY-G2', FALSE),
('2026-05-18', '08:00:00', '10:00:00', 'C303', 3, 'Base de données', 'L2-INFO-G2', FALSE),
('2026-05-18', '10:00:00', '12:00:00', 'D104', 5, 'Blockchain', 'M1-INFO-G2', FALSE),
('2026-05-18', '10:00:00', '12:00:00', 'E201', 6, 'Réseaux Informatiques', 'L3-INFO-G1', FALSE),
('2026-05-18', '14:00:00', '16:00:00', 'A102', 4, 'Statistiques', 'L2-MATH-G1', FALSE),
('2026-05-18', '14:00:00', '16:00:00', 'B206', 9, 'Management Stratégique', 'M1-MNG-G1', FALSE),
('2026-05-18', '16:00:00', '18:00:00', 'C302', 10, 'Big Data', 'M2-INFO-G2', FALSE),

-- JUIN 2026 - Semaine 1 (1-5 juin)
('2026-06-01', '08:00:00', '10:00:00', 'A101', 1, 'Analyse Numérique', 'L3-MATH-G1', FALSE),
('2026-06-01', '08:00:00', '10:00:00', 'B205', 2, 'Thermodynamique', 'L2-PHY-G1', FALSE),
('2026-06-01', '08:00:00', '10:00:00', 'C303', 3, 'Programmation Web', 'L2-INFO-G1', FALSE),
('2026-06-01', '10:00:00', '12:00:00', 'D104', 5, 'Intelligence Artificielle', 'M1-INFO-G1', FALSE),
('2026-06-01', '10:00:00', '12:00:00', 'E201', 6, 'Sécurité Informatique', 'M1-INFO-G2', FALSE),
('2026-06-01', '14:00:00', '16:00:00', 'A102', 4, 'Algèbre Linéaire', 'L2-MATH-G1', FALSE),
('2026-06-01', '14:00:00', '16:00:00', 'B206', 8, 'Architecture Logicielle', 'M1-INFO-G1', FALSE),
('2026-06-01', '16:00:00', '18:00:00', 'C302', 7, 'DevOps', 'M2-INFO-G1', FALSE),

('2026-06-02', '08:00:00', '10:00:00', 'A101', 1, 'Mathématiques Avancées', 'L3-MATH-G1', FALSE),
('2026-06-02', '08:00:00', '10:00:00', 'B205', 3, 'Base de données', 'L2-INFO-G2', FALSE),
('2026-06-02', '10:00:00', '12:00:00', 'D104', 2, 'Physique Quantique', 'L3-PHY-G1', FALSE),
('2026-06-02', '10:00:00', '12:00:00', 'E201', 8, 'Développement Mobile', 'L3-INFO-G1', FALSE),
('2026-06-02', '14:00:00', '16:00:00', 'A102', 4, 'Probabilités', 'L2-MATH-G2', FALSE),
('2026-06-02', '16:00:00', '18:00:00', 'C304', 10, 'Microéconomie', 'L2-ECON-G1', FALSE),

-- JUIN 2026 - Semaine 2 (8-12 juin)
('2026-06-08', '08:00:00', '10:00:00', 'A101', 1, 'Statistiques', 'L2-MATH-G1', FALSE),
('2026-06-08', '08:00:00', '10:00:00', 'B205', 2, 'Électromagnétisme', 'L3-PHY-G1', FALSE),
('2026-06-08', '08:00:00', '10:00:00', 'C303', 3, 'Systèmes d\'exploitation', 'L2-INFO-G1', FALSE),
('2026-06-08', '10:00:00', '12:00:00', 'D104', 5, 'Intelligence Artificielle', 'M1-INFO-G1', FALSE),
('2026-06-08', '10:00:00', '12:00:00', 'E201', 6, 'Réseaux Informatiques', 'L3-INFO-G2', FALSE),
('2026-06-08', '14:00:00', '16:00:00', 'A102', 4, 'Analyse Numérique', 'L3-MATH-G2', FALSE),
('2026-06-08', '14:00:00', '16:00:00', 'B206', 8, 'Développement Mobile', 'L3-INFO-G2', FALSE),
('2026-06-08', '16:00:00', '18:00:00', 'C302', 7, 'Cloud Computing', 'M2-INFO-G1', FALSE),

-- JUIN 2026 - Semaine 3 (15-19 juin) - Dernière semaine avant examens
('2026-06-15', '08:00:00', '10:00:00', 'A101', 1, 'Mathématiques Avancées', 'L3-MATH-G1', FALSE),
('2026-06-15', '08:00:00', '10:00:00', 'B205', 2, 'Physique Quantique', 'L3-PHY-G1', FALSE),
('2026-06-15', '08:00:00', '10:00:00', 'C303', 3, 'Programmation Web', 'L2-INFO-G1', FALSE),
('2026-06-15', '10:00:00', '12:00:00', 'D104', 5, 'Intelligence Artificielle', 'M1-INFO-G1', FALSE),
('2026-06-15', '10:00:00', '12:00:00', 'E201', 6, 'Sécurité Informatique', 'M1-INFO-G2', FALSE),
('2026-06-15', '14:00:00', '16:00:00', 'A102', 4, 'Probabilités', 'L2-MATH-G2', FALSE),
('2026-06-15', '14:00:00', '16:00:00', 'B206', 8, 'Architecture Logicielle', 'M1-INFO-G1', FALSE),
('2026-06-15', '16:00:00', '18:00:00', 'C302', 10, 'Big Data', 'M2-INFO-G2', FALSE),

('2026-06-16', '08:00:00', '10:00:00', 'A101', 1, 'Analyse Numérique', 'L3-MATH-G1', FALSE),
('2026-06-16', '08:00:00', '10:00:00', 'B205', 3, 'Base de données', 'L2-INFO-G2', FALSE),
('2026-06-16', '10:00:00', '12:00:00', 'D104', 2, 'Optique', 'L3-PHY-G2', FALSE),
('2026-06-16', '10:00:00', '12:00:00', 'E201', 9, 'Gestion de Projet', 'M2-MNG-G1', FALSE),
('2026-06-16', '14:00:00', '16:00:00', 'A102', 4, 'Statistiques', 'L2-MATH-G1', FALSE),
('2026-06-16', '16:00:00', '18:00:00', 'C304', 7, 'Cloud Computing', 'M2-INFO-G1', FALSE),

('2026-06-17', '08:00:00', '10:00:00', 'A101', 1, 'Probabilités', 'L2-MATH-G2', FALSE),
('2026-06-17', '08:00:00', '10:00:00', 'B205', 2, 'Thermodynamique', 'L2-PHY-G1', FALSE),
('2026-06-17', '08:00:00', '10:00:00', 'C303', 3, 'Systèmes d\'exploitation', 'L2-INFO-G1', FALSE),
('2026-06-17', '10:00:00', '12:00:00', 'D104', 5, 'Blockchain', 'M1-INFO-G2', FALSE),
('2026-06-17', '10:00:00', '12:00:00', 'E201', 6, 'Réseaux Informatiques', 'L3-INFO-G1', FALSE),
('2026-06-17', '14:00:00', '16:00:00', 'A102', 4, 'Algèbre Linéaire', 'L2-MATH-G1', FALSE),
('2026-06-17', '14:00:00', '16:00:00', 'B206', 8, 'Développement Mobile', 'L3-INFO-G2', FALSE),
('2026-06-17', '16:00:00', '18:00:00', 'C302', 10, 'Macroéconomie', 'L2-ECON-G2', FALSE),

-- Séances de révision - Semaine du 22-26 juin
('2026-06-22', '08:00:00', '10:00:00', 'D104', 1, 'Révision Mathématiques', 'L3-MATH-G1', FALSE),
('2026-06-22', '10:00:00', '12:00:00', 'D104', 2, 'Révision Physique', 'L3-PHY-G1', FALSE),
('2026-06-22', '14:00:00', '16:00:00', 'D104', 3, 'Révision Informatique', 'L2-INFO-G1', FALSE),
('2026-06-22', '16:00:00', '18:00:00', 'D104', 5, 'Révision IA', 'M1-INFO-G1', FALSE),

('2026-06-23', '08:00:00', '10:00:00', 'D104', 4, 'Révision Mathématiques', 'L2-MATH-G1', FALSE),
('2026-06-23', '10:00:00', '12:00:00', 'D104', 6, 'Révision Réseaux', 'L3-INFO-G1', FALSE),
('2026-06-23', '14:00:00', '16:00:00', 'D104', 8, 'Révision Mobile', 'L3-INFO-G2', FALSE),
('2026-06-23', '16:00:00', '18:00:00', 'D104', 10, 'Révision Économie', 'L2-ECON-G1', FALSE),

('2026-06-24', '08:00:00', '10:00:00', 'D104', 7, 'Révision Cloud', 'M2-INFO-G1', FALSE),
('2026-06-24', '10:00:00', '12:00:00', 'D104', 9, 'Révision Management', 'M2-MNG-G1', FALSE),
('2026-06-24', '14:00:00', '16:00:00', 'D104', 1, 'Révision Analyse', 'L3-MATH-G2', FALSE);

-- ============================================================
-- DONNÉES INITIALES - NOTIFICATIONS
-- ============================================================
INSERT INTO notifications (utilisateur_id, demande_id, message, lu) VALUES
(1, 1, 'Votre demande #1 a été validée par le directeur', FALSE),
(11, 2, 'Nouvelle demande en attente de validation (#2)', FALSE),
(13, 3, 'Nouvelle demande validée par l\'assistante, en attente de votre validation (#3)', FALSE),
(4, 4, 'Votre demande #4 a été validée par le directeur', TRUE),
(5, 5, 'Votre demande #5 est en cours de traitement', FALSE),
(1, NULL, 'Bienvenue dans le système de gestion des séances', TRUE),
(2, NULL, 'Bienvenue dans le système de gestion des séances', TRUE);

-- ============================================================
-- DONNÉES INITIALES - PARAMÈTRES SYSTÈME
-- ============================================================
INSERT INTO parametres (cle, valeur, description) VALUES
('delai_minimum_demande', '48', 'Délai minimum en heures avant une séance pour soumettre une demande'),
('max_tentatives_connexion', '5', 'Nombre maximum de tentatives de connexion avant blocage'),
('duree_blocage', '15', 'Durée du blocage en minutes après dépassement des tentatives'),
('notification_email', '1', 'Activer les notifications par email (1=oui, 0=non)'),
('max_demandes_mois', '10', 'Nombre maximum de demandes par professeur par mois'),
('nom_universite', 'Université Mohammed V', 'Nom de l\'établissement'),
('email_support', 'support@univ.fr', 'Email du support technique'),
('session_timeout', '30', 'Durée de session en minutes'),
('maintenance_mode', '0', 'Mode maintenance activé (1=oui, 0=non)');

-- ============================================================
-- LOGS INITIAUX
-- ============================================================
INSERT INTO logs_activite (utilisateur_id, action, table_concernee, details) VALUES
(13, 'CREATION_BASE', 'system', '{"message": "Base de données initialisée avec succès"}'),
(13, 'IMPORT_DONNEES', 'utilisateurs', '{"nb_utilisateurs": 13}'),
(13, 'IMPORT_DONNEES', 'matieres', '{"nb_matieres": 25}'),
(13, 'IMPORT_DONNEES', 'salles', '{"nb_salles": 20}'),
(13, 'IMPORT_DONNEES', 'emploi_temps', '{"nb_seances": 200, "periode": "janvier-juin 2026"}');
