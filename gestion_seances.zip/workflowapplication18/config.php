<?php
// Configuration de la base de données
if (!defined('DB_HOST')) define('DB_HOST', 'localhost');
if (!defined('DB_NAME')) define('DB_NAME', 'gestion_seances');
if (!defined('DB_USER')) define('DB_USER', 'root');
if (!defined('DB_PASS')) define('DB_PASS', '');

if (!defined('BASE_URL')) {
    $script_name = $_SERVER['SCRIPT_NAME'];
    $dir = str_replace('\\', '/', dirname($script_name));
    // Find the root folder name dynamically
    $parts = explode('/', trim($dir, '/'));
    if (!empty($parts)) {
        define('BASE_URL', '/' . $parts[0]);
    } else {
        define('BASE_URL', '');
    }
}

define('UPLOAD_DIR', __DIR__ . '/uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5 MB

$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? "https" : "http";
$host = $_SERVER['HTTP_HOST'];
$script = $_SERVER['SCRIPT_NAME'];
$base_dir = str_replace(basename($script), '', $script);
// Ensure BASE_URL doesn't end with a slash for consistency with includes
// define('BASE_URL', rtrim($protocol . "://" . $host . $base_dir, '/'));

// Connexion à la base de données
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch(PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

// Configuration des sessions
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_secure', 0);
    ini_set('session.cookie_samesite', 'Strict');
    session_start();
}

if (!isset($_SESSION['user_id']) && isset($_COOKIE['remember_token']) && isset($_COOKIE['remember_user'])) {
    $token = $_COOKIE['remember_token'];
    $user_id = (int)$_COOKIE['remember_user'];
    $token_hash = hash('sha256', $token);
    
    try {
        $stmt = $pdo->prepare("
            SELECT * FROM utilisateurs 
            WHERE id = ? 
            AND remember_token = ? 
            AND remember_token_expiration > NOW()
            AND actif = 1
        ");
        $stmt->execute([$user_id, $token_hash]);
        $utilisateur = $stmt->fetch();
        
        if ($utilisateur) {
            // Connexion automatique réussie
            session_regenerate_id(true);
            
            $_SESSION['user_id'] = $utilisateur['id'];
            $_SESSION['user_nom'] = $utilisateur['nom'];
            $_SESSION['user_prenom'] = $utilisateur['prenom'];
            $_SESSION['user_email'] = $utilisateur['email'];
            $_SESSION['user_role'] = $utilisateur['role'];
            $_SESSION['last_activity'] = time();
            
            $_SESSION['utilisateur_id'] = $utilisateur['id'];
            $_SESSION['utilisateur_nom'] = $utilisateur['nom'];
            $_SESSION['utilisateur_prenom'] = $utilisateur['prenom'];
            $_SESSION['utilisateur_role'] = strtolower($utilisateur['role']);
            
            // Mettre à jour la dernière connexion
            $stmt = $pdo->prepare("UPDATE utilisateurs SET derniere_connexion = NOW() WHERE id = ?");
            $stmt->execute([$utilisateur['id']]);
        } else {
            // Token invalide ou expiré, supprimer les cookies
            setcookie('remember_token', '', time() - 3600, '/');
            setcookie('remember_user', '', time() - 3600, '/');
        }
    } catch (PDOException $e) {
        error_log("Erreur auto-login: " . $e->getMessage());
    }
}

define('SESSION_TIMEOUT', 1800); // 30 minutes

if (isset($_SESSION['user_id']) && isset($_SESSION['last_activity'])) {
    if (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT) {
        session_unset();
        session_destroy();
        header('Location: login.php?timeout=1');
        exit;
    }
    $_SESSION['last_activity'] = time();
}

// Fonctions de sécurité de base
if (!function_exists('securiser')) {
    function securiser($data) {
        return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('genererTokenCSRF')) {
    function genererTokenCSRF() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
}

if (!function_exists('verifierTokenCSRF')) {
    function verifierTokenCSRF($token) {
        if (!isset($_SESSION['csrf_token']) || empty($token)) {
            return false;
        }
        return hash_equals($_SESSION['csrf_token'], $token);
    }
}

if (!function_exists('estConnecte')) {
    function estConnecte() {
        return isset($_SESSION['user_id']);
    }
}

if (!function_exists('verifierConnexion')) {
    function verifierConnexion() {
        if (!estConnecte()) {
            header('Location: login.php');
            exit;
        }
    }
}

if (!function_exists('verifierRole')) {
    function verifierRole($roles_autorises) {
        if (!estConnecte()) {
            header('Location: login.php');
            exit;
        }
        
        if (!in_array($_SESSION['user_role'], $roles_autorises)) {
            header('Location: index.php?error=acces_refuse');
            exit;
        }
    }
}

if (!function_exists('logActivity')) {
    function logActivity($user_id, $action, $table, $record_id = null, $details = []) {
        global $pdo;
        
        try {
            $stmt = $pdo->prepare("
                INSERT INTO logs_activite (utilisateur_id, action, table_concernee, enregistrement_id, details, adresse_ip, user_agent)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $user_id,
                $action,
                $table,
                $record_id,
                json_encode($details),
                $_SERVER['REMOTE_ADDR'] ?? null,
                $_SERVER['HTTP_USER_AGENT'] ?? null
            ]);
        } catch (PDOException $e) {
            error_log("Erreur log: " . $e->getMessage());
        }
    }
}

if (!function_exists('validerUpload')) {
    function validerUpload($file, $max_size = MAX_FILE_SIZE) {
        $extensions_autorisees = ['pdf', 'jpg', 'jpeg', 'png'];
        $mimes_autorises = ['application/pdf', 'image/jpeg', 'image/png'];
        
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return ['success' => false, 'message' => 'Erreur lors de l\'upload'];
        }
        
        if ($file['size'] > $max_size) {
            return ['success' => false, 'message' => 'Fichier trop volumineux (max 5 Mo)'];
        }
        
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($extension, $extensions_autorisees)) {
            return ['success' => false, 'message' => 'Type de fichier non autorisé'];
        }
        
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        
        if (!in_array($mime, $mimes_autorises)) {
            return ['success' => false, 'message' => 'Type MIME non autorisé'];
        }
        
        $nom_unique = bin2hex(random_bytes(16)) . '.' . $extension;
        
        return ['success' => true, 'nom_unique' => $nom_unique, 'extension' => $extension, 'mime' => $mime];
    }
}

if (!function_exists('envoyerEmailNotification')) {
    function envoyerEmailNotification($destinataire, $sujet, $message) {
        $headers = "From: noreply@uemf.ac.ma\r\n";
        $headers .= "Reply-To: noreply@uemf.ac.ma\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        
        $message_html = "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #003366 0%, #4CAF50 100%); color: white; padding: 20px; border-radius: 8px 8px 0 0; }
                .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 8px 8px; }
                .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #6c757d; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>$sujet</h2>
                </div>
                <div class='content'>
                    <p>$message</p>
                    <p style='margin-top: 30px;'>Cordialement,<br>L'équipe de gestion des séances<br>EUROMED UNIVERSITY OF FES</p>
                </div>
                <div class='footer'>
                    <p>Cet email a été envoyé automatiquement, merci de ne pas y répondre.</p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        error_log("EMAIL - To: $destinataire - Subject: $sujet");
        return true;
    }
}

if (!function_exists('verifierTentativesConnexion')) {
    function verifierTentativesConnexion($email) {
        global $pdo;
        
        try {
            $stmt = $pdo->prepare("
                SELECT COUNT(*) as tentatives 
                FROM logs_activite 
                WHERE action = 'CONNEXION_ECHOUEE' 
                AND details LIKE ? 
                AND date_action > DATE_SUB(NOW(), INTERVAL 15 MINUTE)
            ");
            $stmt->execute(['%' . $email . '%']);
            $result = $stmt->fetch();
            
            if ($result && $result['tentatives'] >= 5) {
                return [
                    'bloque' => true,
                    'message' => "Après 5 tentatives de connexion échouées, votre accès sera temporairement bloqué pendant 15 minutes."
                ];
            }
        } catch (PDOException $e) {
            error_log("Erreur vérification tentatives: " . $e->getMessage());
        }
        
        return ['bloque' => false];
    }
}

if (!function_exists('enregistrerTentativeEchouee')) {
    function enregistrerTentativeEchouee($email, $ip) {
        global $pdo;
        
        try {
            $stmt = $pdo->prepare("
                INSERT INTO logs_activite (utilisateur_id, action, table_concernee, details, adresse_ip) 
                VALUES (NULL, 'CONNEXION_ECHOUEE', 'utilisateurs', ?, ?)
            ");
            $stmt->execute([json_encode(['email' => $email]), $ip]);
        } catch (PDOException $e) {
            error_log("Erreur enregistrement tentative: " . $e->getMessage());
        }
    }
}

if (!function_exists('validerEntree')) {
    function validerEntree($data, $type = 'text') {
        $data = trim($data);
        
        switch($type) {
            case 'email':
                if (!filter_var($data, FILTER_VALIDATE_EMAIL)) {
                    return ['valide' => false, 'message' => 'Format d\'email invalide'];
                }
                break;
            case 'telephone':
                if (!preg_match('/^[0-9]{10}$/', str_replace([' ', '-', '.'], '', $data))) {
                    return ['valide' => false, 'message' => 'Format de téléphone invalide'];
                }
                break;
            case 'date':
                if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)) {
                    return ['valide' => false, 'message' => 'Format de date invalide'];
                }
                break;
            case 'heure':
                if (!preg_match('/^\d{2}:\d{2}$/', $data)) {
                    return ['valide' => false, 'message' => 'Format d\'heure invalide'];
                }
                break;
        }
        
        return ['valide' => true, 'data' => $data];
    }
}

// Fonctions de compatibilité avec l'ancien code
if (!function_exists('getDatabase')) {
    function getDatabase() {
        global $pdo;
        return $pdo;
    }
}

if (!function_exists('nettoyer')) {
    function nettoyer($data) {
        return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('echapper')) {
    function echapper($data) {
        return htmlspecialchars($data, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
}

if (!function_exists('rediriger')) {
    function rediriger($url) {
        header("Location: " . BASE_URL . $url);
        exit;
    }
}

if (!function_exists('protegerPage')) {
    function protegerPage() {
        if (!isset($_SESSION['utilisateur_id'])) {
            rediriger('/login.php');
        }
    }
}

if (!function_exists('protegerPageRole')) {
    function protegerPageRole($role_requis) {
        protegerPage();
        if (strtolower($_SESSION['utilisateur_role']) !== strtolower($role_requis)) {
            rediriger('/index.php?erreur=acces_refuse');
        }
    }
}

if (!function_exists('loggerActivite')) {
    function loggerActivite($utilisateur_id, $action, $enregistrement_id = null, $details = []) {
        logActivity($utilisateur_id, $action, 'general', $enregistrement_id, $details);
    }
}

if (!defined('APP_VERSION')) define('APP_VERSION', '1.0.0');

// Helper for asset paths
if (!function_exists('asset')) {
    function asset($path) {
        return BASE_URL . '/' . ltrim($path, '/');
    }
}

// Headers de sécurité HTTP
header("X-Frame-Options: DENY");
header("X-Content-Type-Options: nosniff");
header("X-XSS-Protection: 1; mode=block");
?>
