<?php
require_once 'config.php';
verifierConnexion();

$demande_id = $_GET['id'] ?? 0;
$user_id = $_SESSION['user_id'];
$role = $_SESSION['user_role'];

$stmt = $pdo->prepare("
    SELECT d.*, u.nom, u.prenom, u.email 
    FROM demandes d 
    JOIN utilisateurs u ON d.professeur_id = u.id 
    WHERE d.id = ?
");
$stmt->execute([$demande_id]);
$demande = $stmt->fetch();

if (!$demande) {
    header('Location: demandes.php');
    exit;
}

// Traitement des actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $commentaire = trim($_POST['commentaire'] ?? '');
    
    if ($role === 'Assistante' && $demande['statut_assistante'] === 'En attente') {
        if ($action === 'valider') {
            // Vérification des conflits uniquement pour les modifications
            if ($demande['type_demande'] === 'modification') {
                $stmt = $pdo->prepare("
                    SELECT COUNT(*) as count FROM emploi_temps 
                    WHERE date_seance = ? 
                    AND salle = ?
                    AND (
                        (heure_debut < ? AND heure_fin > ?) OR
                        (heure_debut < ? AND heure_fin > ?) OR
                        (heure_debut >= ? AND heure_fin <= ?)
                    )
                    AND disponible = FALSE
                ");
                $stmt->execute([
                    $demande['date_seance_nouvelle'],
                    $demande['salle_nouvelle'],
                    $demande['heure_fin_nouvelle'],
                    $demande['heure_debut_nouvelle'],
                    $demande['heure_fin_nouvelle'],
                    $demande['heure_debut_nouvelle'],
                    $demande['heure_debut_nouvelle'],
                    $demande['heure_fin_nouvelle']
                ]);
                $conflit = $stmt->fetch();
                
                if ($conflit['count'] > 0) {
                    $commentaire .= "\n\n[ATTENTION] Un conflit a été détecté dans l'emploi du temps mais validé manuellement.";
                }
            }
            
            $stmt = $pdo->prepare("UPDATE demandes SET statut_assistante = 'Validé', commentaire_assistante = ?, disponibilite_verifiee = TRUE, date_validation_assistante = NOW() WHERE id = ?");
            $stmt->execute([$commentaire, $demande_id]);
            
            // Notifier directeurs
            $stmt = $pdo->query("SELECT id FROM utilisateurs WHERE role = 'Directeur'");
            $directeurs = $stmt->fetchAll();
            foreach ($directeurs as $dir) {
                $msg = "Nouvelle demande validée par l'assistante (#" . $demande_id . ")";
                $stmt = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
                $stmt->execute([$dir['id'], $demande_id, $msg]);
            }
            
            // Notifier professeur
            $msg = "Votre demande #" . $demande_id . " a été validée par l'assistante";
            $stmt = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
            $stmt->execute([$demande['professeur_id'], $demande_id, $msg]);
            
            header('Location: detail_demande.php?id=' . $demande_id);
            exit;
        } elseif ($action === 'refuser') {
            $stmt = $pdo->prepare("UPDATE demandes SET statut_assistante = 'Refusé', commentaire_assistante = ?, disponibilite_verifiee = TRUE WHERE id = ?");
            $stmt->execute([$commentaire, $demande_id]);
            
            $msg = "Votre demande #" . $demande_id . " a été refusée par l'assistante";
            $stmt = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
            $stmt->execute([$demande['professeur_id'], $demande_id, $msg]);
            
            header('Location: detail_demande.php?id=' . $demande_id);
            exit;
        } elseif ($action === 'proposer_alternative') {
            $date_alternative = trim($_POST['date_alternative'] ?? '');
            $heure_debut_alternative = trim($_POST['heure_debut_alternative'] ?? '');
            $heure_fin_alternative = trim($_POST['heure_fin_alternative'] ?? '');
            $salle_alternative = trim($_POST['salle_alternative'] ?? '');
            
            if (empty($date_alternative) || empty($heure_debut_alternative) || empty($heure_fin_alternative) || empty($salle_alternative)) {
                $_SESSION['erreur_alternative'] = "Veuillez remplir tous les champs de l'alternative proposée.";
            } else {
                $stmt = $pdo->prepare("
                    UPDATE demandes SET 
                        statut_assistante = 'Alternative proposée',
                        commentaire_assistante = ?,
                        date_alternative = ?,
                        heure_debut_alternative = ?,
                        heure_fin_alternative = ?,
                        salle_alternative = ?
                    WHERE id = ?
                ");
                $stmt->execute([
                    $commentaire,
                    $date_alternative,
                    $heure_debut_alternative,
                    $heure_fin_alternative,
                    $salle_alternative,
                    $demande_id
                ]);
                
                $msg = "L'assistante a proposé une date alternative pour votre demande #" . $demande_id;
                $stmt = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
                $stmt->execute([$demande['professeur_id'], $demande_id, $msg]);
                
                header('Location: detail_demande.php?id=' . $demande_id);
                exit;
            }
        }
    } elseif ($role === 'Directeur' && $demande['statut_assistante'] === 'Validé' && $demande['statut_directeur'] === 'En attente') {
               if ($action === 'valider') {
            // Mise à jour du statut de la demande
            $stmt = $pdo->prepare("UPDATE demandes SET statut_directeur = 'Validé', commentaire_directeur = ?, date_validation_directeur = NOW() WHERE id = ?");
            $stmt->execute([$commentaire, $demande_id]);

            // === DÉBUT DU NOUVEAU CODE : Mise à jour de l'emploi du temps ===
            try {
                $pdo->beginTransaction();

                if ($demande['type_demande'] === 'annulation') {
                    // Annuler la séance originale
                    $stmt = $pdo->prepare("
                        UPDATE emploi_temps 
                        SET disponible = FALSE 
                        WHERE date_seance = ? 
                          AND heure_debut = ? 
                          AND heure_fin = ? 
                          AND salle = ? 
                          AND professeur_id = ? 
                          AND matiere = ? 
                          AND groupe = ?
                    ");
                    $stmt->execute([
                        $demande['date_seance_originale'],
                        $demande['heure_debut_originale'],
                        $demande['heure_fin_originale'],
                        $demande['salle_originale'],
                        $demande['professeur_id'],
                        $demande['matiere'],
                        $demande['groupe'] ?? null
                    ]);

                } elseif ($demande['type_demande'] === 'modification' || $demande['type_demande'] === 'ajout' || strtolower($demande['type_demande'] ?? '') === 'programmation') {
                    // Si c'est une modification, on annule d'abord l'ancienne séance (si elle existe)
                    if (!empty($demande['date_seance_originale']) && $demande['date_seance_originale'] !== '0000-00-00') {
                        $stmt = $pdo->prepare("
                            UPDATE emploi_temps 
                            SET disponible = FALSE 
                            WHERE date_seance = ? 
                              AND heure_debut = ? 
                              AND heure_fin = ? 
                              AND salle = ? 
                              AND professeur_id = ?
                        ");
                        $stmt->execute([
                            $demande['date_seance_originale'],
                            $demande['heure_debut_originale'],
                            $demande['heure_fin_originale'],
                            $demande['salle_originale'],
                            $demande['professeur_id']
                        ]);
                    }

                    // Puis on ajoute la nouvelle séance
                    $stmt = $pdo->prepare("
                        INSERT INTO emploi_temps (
                            date_seance, heure_debut, heure_fin, salle, 
                            professeur_id, matiere, groupe, disponible, date_creation
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, TRUE, NOW())
                    ");
                    $stmt->execute([
                        $demande['date_seance_nouvelle'],
                        $demande['heure_debut_nouvelle'],
                        $demande['heure_fin_nouvelle'],
                        $demande['salle_nouvelle'],
                        $demande['professeur_id'],
                        $demande['matiere'],
                        $demande['groupe'] ?? null
                    ]);
                }

                $pdo->commit();

            } catch (Exception $e) {
                $pdo->rollBack();
                error_log("Erreur mise à jour emploi du temps (demande #$demande_id) : " . $e->getMessage());
                // Optionnel : afficher un message d'erreur à l'utilisateur
                $_SESSION['erreur'] = "Erreur technique lors de la mise à jour de l'emploi du temps.";
            }
            // === FIN DU NOUVEAU CODE ===

            // Notification au professeur
            $msg = "Votre demande #" . $demande_id . " a été validée par le directeur et l'emploi du temps a été mis à jour.";
            $stmt = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
            $stmt->execute([$demande['professeur_id'], $demande_id, $msg]);

            header('Location: detail_demande.php?id=' . $demande_id);
            exit;
        }
        } elseif ($action === 'refuser') {
            $stmt = $pdo->prepare("UPDATE demandes SET statut_directeur = 'Refusé', commentaire_directeur = ? WHERE id = ?");
            $stmt->execute([$commentaire, $demande_id]);
            
            $msg = "Votre demande #" . $demande_id . " a été refusée par le directeur";
            $stmt = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
            $stmt->execute([$demande['professeur_id'], $demande_id, $msg]);
            
            header('Location: detail_demande.php?id=' . $demande_id);
            exit;
        }
    } elseif ($role === 'Professeur' && $demande['statut_assistante'] === 'Alternative proposée' && $demande['professeur_id'] == $user_id) {
        if ($action === 'accepter_alternative') {
            $stmt = $pdo->prepare("
                UPDATE demandes SET 
                    date_seance_nouvelle = date_alternative,
                    heure_debut_nouvelle = heure_debut_alternative,
                    heure_fin_nouvelle = heure_fin_alternative,
                    salle_nouvelle = salle_alternative,
                    statut_assistante = 'Validé',
                    date_validation_assistante = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$demande_id]);
            
            // Notifier directeurs
            $stmt = $pdo->query("SELECT id FROM utilisateurs WHERE role = 'Directeur'");
            $directeurs = $stmt->fetchAll();
            foreach ($directeurs as $dir) {
                $msg = "Le professeur a accepté l'alternative proposée pour la demande #" . $demande_id;
                $stmt = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
                $stmt->execute([$dir['id'], $demande_id, $msg]);
            }
            
            header('Location: detail_demande.php?id=' . $demande_id);
            exit;
        } elseif ($action === 'refuser_alternative') {
            $stmt = $pdo->prepare("UPDATE demandes SET statut_assistante = 'En attente' WHERE id = ?");
            $stmt->execute([$demande_id]);
            
            // Notifier l'assistante
            $stmt = $pdo->query("SELECT id FROM utilisateurs WHERE role = 'Assistante'");
            $assistantes = $stmt->fetchAll();
            foreach ($assistantes as $ass) {
                $msg = "Le professeur a refusé l'alternative proposée pour la demande #" . $demande_id;
                $stmt = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
                $stmt->execute([$ass['id'], $demande_id, $msg]);
            }
            
            header('Location: detail_demande.php?id=' . $demande_id);
            exit;
        }
    }


// Recharger la demande
$stmt = $pdo->prepare("
    SELECT d.*, u.nom, u.prenom, u.email 
    FROM demandes d 
    JOIN utilisateurs u ON d.professeur_id = u.id 
    WHERE d.id = ?
");
$stmt->execute([$demande_id]);
$demande = $stmt->fetch();

$conflits = [];
if ($role === 'Assistante' && $demande['statut_assistante'] === 'En attente' && $demande['type_demande'] === 'modification') {
    $stmt = $pdo->prepare("
        SELECT et.*, u.nom, u.prenom 
        FROM emploi_temps et
        LEFT JOIN utilisateurs u ON et.professeur_id = u.id
        WHERE et.date_seance = ? 
        AND et.salle = ?
        AND (
            (et.heure_debut < ? AND et.heure_fin > ?) OR
            (et.heure_debut < ? AND et.heure_fin > ?) OR
            (et.heure_debut >= ? AND et.heure_fin <= ?)
        )
        AND et.disponible = FALSE
    ");
    $stmt->execute([
        $demande['date_seance_nouvelle'],
        $demande['salle_nouvelle'],
        $demande['heure_fin_nouvelle'],
        $demande['heure_debut_nouvelle'],
        $demande['heure_fin_nouvelle'],
        $demande['heure_debut_nouvelle'],
        $demande['heure_debut_nouvelle'],
        $demande['heure_fin_nouvelle']
    ]);
    $conflits = $stmt->fetchAll();
}

// Trouver des créneaux alternatifs disponibles
$creneaux_disponibles = [];
if ($role === 'Assistante' && $demande['statut_assistante'] === 'En attente' && $demande['type_demande'] === 'modification' && count($conflits) > 0) {
    // Chercher des créneaux libres dans les 7 jours suivant la date demandée
    $date_debut = $demande['date_seance_nouvelle'];
    $date_fin = date('Y-m-d', strtotime($date_debut . ' +7 days'));
    
    $stmt = $pdo->prepare("
        SELECT DISTINCT date_seance, heure_debut, heure_fin, salle
        FROM emploi_temps
        WHERE date_seance BETWEEN ? AND ?
        AND disponible = TRUE
        ORDER BY date_seance, heure_debut
        LIMIT 10
    ");
    $stmt->execute([$date_debut, $date_fin]);
    $creneaux_disponibles = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails de la demande - Gestion des Séances</title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container">
        <div class="page-header">
            <h1>Détails de la demande #<?php echo $demande['id']; ?></h1>
            <a href="<?php echo BASE_URL; ?>/demandes.php" class="btn btn-secondary">Retour</a>
        </div>

        <?php if (isset($_SESSION['erreur_alternative'])): ?>
            <div class="alert alert-error">
                <?php 
                echo securiser($_SESSION['erreur_alternative']); 
                unset($_SESSION['erreur_alternative']);
                ?>
            </div>
        <?php endif; ?>

        <div class="detail-grid">
            <div class="card">
                <div class="card-header">
                    <h2>Informations générales</h2>
                </div>
                <div class="card-body">
                    <div class="detail-row">
                        <strong>Professeur:</strong>
                        <span><?php echo securiser($demande['prenom'] . ' ' . $demande['nom']); ?></span>
                    </div>
                    <div class="detail-row">
                        <strong>Email:</strong>
                        <span><?php echo securiser($demande['email']); ?></span>
                    </div>
                    <div class="detail-row">
                        <strong>Type de demande:</strong>
                        <span>
                            <?php 
                            if ($demande['type_demande'] === 'modification') {
                                echo '<span class="badge badge-info">Modification de séance</span>';
                            } elseif ($demande['type_demande'] === 'annulation') {
                                echo '<span class="badge badge-warning">Annulation de séance</span>';
                            } else {
                                echo '<span class="badge badge-success">Ajout de séance</span>';
                            }
                            ?>
                        </span>
                    </div>
                    <div class="detail-row">
                        <strong>Date de création:</strong>
                        <span><?php echo date('d/m/Y à H:i', strtotime($demande['date_creation'])); ?></span>
                    </div>
                </div>
            </div>

            <?php 
            $is_programming = (
                strtolower($demande['type_demande'] ?? '') === 'ajout' || 
                strtolower($demande['type_demande'] ?? '') === 'programmation' ||
                empty($demande['date_seance_originale']) || 
                $demande['date_seance_originale'] === '0000-00-00'
            );
            
            if (!$is_programming): 
            ?>
            <div class="card">
                <div class="card-header">
                    <h2>Séance originale</h2>
                </div>
                <div class="card-body">
                    <div class="detail-row">
                        <strong>Date:</strong>
                        <span><?php echo date('d/m/Y', strtotime($demande['date_seance_originale'])); ?></span>
                    </div>
                    <div class="detail-row">
                        <strong>Horaire:</strong>
                        <span><?php echo date('H:i', strtotime($demande['heure_debut_originale'])) . ' - ' . date('H:i', strtotime($demande['heure_fin_originale'])); ?></span>
                    </div>
                    <div class="detail-row">
                        <strong>Salle:</strong>
                        <span><?php echo securiser($demande['salle_originale']); ?></span>
                    </div>
                    <div class="detail-row">
                        <strong>Matière:</strong>
                        <span><?php echo securiser($demande['matiere']); ?></span>
                    </div>
                    <div class="detail-row">
                        <strong>Niveau:</strong>
                        <span><?php echo securiser($demande['niveau']); ?></span>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if (strtolower($demande['type_demande'] ?? '') === 'modification' || $is_programming): ?>
            <div class="card">
                <div class="card-header">
                    <h2><?php echo $is_programming ? 'Nouveau créneau souhaité' : 'Nouvelle séance demandée'; ?></h2>
                </div>
                <div class="card-body">
                    <div class="detail-row">
                        <strong>Date:</strong>
                        <span><?php echo date('d/m/Y', strtotime($demande['date_seance_nouvelle'])); ?></span>
                    </div>
                    <div class="detail-row">
                        <strong>Horaire:</strong>
                        <span><?php echo date('H:i', strtotime($demande['heure_debut_nouvelle'])) . ' - ' . date('H:i', strtotime($demande['heure_fin_nouvelle'])); ?></span>
                    </div>
                    <div class="detail-row">
                        <strong>Salle:</strong>
                        <span><?php echo securiser($demande['salle_nouvelle']); ?></span>
                    </div>
                    <?php if ($is_programming): ?>
                    <div class="detail-row">
                        <strong>Matière:</strong>
                        <span><?php echo securiser($demande['matiere']); ?></span>
                    </div>
                    <div class="detail-row">
                        <strong>Niveau:</strong>
                        <span><?php echo securiser($demande['niveau']); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <div class="card full-width">
                <div class="card-header">
                    <h2>Motif de la demande</h2>
                </div>
                <div class="card-body">
                    <p style="line-height: 1.6;"><?php echo nl2br(securiser($demande['raison'])); ?></p>
                </div>
            </div>

            <?php if (!empty($demande['piece_jointe'])): ?>
            <div class="card full-width">
                <div class="card-header" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%);">
                    <h2 style="color: white;">Pièce justificative</h2>
                </div>
                <div class="card-body">
                    <div style="display: flex; align-items: center; gap: 15px; padding: 15px; background: #f0fdf4; border-radius: 8px; border: 1px solid #86efac;">
                        <div style="font-size: 48px;">📄</div>
                        <div style="flex: 1;">
                            <p style="margin: 0; font-weight: 600; color: #065f46;">Document justificatif déposé par le professeur</p>
                            <p style="margin: 5px 0 0 0; font-size: 14px; color: #047857;">Cliquez ci-dessous pour consulter la pièce jointe.</p>
                        </div>
                        <div style="display: flex; gap: 10px;">
                            <a href="<?php echo BASE_URL; ?>/uploads/<?php echo $demande['piece_jointe']; ?>" target="_blank" class="btn btn-success btn-sm">Visualiser</a>
                            <a href="<?php echo BASE_URL; ?>/uploads/<?php echo $demande['piece_jointe']; ?>" download class="btn btn-primary btn-sm">Télécharger</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($demande['statut_assistante'] === 'Alternative proposée' && $demande['date_alternative']): ?>
            <div class="card full-width">
                <div class="card-header" style="background: linear-gradient(135deg, #f59e0b 0%, #f97316 100%);">
                    <h2 style="color: white;">Alternative proposée par l'assistante</h2>
                </div>
                <div class="card-body">
                    <p style="color: #b45309; font-weight: bold; margin-bottom: 15px;">
                        Une date alternative a été proposée car la date demandée n'était pas disponible:
                    </p>
                    <div style="background: #fef3c7; padding: 20px; border-radius: 8px; border-left: 4px solid #f59e0b;">
                        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                            <div>
                                <strong>Date:</strong> <?php echo date('d/m/Y', strtotime($demande['date_alternative'])); ?>
                            </div>
                            <div>
                                <strong>Horaire:</strong> <?php echo date('H:i', strtotime($demande['heure_debut_alternative'])) . ' - ' . date('H:i', strtotime($demande['heure_fin_alternative'])); ?>
                            </div>
                            <div>
                                <strong>Salle:</strong> <?php echo securiser($demande['salle_alternative']); ?>
                            </div>
                        </div>
                    </div>
                    
                    <?php if ($role === 'Professeur' && $demande['professeur_id'] == $user_id): ?>
                        <div style="margin-top: 20px; display: flex; gap: 10px;">
                            <form method="POST" style="display: inline;">
                                <button type="submit" name="action" value="accepter_alternative" class="btn btn-success">
                                    Accepter l'alternative
                                </button>
                            </form>
                            <form method="POST" style="display: inline;">
                                <button type="submit" name="action" value="refuser_alternative" class="btn btn-danger">
                                    Refuser l'alternative
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($role === 'Assistante' && $demande['statut_assistante'] === 'En attente' && $demande['type_demande'] === 'modification' && count($conflits) > 0): ?>
                <div class="card full-width">
                    <div class="card-header" style="background: linear-gradient(135deg, #ff6b6b 0%, #ee5a6f 100%);">
                        <h2 style="color: white;">Conflits détectés dans l'emploi du temps</h2>
                    </div>
                    <div class="card-body">
                        <p style="color: #d32f2f; font-weight: bold; margin-bottom: 15px;">
                            La salle <?php echo securiser($demande['salle_nouvelle']); ?> est déjà occupée aux horaires demandés:
                        </p>
                        <?php foreach ($conflits as $conf): ?>
                            <div style="background: #ffebee; padding: 15px; margin-bottom: 10px; border-left: 4px solid #d32f2f; border-radius: 4px;">
                                <strong>Date:</strong> <?php echo date('d/m/Y', strtotime($conf['date_seance'])); ?><br>
                                <strong>Horaire:</strong> <?php echo date('H:i', strtotime($conf['heure_debut'])) . ' - ' . date('H:i', strtotime($conf['heure_fin'])); ?><br>
                                <?php if ($conf['professeur_id']): ?>
                                    <strong>Professeur:</strong> <?php echo securiser($conf['prenom'] . ' ' . $conf['nom']); ?><br>
                                <?php endif; ?>
                                <?php if ($conf['matiere']): ?>
                                    <strong>Matière:</strong> <?php echo securiser($conf['matiere']); ?><br>
                                <?php endif; ?>
                                <?php if ($conf['groupe']): ?>
                                    <strong>Groupe:</strong> <?php echo securiser($conf['groupe']); ?>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                        
                        <?php if (count($creneaux_disponibles) > 0): ?>
                            <div style="margin-top: 20px; padding: 15px; background: #e8f5e9; border-radius: 8px;">
                                <h4 style="color: #2e7d32; margin-top: 0;">Créneaux disponibles suggérés:</h4>
                                <ul style="list-style: none; padding: 0;">
                                    <?php foreach ($creneaux_disponibles as $creneau): ?>
                                        <li style="padding: 8px; margin: 5px 0; background: white; border-radius: 4px; cursor: pointer;" onclick="remplirAlternative('<?php echo $creneau['date_seance']; ?>', '<?php echo $creneau['heure_debut']; ?>', '<?php echo $creneau['heure_fin']; ?>', '<?php echo $creneau['salle']; ?>')">
                                            <?php echo date('d/m/Y', strtotime($creneau['date_seance'])); ?> - 
                                            <?php echo date('H:i', strtotime($creneau['heure_debut'])) . '-' . date('H:i', strtotime($creneau['heure_fin'])); ?> - 
                                            Salle <?php echo securiser($creneau['salle']); ?>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                                <p style="font-size: 12px; color: #666; margin-top: 10px;">Cliquez sur un créneau pour le sélectionner automatiquement</p>
                            </div>
                        <?php endif; ?>
                        
                        <p style="color: #666; margin-top: 15px; font-style: italic;">
                            Vous pouvez tout de même valider la demande ou proposer une alternative ci-dessous.
                        </p>
                    </div>
                </div>
            <?php elseif ($role === 'Assistante' && $demande['statut_assistante'] === 'En attente' && $demande['type_demande'] === 'modification'): ?>
                <div class="card full-width">
                    <div class="card-header" style="background: linear-gradient(135deg, #4caf50 0%, #66bb6a 100%);">
                        <h2 style="color: white;">Aucun conflit détecté</h2>
                    </div>
                    <div class="card-body">
                        <p style="color: #2e7d32; font-weight: bold;">
                            La salle <?php echo securiser($demande['salle_nouvelle']); ?> est disponible le <?php echo date('d/m/Y', strtotime($demande['date_seance_nouvelle'])); ?> 
                            de <?php echo date('H:i', strtotime($demande['heure_debut_nouvelle'])); ?> à <?php echo date('H:i', strtotime($demande['heure_fin_nouvelle'])); ?>.
                        </p>
                    </div>
                </div>
            <?php endif; ?>

            <div class="card full-width">
                <div class="card-header">
                    <h2>Statut de validation</h2>
                </div>
                <div class="card-body">
                    <div class="timeline">
                        <div class="timeline-item <?php echo ($demande['statut_assistante'] !== 'En attente') ? 'completed' : ''; ?>">
                            <div class="timeline-marker"></div>
                            <div class="timeline-content">
                                <h3>Assistante - Vérification disponibilité</h3>
                                <p>
                                    <?php
                                    if ($demande['statut_assistante'] === 'Validé') {
                                        echo '<span class="badge badge-success">Validé</span>';
                                        if ($demande['date_validation_assistante']) {
                                            echo ' le ' . date('d/m/Y à H:i', strtotime($demande['date_validation_assistante']));
                                        }
                                        if ($demande['disponibilite_verifiee']) {
                                            echo '<br><small style="color: #666;">Disponibilité vérifiée dans l\'emploi du temps</small>';
                                        }
                                    } elseif ($demande['statut_assistante'] === 'Refusé') {
                                        echo '<span class="badge badge-danger">Refusé</span>';
                                    } elseif ($demande['statut_assistante'] === 'Alternative proposée') {
                                        echo '<span class="badge badge-warning">Alternative proposée</span>';
                                    } else {
                                        echo '<span class="badge badge-warning">En attente</span>';
                                    }
                                    ?>
                                </p>
                                <?php if ($demande['commentaire_assistante']): ?>
                                    <p><strong>Commentaire:</strong> <?php echo nl2br(securiser($demande['commentaire_assistante'])); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="timeline-item <?php echo ($demande['statut_directeur'] !== 'En attente') ? 'completed' : ''; ?>">
                            <div class="timeline-marker"></div>
                            <div class="timeline-content">
                                <h3>Directeur - Validation finale</h3>
                                <p>
                                    <?php
                                    if ($demande['statut_directeur'] === 'Validé') {
                                        echo '<span class="badge badge-success">Validé</span>';
                                        if ($demande['date_validation_directeur']) {
                                            echo ' le ' . date('d/m/Y à H:i', strtotime($demande['date_validation_directeur']));
                                        }
                                    } elseif ($demande['statut_directeur'] === 'Refusé') {
                                        echo '<span class="badge badge-danger">Refusé</span>';
                                    } else {
                                        echo '<span class="badge badge-warning">En attente</span>';
                                    }
                                    ?>
                                </p>
                                <?php if ($demande['commentaire_directeur']): ?>
                                    <p><strong>Commentaire:</strong> <?php echo nl2br(securiser($demande['commentaire_directeur'])); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php if ($role === 'Assistante' && $demande['statut_assistante'] === 'En attente'): ?>
                <div class="card full-width">
                    <div class="card-header">
                        <h2>Actions</h2>
                    </div>
                    <div class="card-body">
                        <form method="POST" class="form">
                            <div class="form-group">
                                <label for="commentaire">Commentaire (optionnel)</label>
                                <textarea id="commentaire" name="commentaire" rows="3"></textarea>
                            </div>
                            <div class="form-actions">
                                <button type="submit" name="action" value="valider" class="btn btn-success">Valider</button>
                                <button type="submit" name="action" value="refuser" class="btn btn-danger">Refuser</button>
                                <?php if ($demande['type_demande'] === 'modification'): ?>
                                    <button type="button" class="btn btn-warning" onclick="document.getElementById('alternative_form').style.display='block'">Proposer une alternative</button>
                                <?php endif; ?>
                            </div>
                        </form>
                        
                        <?php if ($demande['type_demande'] === 'modification'): ?>
                        <div id="alternative_form" style="display: none; margin-top: 20px; padding: 20px; background: #fef3c7; border-radius: 8px;">
                            <h3 style="margin-top: 0;">Proposer une date alternative</h3>
                            <form method="POST">
                                <input type="hidden" name="action" value="proposer_alternative">
                                <div class="form-group">
                                    <label for="commentaire_alt">Commentaire explicatif</label>
                                    <textarea id="commentaire_alt" name="commentaire" rows="2" placeholder="Expliquez pourquoi vous proposez cette alternative..."></textarea>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="date_alternative">Nouvelle date *</label>
                                        <input type="date" id="date_alternative" name="date_alternative" required class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label for="heure_debut_alternative">Heure début *</label>
                                        <input type="time" id="heure_debut_alternative" name="heure_debut_alternative" required class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label for="heure_fin_alternative">Heure fin *</label>
                                        <input type="time" id="heure_fin_alternative" name="heure_fin_alternative" required class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="salle_alternative">Salle *</label>
                                    <input type="text" id="salle_alternative" name="salle_alternative" required class="form-control" placeholder="Ex: B205">
                                </div>
                                <div class="form-actions">
                                    <button type="button" class="btn btn-secondary" onclick="document.getElementById('alternative_form').style.display='none'">Annuler</button>
                                    <button type="submit" class="btn btn-primary">Soumettre l'alternative</button>
                                </div>
                            </form>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php elseif ($role === 'Directeur' && $demande['statut_assistante'] === 'Validé' && $demande['statut_directeur'] === 'En attente'): ?>
                <div class="card full-width">
                    <div class="card-header">
                        <h2>Actions</h2>
                    </div>
                    <div class="card-body">
                        <form method="POST" class="form">
                            <div class="form-group">
                                <label for="commentaire">Commentaire (optionnel)</label>
                                <textarea id="commentaire" name="commentaire" rows="3"></textarea>
                            </div>
                            <div class="form-actions">
                                <button type="submit" name="action" value="valider" class="btn btn-success">Valider</button>
                                <button type="submit" name="action" value="refuser" class="btn btn-danger">Refuser</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <style>
        .detail-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 24px;
            margin-top: 24px;
        }
        
        .card.full-width {
            grid-column: 1 / -1;
        }
        
        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .detail-row:last-child {
            border-bottom: none;
        }
        
        .detail-row strong {
            color: #64748b;
            font-weight: 600;
        }
    </style>

    <script>
        function remplirAlternative(date, heureDebut, heureFin, salle) {
            document.getElementById('alternative_form').style.display = 'block';
            document.getElementById('date_alternative').value = date;
            document.getElementById('heure_debut_alternative').value = heureDebut;
            document.getElementById('heure_fin_alternative').value = heureFin;
            document.getElementById('salle_alternative').value = salle;
            window.scrollTo(0, document.getElementById('alternative_form').offsetTop);
        }
    </script>
</body>
</html>
