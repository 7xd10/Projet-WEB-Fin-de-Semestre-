===========================================
GESTION DES SÉANCES UNIVERSITAIRES
Application Web PHP/MySQL
===========================================

INSTALLATION RAPIDE (3 ÉTAPES)
===========================================

ÉTAPE 1 : IMPORTER LA BASE DE DONNÉES
--------------------------------------
1. Démarrez XAMPP (Apache + MySQL)
2. Ouvrez phpMyAdmin : http://localhost/phpmyadmin/
3. Si la base "gestion_seances" existe déjà, supprimez-la :
   - Cliquez sur "gestion_seances" dans la colonne gauche
   - Onglet "Opérations" → "Supprimer la base de données"
4. Créez la nouvelle base :
   - Cliquez sur "Nouvelle base de données"
   - Nom : gestion_seances
   - Interclassement : utf8mb4_general_ci
   - Cliquez "Créer"
5. Importez database.sql :
   - Cliquez sur "gestion_seances"
   - Onglet "Importer"
   - Choisir le fichier "database.sql"
   - Cliquez "Exécuter"

ÉTAPE 2 : PLACER LES FICHIERS
------------------------------
Copiez tous les fichiers dans : C:\xampp\htdocs\gestion-seances\

ÉTAPE 3 : ACCÉDER À L'APPLICATION
----------------------------------
Ouvrez : http://localhost/gestion-seances/
ou https://localhost/gestion-seances/ (si HTTPS configuré)

===========================================
FONCTIONNALITÉS PRINCIPALES
===========================================

✓ PROFESSEUR 
  - Créer des demandes de changement de séances avec dates complètes
  - Suivre l'état de ses demandes
  - Consulter le calendrier des séances
  - Recevoir des notifications
  - Modifier son profil (email, mot de passe)

✓ ASSISTANTE 
  - Voir toutes les demandes
  - Consulter le calendrier complet des séances
  - Vérifier les disponibilités dans l'emploi du temps
  - Détecter automatiquement les conflits de salles/horaires
  - Valider ou refuser les demandes (1ère validation)
  - Modifier son profil

✓ DIRECTEUR 
  - Validation finale des demandes validées par l'assistante
  - Vue d'ensemble des demandes
  - Consulter le calendrier des séances
  - Modifier son profil

===========================================
NOUVEAUTÉS DE CETTE VERSION
===========================================

✓ Design moderne et professionnel pleine largeur
✓ Page de connexion avec dégradés violet/bleu élégants
✓ Dates complètes avec calendrier (DATE et TIME)
✓ Vérification automatique des conflits dans l'emploi du temps
✓ Page calendrier pour visualiser toutes les séances
✓ Table emploi_temps pour gérer le calendrier des séances
✓ Alertes visuelles en cas de conflit détecté
✓ Page profil pour modifier email et mot de passe
✓ Option "Afficher mot de passe" sur la page de connexion
✓ Alerte de sécurité pour mots de passe faibles
✓ Interface responsive et professionnelle
✓ Système de notifications fonctionnel
✓ Autocomplete désactivé pour la sécurité

===========================================
WORKFLOW COMPLET
===========================================

1. PROFESSEUR crée une demande
   - Sélectionne la date et heure actuelle de la séance
   - Sélectionne la nouvelle date et heure souhaitée
   - Indique la salle et le motif
   
2. ASSISTANTE reçoit notification
   - Vérifie la disponibilité dans l'emploi du temps
   - Consulte le calendrier pour voir les conflits éventuels
   - Voit les conflits éventuels (salle occupée)
   - Valide ou refuse la demande
   
3. DIRECTEUR (si validé par assistante)
   - Reçoit notification
   - Consulte les détails et le calendrier
   - Valide ou refuse la demande finale
   
4. PROFESSEUR reçoit notification du résultat

===========================================
STRUCTURE DES FICHIERS
===========================================

gestion-seances/
├── database.sql          (UNIQUE fichier SQL - tout inclus)
├── config.php           (configuration base de données)
├── login.php            (page de connexion moderne)
├── logout.php           (déconnexion)
├── index.php            (tableau de bord avec statistiques)
├── nouvelle_demande.php (création demande avec dates complètes)
├── demandes.php         (liste des demandes)
├── detail_demande.php   (détails + vérification conflits)
├── calendrier.php       (calendrier complet des séances)
├── notifications.php    (notifications utilisateur)
├── profil.php          (modification email/mot de passe)
├── style.css           (design moderne complet)
└── README.txt          (ce fichier)

===========================================
BASE DE DONNÉES
===========================================

4 TABLES PRINCIPALES :

1. utilisateurs
   - Gestion des comptes (Professeur, Assistante, Directeur)
   - Mots de passe hashés en MD5
   - 6 utilisateurs de test (3 professeurs, 2 assistantes, 1 directeur)

2. demandes
   - Anciennes et nouvelles séances avec DATE et TIME
   - Statuts de validation (assistante + directeur)
   - Vérification de disponibilité
   - Traçabilité complète

3. emploi_temps
   - Calendrier complet des séances existantes
   - Vérification des disponibilités
   - Détection automatique des conflits

4. notifications
   - Notifications en temps réel
   - Système de lecture/non-lu

===========================================
TECHNOLOGIES UTILISÉES
===========================================

✓ PHP 7+ (pur, sans framework)
✓ MySQL avec PDO
✓ HTML5 (formulaires modernes)
✓ CSS3 (dégradés, animations, responsive)
✓ JavaScript minimal (uniquement pour toggle password)

===========================================
SÉCURITÉ
===========================================

✓ Mots de passe hashés (MD5)
✓ Sessions PHP sécurisées
✓ Requêtes préparées (PDO) contre SQL injection
✓ Fonction htmlspecialchars() sur tous les affichages
✓ Validation HTML5 des formulaires
✓ Autocomplete désactivé sur les champs sensibles
✓ Alerte automatique pour mots de passe faibles

===========================================
EN CAS DE PROBLÈME
===========================================

PROBLÈME : "Connexion impossible"
SOLUTION :
1. Vérifiez que MySQL est démarré dans XAMPP
2. Réimportez database.sql
3. Vérifiez vos identifiants de connexion
4. Pas d'espaces avant/après

PROBLÈME : "Page blanche"
SOLUTION :
1. Vérifiez que Apache est démarré
2. Vérifiez le chemin : C:\xampp\htdocs\gestion-seances\
3. Accédez via http://localhost/gestion-seances/

PROBLÈME : "Erreur base de données"
SOLUTION :
1. Ouvrez config.php
2. Vérifiez : DB_HOST = 'localhost', DB_NAME = 'gestion_seances'
3. DB_USER = 'root', DB_PASS = '' (vide par défaut XAMPP)

PROBLÈME : "Notifications ne fonctionnent pas"
SOLUTION :
1. Vérifiez que la table notifications existe
2. Réimportez database.sql
3. Actualisez la page

===========================================
SUPPORT
===========================================

Cette application a été développée pour l'Université Euromed de Fès.
Tous les fichiers sont autonomes et ne nécessitent aucune configuration
XAMPP particulière.

Design moderne et professionnel optimisé pour tous les écrans.

===========================================
