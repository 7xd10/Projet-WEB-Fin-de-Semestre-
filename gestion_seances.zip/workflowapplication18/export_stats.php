<?php
require_once 'config.php';
verifierRole(['Directeur', 'Assistante']);

$format = $_GET['format'] ?? 'excel';
$periode = (int)($_GET['periode'] ?? 30);
$date_debut = date('Y-m-d', strtotime("-{$periode} days"));

$stmt = $pdo->prepare("
    SELECT 
        d.id,
        d.date_creation,
        u.nom as prof_nom,
        u.prenom as prof_prenom,
        d.type_demande,
        d.date_seance_originale,
        CONCAT(d.heure_debut_originale, ' - ', d.heure_fin_originale) as horaire_original,
        d.salle_originale,
        d.date_seance_nouvelle,
        CONCAT(d.heure_debut_nouvelle, ' - ', d.heure_fin_nouvelle) as horaire_nouveau,
        d.salle_nouvelle,
        d.raison as motif,
        d.statut_assistante,
        d.statut_directeur,
        d.date_validation_assistante,
        d.date_validation_directeur
    FROM demandes d
    JOIN utilisateurs u ON d.professeur_id = u.id
    WHERE d.date_creation >= ?
    ORDER BY d.date_creation DESC
");
$stmt->execute([$date_debut]);
$demandes = $stmt->fetchAll();

if ($format === 'excel') {
    // Export CSV (compatible Excel)
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="statistiques_demandes_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    // BOM UTF-8 pour Excel
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    
    // En-têtes
    fputcsv($output, [
        'ID', 'Date création', 'Professeur', 'Type', 
        'Date originale', 'Horaire original', 'Salle originale',
        'Date nouvelle', 'Horaire nouveau', 'Salle nouvelle',
        'Motif', 'Statut assistante', 'Statut directeur', 
        'Date validation assistante', 'Date validation directeur'
    ], ';');
    
    // Données
    foreach ($demandes as $d) {
        fputcsv($output, [
            $d['id'],
            date('d/m/Y H:i', strtotime($d['date_creation'])),
            $d['prof_prenom'] . ' ' . $d['prof_nom'],
            $d['type_demande'] === 'modification' ? 'Modification' : 'Annulation',
            $d['date_seance_originale'] ? date('d/m/Y', strtotime($d['date_seance_originale'])) : '',
            $d['horaire_original'] ?? '',
            $d['salle_originale'] ?? '',
            $d['date_seance_nouvelle'] ? date('d/m/Y', strtotime($d['date_seance_nouvelle'])) : '',
            $d['horaire_nouveau'] ?? '',
            $d['salle_nouvelle'] ?? '',
            $d['motif'] ?? '',
            $d['statut_assistante'],
            $d['statut_directeur'],
            $d['date_validation_assistante'] ? date('d/m/Y H:i', strtotime($d['date_validation_assistante'])) : '',
            $d['date_validation_directeur'] ? date('d/m/Y H:i', strtotime($d['date_validation_directeur'])) : ''
        ], ';');
    }
    
    fclose($output);
    logActivity($_SESSION['user_id'], 'EXPORT_STATS_EXCEL', 'demandes', null, ['periode' => $periode]);
    exit;
}
?>
