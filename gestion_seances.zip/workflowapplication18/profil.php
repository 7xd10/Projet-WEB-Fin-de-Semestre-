<?php
require_once 'config.php';
verifierConnexion();

$succes = '';
$erreur = '';

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if (!isset($_POST['csrf_token']) || !verifierTokenCSRF($_POST['csrf_token'])) {
        $erreur = "Erreur de validation du formulaire. Veuillez réessayer.";
    } else {
        if ($action === 'modifier_email') {
            $nouvel_email = trim($_POST['email'] ?? '');
            $mot_de_passe_actuel = $_POST['mot_de_passe_actuel'] ?? '';
            
            if (empty($nouvel_email) || empty($mot_de_passe_actuel)) {
                $erreur = "Veuillez remplir tous les champs.";
            } else {
                $stmt = $pdo->prepare("SELECT mot_de_passe FROM utilisateurs WHERE id = ?");
                $stmt->execute([$user_id]);
                $user = $stmt->fetch();
                
                if (md5($mot_de_passe_actuel) !== $user['mot_de_passe']) {
                    $erreur = "Mot de passe actuel incorrect.";
                } else {
                    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM utilisateurs WHERE email = ? AND id != ?");
                    $stmt->execute([$nouvel_email, $user_id]);
                    $existe = $stmt->fetch();
                    
                    if ($existe['count'] > 0) {
                        $erreur = "Cet email est déjà utilisé.";
                    } else {
                        $stmt = $pdo->prepare("UPDATE utilisateurs SET email = ? WHERE id = ?");
                        if ($stmt->execute([$nouvel_email, $user_id])) {
                            $_SESSION['user_email'] = $nouvel_email;
                            logActivity($user_id, 'MODIFICATION_EMAIL', 'utilisateurs', $user_id);
                            $succes = "Email modifié avec succès.";
                        } else {
                            $erreur = "Une erreur est survenue.";
                        }
                    }
                }
            }
        } 
        elseif ($action === 'modifier_telephone') {
            $nouveau_telephone = trim($_POST['telephone'] ?? '');
            $mot_de_passe_actuel = $_POST['mot_de_passe_actuel_tel'] ?? '';
            
            if (empty($mot_de_passe_actuel)) {
                $erreur = "Le mot de passe est requis pour modifier le téléphone.";
            } else {
                $stmt = $pdo->prepare("SELECT mot_de_passe FROM utilisateurs WHERE id = ?");
                $stmt->execute([$user_id]);
                $user = $stmt->fetch();
                
                if (md5($mot_de_passe_actuel) !== $user['mot_de_passe']) {
                    $erreur = "Mot de passe incorrect.";
                } else {
                    if (!empty($nouveau_telephone) && !preg_match('/^[\d\s\-\+()]+$/', $nouveau_telephone)) {
                        $erreur = "Format de téléphone invalide.";
                    } else {
                        $stmt = $pdo->prepare("UPDATE utilisateurs SET telephone = ? WHERE id = ?");
                        if ($stmt->execute([$nouveau_telephone, $user_id])) {
                            logActivity($user_id, 'MODIFICATION_TELEPHONE', 'utilisateurs', $user_id);
                            $succes = "Numéro de téléphone modifié avec succès.";
                        } else {
                            $erreur = "Une erreur est survenue.";
                        }
                    }
                }
            }
        }
        elseif ($action === 'modifier_bureau') {
            $nouveau_bureau = trim($_POST['bureau'] ?? '');
            $mot_de_passe_actuel = $_POST['mot_de_passe_actuel_bureau'] ?? '';
            
            if (empty($mot_de_passe_actuel)) {
                $erreur = "Le mot de passe est requis pour modifier le bureau.";
            } else {
                $stmt = $pdo->prepare("SELECT mot_de_passe FROM utilisateurs WHERE id = ?");
                $stmt->execute([$user_id]);
                $user = $stmt->fetch();
                
                if (md5($mot_de_passe_actuel) !== $user['mot_de_passe']) {
                    $erreur = "Mot de passe incorrect.";
                } else {
                    $stmt = $pdo->prepare("UPDATE utilisateurs SET bureau = ? WHERE id = ?");
                    if ($stmt->execute([$nouveau_bureau, $user_id])) {
                        logActivity($user_id, 'MODIFICATION_BUREAU', 'utilisateurs', $user_id);
                        $succes = "Bureau modifié avec succès.";
                    } else {
                        $erreur = "Une erreur est survenue.";
                    }
                }
            }
        }
        elseif ($action === 'modifier_mot_de_passe') {
            $mot_de_passe_actuel = $_POST['mot_de_passe_actuel_mdp'] ?? '';
            $nouveau_mot_de_passe = $_POST['nouveau_mot_de_passe'] ?? '';
            $confirmer_mot_de_passe = $_POST['confirmer_mot_de_passe'] ?? '';
            
            if (empty($mot_de_passe_actuel) || empty($nouveau_mot_de_passe) || empty($confirmer_mot_de_passe)) {
                $erreur = "Veuillez remplir tous les champs.";
            } elseif ($nouveau_mot_de_passe !== $confirmer_mot_de_passe) {
                $erreur = "Les mots de passe ne correspondent pas.";
            } elseif (strlen($nouveau_mot_de_passe) < 8) {
                $erreur = "Le mot de passe doit contenir au moins 8 caractères.";
            } else {
                $stmt = $pdo->prepare("SELECT mot_de_passe FROM utilisateurs WHERE id = ?");
                $stmt->execute([$user_id]);
                $user = $stmt->fetch();
                
                if (md5($mot_de_passe_actuel) !== $user['mot_de_passe']) {
                    $erreur = "Mot de passe actuel incorrect.";
                } else {
                    $nouveau_hash = md5($nouveau_mot_de_passe);
                    $stmt = $pdo->prepare("UPDATE utilisateurs SET mot_de_passe = ? WHERE id = ?");
                    if ($stmt->execute([$nouveau_hash, $user_id])) {
                        logActivity($user_id, 'MODIFICATION_MOT_DE_PASSE', 'utilisateurs', $user_id);
                        $succes = "Mot de passe modifié avec succès.";
                    } else {
                        $erreur = "Une erreur est survenue.";
                    }
                }
            }
        }
    }
}

$stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
$stmt->execute([$user_id]);
$utilisateur = $stmt->fetch();

$csrf_token = genererTokenCSRF();
$page_title = 'Mon Profil';
include 'includes/header.php';
?>

    <div class="container" style="margin-top: 40px;">
        <!-- Added independent profile update logic for employees -->
        <div class="page-header">
            <h1><?php echo $page_title; ?></h1>
            <p>Gérez vos informations personnelles de manière indépendante</p>
        </div>

        <?php if ($succes): ?>
            <div class="alert alert-success"><?php echo securiser($succes); ?></div>
        <?php endif; ?>

        <?php if ($erreur): ?>
            <div class="alert alert-error"><?php echo securiser($erreur); ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h2>Informations personnelles</h2>
            </div>
            <div class="card-body">
                <div class="info-row">
                    <strong>Nom complet:</strong>
                    <?php echo securiser($utilisateur['prenom'] . ' ' . $utilisateur['nom']); ?>
                </div>
                <div class="info-row">
                    <strong>Matricule:</strong>
                    <?php echo securiser($utilisateur['matricule']); ?>
                </div>
                <div class="info-row">
                    <strong>Rôle:</strong>
                    <span class="badge badge-primary"><?php echo securiser($utilisateur['role']); ?></span>
                </div>
            </div>
        </div>

        <!-- Modification Email -->
        <div class="card">
            <div class="card-header">
                <h2>Modifier l'email</h2>
            </div>
            <div class="card-body">
                <form method="POST" class="form">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    <input type="hidden" name="action" value="modifier_email">

                    <div class="form-group">
                        <label for="email">Nouvel email</label>
                        <input type="email" id="email" name="email" value="<?php echo securiser($utilisateur['email']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="mot_de_passe_actuel">Mot de passe actuel</label>
                        <input type="password" id="mot_de_passe_actuel" name="mot_de_passe_actuel" required>
                    </div>

                    <button type="submit" class="btn btn-primary">Modifier l'email</button>
                </form>
            </div>
        </div>

        <!-- Modification Téléphone -->
        <div class="card">
            <div class="card-header">
                <h2>Modifier le téléphone</h2>
            </div>
            <div class="card-body">
                <form method="POST" class="form">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    <input type="hidden" name="action" value="modifier_telephone">

                    <div class="form-group">
                        <label for="telephone">Numéro de téléphone</label>
                        <input type="tel" id="telephone" name="telephone" value="<?php echo securiser($utilisateur['telephone'] ?? ''); ?>" placeholder="0612345678">
                    </div>

                    <div class="form-group">
                        <label for="mot_de_passe_actuel_tel">Mot de passe actuel</label>
                        <input type="password" id="mot_de_passe_actuel_tel" name="mot_de_passe_actuel_tel" required>
                    </div>

                    <button type="submit" class="btn btn-primary">Modifier le téléphone</button>
                </form>
            </div>
        </div>

        <!-- Modification Bureau -->
        <div class="card">
            <div class="card-header">
                <h2>Modifier le bureau</h2>
            </div>
            <div class="card-body">
                <form method="POST" class="form">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    <input type="hidden" name="action" value="modifier_bureau">

                    <div class="form-group">
                        <label for="bureau">Bureau</label>
                        <input type="text" id="bureau" name="bureau" value="<?php echo securiser($utilisateur['bureau'] ?? ''); ?>" placeholder="ex: B104">
                    </div>

                    <div class="form-group">
                        <label for="mot_de_passe_actuel_bureau">Mot de passe actuel</label>
                        <input type="password" id="mot_de_passe_actuel_bureau" name="mot_de_passe_actuel_bureau" required>
                    </div>

                    <button type="submit" class="btn btn-primary">Modifier le bureau</button>
                </form>
            </div>
        </div>

        <!-- Modification Mot de passe -->
        <div class="card">
            <div class="card-header">
                <h2>Modifier le mot de passe</h2>
            </div>
            <div class="card-body">
                <form method="POST" class="form">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    <input type="hidden" name="action" value="modifier_mot_de_passe">

                    <div class="form-group">
                        <label for="mot_de_passe_actuel_mdp">Mot de passe actuel</label>
                        <input type="password" id="mot_de_passe_actuel_mdp" name="mot_de_passe_actuel_mdp" required>
                    </div>

                    <div class="form-group">
                        <label for="nouveau_mot_de_passe">Nouveau mot de passe</label>
                        <input type="password" id="nouveau_mot_de_passe" name="nouveau_mot_de_passe" required minlength="8">
                        <small>Minimum 8 caractères</small>
                    </div>

                    <div class="form-group">
                        <label for="confirmer_mot_de_passe">Confirmer le mot de passe</label>
                        <input type="password" id="confirmer_mot_de_passe" name="confirmer_mot_de_passe" required minlength="8">
                    </div>

                    <button type="submit" class="btn btn-primary">Modifier le mot de passe</button>
                </form>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
