<?php
require_once 'config.php';
verifierConnexion();

$user_id = $_SESSION['user_id'];
$role = $_SESSION['user_role'];

// Récupérer le mois et l'année
$mois = isset($_GET['mois']) ? (int)$_GET['mois'] : date('n');
$annee = isset($_GET['annee']) ? (int)$_GET['annee'] : date('Y');

// Validation
if ($mois < 1) {
    $mois = 12;
    $annee--;
} elseif ($mois > 12) {
    $mois = 1;
    $annee++;
}

// Calculer les dates du mois
$premier_jour = mktime(0, 0, 0, $mois, 1, $annee);
$nb_jours = date('t', $premier_jour);
$premier_jour_semaine = date('N', $premier_jour);

// Mois précédent et suivant
$mois_prec = $mois - 1;
$annee_prec = $annee;
if ($mois_prec < 1) {
    $mois_prec = 12;
    $annee_prec--;
}

$mois_suiv = $mois + 1;
$annee_suiv = $annee;
if ($mois_suiv > 12) {
    $mois_suiv = 1;
    $annee_suiv++;
}

// Récupérer les séances du mois
$date_debut = date('Y-m-01', $premier_jour);
$date_fin = date('Y-m-t', $premier_jour);

$stmt = $pdo->prepare("
    (SELECT et.date_seance, et.heure_debut, et.heure_fin, et.salle, et.matiere, et.groupe, et.disponible, u.nom, u.prenom, u.id as professeur_id, 'PLANIFIEE' as type
    FROM emploi_temps et
    LEFT JOIN utilisateurs u ON et.professeur_id = u.id
    WHERE et.date_seance BETWEEN ? AND ?)
    UNION
    (SELECT d.date_seance_nouvelle as date_seance, d.heure_debut_nouvelle as heure_debut, d.heure_fin_nouvelle as heure_fin, d.salle_nouvelle as salle, d.matiere, d.niveau as groupe, 0 as disponible, u.nom, u.prenom, u.id as professeur_id, 'VALIDEE' as type
    FROM demandes d
    JOIN utilisateurs u ON d.professeur_id = u.id
    WHERE d.date_seance_nouvelle BETWEEN ? AND ? 
    AND d.statut_directeur = 'Validé')
    ORDER BY date_seance, heure_debut
");
$stmt->execute([$date_debut, $date_fin, $date_debut, $date_fin]);
$seances = $stmt->fetchAll();

// Organiser les séances par date
$seances_par_jour = [];
foreach ($seances as $seance) {
    $jour = date('j', strtotime($seance['date_seance']));
    if (!isset($seances_par_jour[$jour])) {
        $seances_par_jour[$jour] = [];
    }
    $seances_par_jour[$jour][] = $seance;
}

$mois_fr = ['', 'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];

$couleurs_professeurs = [
    '#ef4444', '#f97316', '#f59e0b', '#eab308', '#84cc16',
    '#22c55e', '#10b981', '#14b8a6', '#06b6d4', '#0ea5e9',
    '#3b82f6', '#6366f1', '#8b5cf6', '#a855f7', '#d946ef',
    '#ec4899', '#f43f5e'
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendrier - Gestion des Séances</title>
    <!-- Updated CSS link to use assets/css/style.css for consistency -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
  <?php include 'includes/header.php'; ?>
    <div class="container">
        <div class="page-header">
            <h1>Calendrier des Séances</h1>
            <div style="display: flex; gap: 12px; align-items: center;">
                <a href="?mois=<?php echo $mois_prec; ?>&annee=<?php echo $annee_prec; ?>" class="btn btn-secondary">◀ Mois précédent</a>
                <span style="font-weight: 700; font-size: 18px;"><?php echo $mois_fr[$mois] . ' ' . $annee; ?></span>
                <a href="?mois=<?php echo $mois_suiv; ?>&annee=<?php echo $annee_suiv; ?>" class="btn btn-secondary">Mois suivant ▶</a>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <!-- Calendrier amélioré avec couleurs et informations détaillées -->
                <div class="calendar-grid">
                    <!-- En-tête des jours -->
                    <div class="calendar-header">Lundi</div>
                    <div class="calendar-header">Mardi</div>
                    <div class="calendar-header">Mercredi</div>
                    <div class="calendar-header">Jeudi</div>
                    <div class="calendar-header">Vendredi</div>
                    <div class="calendar-header">Samedi</div>
                    <div class="calendar-header">Dimanche</div>
                    
                    <!-- Cases vides avant le premier jour -->
                    <?php for ($i = 1; $i < $premier_jour_semaine; $i++): ?>
                        <div class="calendar-day empty"></div>
                    <?php endfor; ?>
                    
                    <!-- Jours du mois -->
                    <?php for ($jour = 1; $jour <= $nb_jours; $jour++): ?>
                        <div class="calendar-day">
                            <div class="day-number"><?php echo $jour; ?></div>
                            <?php if (isset($seances_par_jour[$jour])): ?>
                                <div class="day-seances">
                                    <?php 
                                    $index_couleur = 0;
                                    foreach ($seances_par_jour[$jour] as $seance): 
                                        $couleur = $seance['disponible'] ? '#10b981' : $couleurs_professeurs[$index_couleur % count($couleurs_professeurs)];
                                        $index_couleur++;
                                    ?>
                                        <!-- Improved layout to prevent overlap and fixed PHP warning for professeur_id -->
                                        <div class="seance-item <?php echo $seance['disponible'] ? 'disponible' : 'occupee'; ?>" style="background: white; border-left: 5px solid <?php echo $couleur; ?>; box-shadow: 0 2px 4px rgba(0,0,0,0.05); padding: 8px; margin-bottom: 4px; overflow: hidden; word-break: break-word;">
                                            <strong style="color: var(--primary); display: block; font-size: 11px;"><?php echo date('H:i', strtotime($seance['heure_debut'])); ?> - <?php echo date('H:i', strtotime($seance['heure_fin'])); ?></strong>
                                            <div class="seance-details" style="margin-top: 2px;">
                                                <?php if ($seance['disponible']): ?>
                                                    <span style="font-weight: 700; color: #065f46; font-size: 10px;">✓ LIBRE</span>
                                                    <small style="font-size: 9px;">Salle: <?php echo securiser($seance['salle']); ?></small>
                                                <?php else: ?>
                                                    <?php if ($seance['matiere']): ?>
                                                        <span style="font-weight: 700; font-size: 11px; display: block;"><?php echo securiser($seance['matiere']); ?></span>
                                                    <?php endif; ?>
                                                    <?php if (isset($seance['prenom']) && isset($seance['nom'])): ?>
                                                        <small style="font-weight: 600; color: #374151; font-size: 10px;">P: <?php echo securiser($seance['prenom'] . ' ' . $seance['nom']); ?></small>
                                                    <?php endif; ?>
                                                    <small style="font-size: 9px; display: block;">S: <?php echo securiser($seance['salle']); ?> | G: <?php echo securiser($seance['groupe']); ?></small>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endfor; ?>
                </div>
                
                <!-- Légende améliorée -->
                <div style="margin-top: 32px; display: flex; gap: 24px; flex-wrap: wrap;">
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <div style="width: 24px; height: 24px; background: linear-gradient(135deg, #10b98122 0%, #10b98144 100%); border: 3px solid #10b981; border-radius: 6px;"></div>
                        <span style="font-weight: 600;">Salle disponible</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <div style="width: 24px; height: 24px; background: linear-gradient(135deg, #ef444422 0%, #ef444444 100%); border: 3px solid #ef4444; border-radius: 6px;"></div>
                        <span style="font-weight: 600;">Salle occupée (avec détails)</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
