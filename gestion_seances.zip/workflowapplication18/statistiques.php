<?php
require_once 'config.php';
verifierConnexion();

$user_id = $_SESSION['user_id'];
$role = $_SESSION['user_role'];

// Période pour les statistiques
$periode = isset($_GET['periode']) ? $_GET['periode'] : '30'; // 30 jours par défaut
$date_debut = date('Y-m-d', strtotime("-{$periode} days"));

// Statistiques globales
if ($role === 'Directeur' || $role === 'Assistante') {
    // Stats par statut
    $stmt = $pdo->query("
        SELECT 
            statut_directeur,
            COUNT(*) as nombre
        FROM demandes
        WHERE date_creation >= '{$date_debut}'
        GROUP BY statut_directeur
    ");
    $stats_statut = $stmt->fetchAll();
    
    // Stats par professeur
    $stmt = $pdo->query("
        SELECT 
            u.nom, u.prenom,
            COUNT(*) as total,
            SUM(CASE WHEN d.statut_directeur = 'Validé' THEN 1 ELSE 0 END) as valide
        FROM demandes d
        JOIN utilisateurs u ON d.professeur_id = u.id
        WHERE d.date_creation >= '{$date_debut}'
        GROUP BY u.id
        ORDER BY total DESC
        LIMIT 10
    ");
    $stats_professeurs = $stmt->fetchAll();
    
    // Temps moyen de traitement
    $stmt = $pdo->query("
        SELECT 
            AVG(TIMESTAMPDIFF(HOUR, date_creation, date_validation_directeur)) as temps_moyen
        FROM demandes
        WHERE statut_directeur = 'Validé'
        AND date_creation >= '{$date_debut}'
    ");
    $temps_traitement = $stmt->fetch();
    
} else {
    // Stats personnelles pour le professeur
    $stmt = $pdo->prepare("
        SELECT 
            statut_directeur,
            COUNT(*) as nombre
        FROM demandes
        WHERE professeur_id = ?
        AND date_creation >= ?
        GROUP BY statut_directeur
    ");
    $stmt->execute([$user_id, $date_debut]);
    $stats_statut = $stmt->fetchAll();
}

// Préparer les données pour les graphiques
$labels_statut = [];
$data_statut = [];
foreach ($stats_statut as $stat) {
    $labels_statut[] = $stat['statut_directeur'];
    $data_statut[] = $stat['nombre'];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Statistiques - Gestion des Séances</title>
    <!-- Updated CSS link to use assets/css/style.css for consistency -->
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body>
   <?php include 'includes/header.php'; ?>
    <div class="container">
        <div class="page-header">
            <div>
                <h1>Statistiques et Rapports</h1>
                <p>Analyse des demandes de changement de séances</p>
            </div>
            <div style="display: flex; gap: 12px;">
                <a href="?periode=7" class="btn <?php echo $periode == 7 ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">7 jours</a>
                <a href="?periode=30" class="btn <?php echo $periode == 30 ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">30 jours</a>
                <a href="?periode=90" class="btn <?php echo $periode == 90 ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">90 jours</a>
            </div>
        </div>

        <?php if ($role === 'Directeur' || $role === 'Assistante'): ?>
        <div class="stats-grid">
            <div class="stat-card stat-total">
                <h3><?php echo array_sum($data_statut); ?></h3>
                <p>Total demandes (<?php echo $periode; ?>j)</p>
            </div>
            <div class="stat-card stat-approved">
                <h3><?php 
                    $key = array_search('Validé', $labels_statut);
                    echo $key !== false ? $data_statut[$key] : 0;
                ?></h3>
                <p>Demandes validées</p>
            </div>
            <div class="stat-card stat-pending">
                <h3><?php 
                    $key = array_search('En attente', $labels_statut);
                    echo $key !== false ? $data_statut[$key] : 0;
                ?></h3>
                <p>En attente</p>
            </div>
            <div class="stat-card" style="background: linear-gradient(135deg, #8b5cf6 0%, #6d28d9 100%);">
                <h3 style="color: white;"><?php echo isset($temps_traitement['temps_moyen']) ? round($temps_traitement['temps_moyen'], 1) : 0; ?>h</h3>
                <p style="color: white;">Temps moyen de traitement</p>
            </div>
        </div>
        <?php endif; ?>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(500px, 1fr)); gap: 28px; margin-bottom: 36px;">
            <div class="card">
                <div class="card-header">
                    <h2>Répartition par statut</h2>
                </div>
                <div class="card-body">
                    <canvas id="chartStatut"></canvas>
                </div>
            </div>
        </div>

        <?php if (($role === 'Directeur' || $role === 'Assistante') && !empty($stats_professeurs)): ?>
        <div class="card">
            <div class="card-header">
                <h2>Top 10 des professeurs</h2>
                <a href="export_stats.php?format=excel&periode=<?php echo $periode; ?>" class="btn btn-success btn-sm">Exporter Excel</a>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Professeur</th>
                            <th>Total demandes</th>
                            <th>Demandes validées</th>
                            <th>Taux de validation</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($stats_professeurs as $prof): ?>
                        <tr>
                            <td><?php echo securiser($prof['prenom'] . ' ' . $prof['nom']); ?></td>
                            <td><?php echo $prof['total']; ?></td>
                            <td><?php echo $prof['valide']; ?></td>
                            <td>
                                <span class="badge badge-info">
                                    <?php echo $prof['total'] > 0 ? round(($prof['valide'] / $prof['total']) * 100) : 0; ?>%
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <script>
        // Graphique répartition par statut
        const ctxStatut = document.getElementById('chartStatut').getContext('2d');
        new Chart(ctxStatut, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($labels_statut); ?>,
                datasets: [{
                    data: <?php echo json_encode($data_statut); ?>,
                    backgroundColor: [
                        'rgba(16, 185, 129, 0.8)',
                        'rgba(245, 158, 11, 0.8)',
                        'rgba(239, 68, 68, 0.8)'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            font: { size: 14, weight: '600' },
                            padding: 20
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
