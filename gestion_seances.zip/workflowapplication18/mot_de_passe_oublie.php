<?php
require_once 'config.php';

// Chargement de PHPMailer
require_once 'PHPMailer/src/Exception.php';
require_once 'PHPMailer/src/PHPMailer.php';
require_once 'PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Email invalide";
    } else {
        $stmt = $pdo->prepare("SELECT id, nom, prenom FROM utilisateurs WHERE email = ? AND actif = 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user) {
            $error = "Cet email n'existe pas ou le compte est désactivé";
        } else {
            // Générer un token unique
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', time() + 3600); // Expire dans 1 heure

            // Enregistrer le token dans remember_token
            $stmt = $pdo->prepare("UPDATE utilisateurs 
                                 SET remember_token = ?, remember_token_expiration = ? 
                                 WHERE id = ?");
            $stmt->execute([$token, $expires, $user['id']]);

            // Créer le lien de réinitialisation
            $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
            $reset_link = $protocol . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/reset_password.php?token=" . $token;

            // Configuration de l'email
            $mail = new PHPMailer(true);

            try {
                // Configuration SMTP
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'hatim2002acherkouk@gmail.com';           // ← VOTRE EMAIL
                $mail->Password   = 'xkhk mmza phva idib';             // ← MOT DE PASSE D'APPLICATION
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 587;
                $mail->CharSet    = 'UTF-8';

                // Expéditeur et destinataire
                $mail->setFrom('votre-email@gmail.com', 'Gestion des Séances');
                $mail->addAddress($email, $user['nom'] . ' ' . $user['prenom']);

                // Contenu de l'email
                $mail->isHTML(true);
                $mail->Subject = 'Réinitialisation de votre mot de passe';
                $mail->Body    = "
                    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;'>
                        <h2 style='color: #1976d2;'>Bonjour {$user['nom']} {$user['prenom']},</h2>
                        <p>Vous avez demandé la réinitialisation de votre mot de passe.</p>
                        <p style='margin: 30px 0;'>
                            <a href='$reset_link' style='display:inline-block; padding:12px 24px; background:#1976d2; color:white; text-decoration:none; border-radius:6px;'>
                                Changer mon mot de passe
                            </a>
                        </p>
                        <p style='color: #666;'>Ce lien expire dans <strong>1 heure</strong>.</p>
                        <hr style='border: none; border-top: 1px solid #eee; margin: 30px 0;'>
                        <p style='color: #999; font-size: 13px;'>
                            Si vous n'avez pas demandé cette réinitialisation, ignorez ce message.
                        </p>
                    </div>
                ";

                $mail->AltBody = "Lien de réinitialisation : $reset_link (expire dans 1 heure)";

                $mail->send();
                $message = "Email envoyé ! Vérifiez votre boîte de réception (et les spams).";
                
                // Logger l'activité
                if (function_exists('logActivity')) {
                    logActivity($user['id'], 'DEMANDE_REINITIALISATION_MOT_DE_PASSE', 'utilisateurs', $user['id'], ['email' => $email]);
                }
                
            } catch (Exception $e) {
                $error = "Erreur lors de l'envoi de l'email : " . $mail->ErrorInfo;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mot de passe oublié</title>
<style>
body {
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    margin: 0;
    padding: 20px;
}
.container {
    background: white;
    padding: 40px;
    border-radius: 12px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.2);
    width: 100%;
    max-width: 420px;
}
h1 {
    text-align: center;
    margin-bottom: 10px;
    color: #333;
    font-size: 28px;
}
.subtitle {
    text-align: center;
    color: #666;
    margin-bottom: 30px;
    font-size: 14px;
}
input {
    width: 100%;
    padding: 14px;
    margin: 10px 0;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    box-sizing: border-box;
    font-size: 15px;
    transition: border 0.3s;
}
input:focus {
    outline: none;
    border-color: #667eea;
}
button {
    width: 100%;
    padding: 14px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
    font-weight: 500;
    margin-top: 10px;
    transition: transform 0.2s, box-shadow 0.2s;
}
button:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
}
button:active {
    transform: translateY(0);
}
.error {
    background: #ffebee;
    color: #c62828;
    padding: 15px;
    border-radius: 8px;
    margin: 15px 0;
    text-align: center;
    border-left: 4px solid #c62828;
}
.success {
    background: #e8f5e9;
    color: #2e7d32;
    padding: 15px;
    border-radius: 8px;
    margin: 15px 0;
    text-align: center;
    border-left: 4px solid #2e7d32;
}
.back-link {
    text-align: center;
    margin-top: 25px;
}
.back-link a {
    color: #667eea;
    text-decoration: none;
    font-size: 14px;
    transition: color 0.3s;
}
.back-link a:hover {
    color: #764ba2;
    text-decoration: underline;
}
.icon {
    text-align: center;
    font-size: 48px;
    margin-bottom: 20px;
}
</style>
</head>
<body>

<div class="container">
    <div class="icon">🔐</div>
    <h1>Mot de passe oublié ?</h1>
    <p class="subtitle">Entrez votre email pour recevoir un lien de réinitialisation</p>

    <?php if ($error): ?>
        <div class="error">❌ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($message): ?>
        <div class="success">✅ <?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <form method="post">
        <input 
            type="email" 
            name="email" 
            placeholder="votre.email@exemple.com" 
            required
            autocomplete="email"
            <?php echo $message ? 'disabled' : ''; ?>
        >
        <button type="submit" <?php echo $message ? 'disabled' : ''; ?>>
            📧 Envoyer le lien de réinitialisation
        </button>
    </form>

    <div class="back-link">
        <a href="login.php">← Retour à la connexion</a>
    </div>
</div>

</body>
</html>