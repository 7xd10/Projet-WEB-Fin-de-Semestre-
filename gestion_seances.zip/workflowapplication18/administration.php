<?php
require_once 'config.php';
verifierRole(['Directeur']);

$user_id = $_SESSION['user_id'];
$tab = isset($_GET['tab']) ? $_GET['tab'] : 'utilisateurs';
$succes = '';
$erreur = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!isset($_POST['csrf_token'])) {
        $erreur = "Token CSRF manquant";
    } else {
        verifierTokenCSRF($_POST['csrf_token']);
        
        $action = $_POST['action'];
        
        if ($action === 'creer_utilisateur') {
            $nom = trim($_POST['nom'] ?? '');
            $prenom = trim($_POST['prenom'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $role = $_POST['role'] ?? '';
            $mot_de_passe = $_POST['mot_de_passe'] ?? '';
            $telephone = trim($_POST['telephone'] ?? '');
            $matricule = trim($_POST['matricule'] ?? '');
            
            if (empty($nom) || empty($prenom) || empty($email) || empty($role) || empty($mot_de_passe) || empty($matricule)) {
                $erreur = "Tous les champs obligatoires doivent être remplis";
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $erreur = "Email invalide";
            } elseif (!in_array($role, ['Professeur', 'Assistante', 'Directeur'])) {
                $erreur = "Rôle invalide";
            } elseif (strlen($mot_de_passe) < 8) {
                $erreur = "Le mot de passe doit contenir au moins 8 caractères";
            } else {
                try {
                    $stmt = $pdo->prepare("INSERT INTO utilisateurs (matricule, nom, prenom, email, mot_de_passe, role, telephone) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$matricule, $nom, $prenom, $email, md5($mot_de_passe), $role, $telephone]);
                    
                    logActivity($user_id, 'CREATION_UTILISATEUR', 'utilisateurs', $pdo->lastInsertId(), ['email' => $email, 'role' => $role]);
                    $succes = "Utilisateur créé avec succès";
                } catch (PDOException $e) {
                    if ($e->getCode() == 23000) {
                        $erreur = "Cet email ou matricule existe déjà";
                    } else {
                        $erreur = "Erreur lors de la création";
                    }
                }
            }
        } 
        elseif ($action === 'modifier_utilisateur') {
            $id = (int)$_POST['id'];
            $nom = trim($_POST['nom'] ?? '');
            $prenom = trim($_POST['prenom'] ?? '');
            $telephone = trim($_POST['telephone'] ?? '');
            $bureau = trim($_POST['bureau'] ?? '');
            $actif = isset($_POST['actif']) ? 1 : 0;
            
            $stmt = $pdo->prepare("UPDATE utilisateurs SET nom = ?, prenom = ?, telephone = ?, bureau = ?, actif = ? WHERE id = ?");
            $stmt->execute([$nom, $prenom, $telephone, $bureau, $actif, $id]);
            
            logActivity($user_id, 'MODIFICATION_UTILISATEUR', 'utilisateurs', $id);
            $succes = "Utilisateur modifié avec succès";
        } 
        elseif ($action === 'reinitialiser_mdp') {
            $id = (int)$_POST['id'];
            $nouveau_mdp = bin2hex(random_bytes(4)); // Générer un mot de passe temporaire
            
            $stmt = $pdo->prepare("UPDATE utilisateurs SET mot_de_passe = ? WHERE id = ?");
            $stmt->execute([md5($nouveau_mdp), $id]);
            
            // Récupérer l'email de l'utilisateur
            $stmt = $pdo->prepare("SELECT email, prenom, nom FROM utilisateurs WHERE id = ?");
            $stmt->execute([$id]);
            $user = $stmt->fetch();
            
            if ($user) {
                envoyerEmailNotification($user['email'], 'Réinitialisation de mot de passe', 
                    "Votre mot de passe a été réinitialisé. Nouveau mot de passe temporaire: $nouveau_mdp");
            }
            
            logActivity($user_id, 'REINITIALISATION_MDP', 'utilisateurs', $id);
            $succes = "Mot de passe réinitialisé. Nouveau mot de passe: $nouveau_mdp";
        }
        elseif ($action === 'creer_salle') {
            $nom = trim($_POST['nom'] ?? '');
            $batiment = trim($_POST['batiment'] ?? '');
            $capacite = (int)($_POST['capacite'] ?? 30);
            $equipements = trim($_POST['equipements'] ?? '');
            
            $stmt = $pdo->prepare("INSERT INTO salles (nom, batiment, capacite, equipements) VALUES (?, ?, ?, ?)");
            $stmt->execute([$nom, $batiment, $capacite, $equipements]);
            
            logActivity($user_id, 'CREATION_SALLE', 'salles', $pdo->lastInsertId());
            $succes = "Salle créée avec succès";
        } 
        elseif ($action === 'creer_matiere') {
            $code = trim($_POST['code'] ?? '');
            $nom = trim($_POST['nom'] ?? '');
            $description = trim($_POST['description'] ?? '');
            
            $stmt = $pdo->prepare("INSERT INTO matieres (code, nom, description) VALUES (?, ?, ?)");
            $stmt->execute([$code, $nom, $description]);
            
            logActivity($user_id, 'CREATION_MATIERE', 'matieres', $pdo->lastInsertId());
            $succes = "Matière créée avec succès";
        } 
        elseif ($action === 'modifier_parametre') {
            $cle = $_POST['cle'] ?? '';
            $valeur = trim($_POST['valeur'] ?? '');
            
            $stmt = $pdo->prepare("UPDATE parametres SET valeur = ? WHERE cle = ?");
            $stmt->execute([$valeur, $cle]);
            
            logActivity($user_id, 'MODIFICATION_PARAMETRE', 'parametres', null, ['cle' => $cle, 'valeur' => $valeur]);
            $succes = "Paramètre modifié avec succès";
        }
    }
}

// Récupération des données
$utilisateurs = $pdo->query("SELECT * FROM utilisateurs ORDER BY nom, prenom")->fetchAll();
$salles = $pdo->query("SELECT * FROM salles ORDER BY nom")->fetchAll();
$matieres = $pdo->query("SELECT * FROM matieres ORDER BY code")->fetchAll();
$parametres = $pdo->query("SELECT * FROM parametres ORDER BY cle")->fetchAll();

// Logs récents
$logs = $pdo->query("
    SELECT l.*, u.nom, u.prenom 
    FROM logs_activite l 
    LEFT JOIN utilisateurs u ON l.utilisateur_id = u.id 
    ORDER BY l.date_action DESC 
    LIMIT 50
")->fetchAll();

$stats_globales = $pdo->query("
    SELECT 
        COUNT(*) as total_demandes,
        SUM(CASE WHEN statut_directeur = 'Validé' THEN 1 ELSE 0 END) as demandes_validees,
        SUM(CASE WHEN statut_assistante = 'En attente' THEN 1 ELSE 0 END) as demandes_en_attente
    FROM demandes
    WHERE date_creation >= DATE_SUB(NOW(), INTERVAL 30 DAY)
")->fetch();

$csrf_token = genererTokenCSRF();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration - Gestion des Séances</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="navbar-brand">
            <h2>Gestion des Séances</h2>
        </div>
        <ul class="navbar-menu">
            <li><a href="index.php">Tableau de bord</a></li>
            <li><a href="demandes.php">Demandes</a></li>
            <li><a href="calendrier.php">Calendrier</a></li>
            <li><a href="statistiques.php">Statistiques</a></li>
            <li><a href="administration.php" class="active">Administration</a></li>
            <li><a href="profil.php">Profil</a></li>
            <li><a href="logout.php">Déconnexion</a></li>
        </ul>
        <div class="navbar-user">
            <span><?php echo securiser($_SESSION['user_prenom'] . ' ' . $_SESSION['user_nom']); ?></span>
            <span class="badge badge-info"><?php echo securiser($_SESSION['user_role']); ?></span>
        </div>
    </nav>

    <div class="container">
        <div class="page-header">
            <div>
                <h1>Administration du Système</h1>
                <p>Gestion des utilisateurs, salles, matières et paramètres</p>
            </div>
        </div>

        <?php if ($succes): ?>
            <div class="alert alert-success"><?php echo securiser($succes); ?></div>
        <?php endif; ?>
        
        <?php if ($erreur): ?>
            <div class="alert alert-error"><?php echo securiser($erreur); ?></div>
        <?php endif; ?>

        <!-- Dashboard statistiques pour le directeur -->
        <?php if ($tab === 'utilisateurs'): ?>
        <div class="stats-grid" style="margin-bottom: 24px;">
            <div class="stat-card stat-total">
                <h3><?php echo $stats_globales['total_demandes']; ?></h3>
                <p>Demandes (30j)</p>
            </div>
            <div class="stat-card stat-approved">
                <h3><?php echo $stats_globales['demandes_validees']; ?></h3>
                <p>Validées</p>
            </div>
            <div class="stat-card stat-pending">
                <h3><?php echo $stats_globales['demandes_en_attente']; ?></h3>
                <p>En attente</p>
            </div>
            <div class="stat-card" style="background: linear-gradient(135deg, #8b5cf6 0%, #6d28d9 100%);">
                <h3 style="color: white;"><?php echo count($utilisateurs); ?></h3>
                <p style="color: white;">Utilisateurs actifs</p>
            </div>
        </div>
        <?php endif; ?>

        <div class="card" style="margin-bottom: 24px;">
            <div class="card-header" style="border-bottom: none;">
                <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                    <a href="?tab=utilisateurs" class="btn <?php echo $tab === 'utilisateurs' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Utilisateurs</a>
                    <a href="?tab=salles" class="btn <?php echo $tab === 'salles' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Salles</a>
                    <a href="?tab=matieres" class="btn <?php echo $tab === 'matieres' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Matières</a>
                    <a href="?tab=parametres" class="btn <?php echo $tab === 'parametres' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Paramètres</a>
                    <a href="?tab=logs" class="btn <?php echo $tab === 'logs' ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Logs d'activité</a>
                </div>
            </div>
        </div>

        <?php if ($tab === 'utilisateurs'): ?>
        <div class="card">
            <div class="card-header">
                <h2>Gestion des Utilisateurs</h2>
                <button onclick="document.getElementById('modal-user').style.display='block'" class="btn btn-primary btn-sm">+ Nouvel utilisateur</button>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Matricule</th>
                            <th>Nom</th>
                            <th>Email</th>
                            <th>Rôle</th>
                            <th>Téléphone</th>
                            <th>Statut</th>
                            <th>Dernière connexion</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($utilisateurs as $u): ?>
                        <tr>
                            <td><strong><?php echo securiser($u['matricule'] ?? '-'); ?></strong></td>
                            <td><?php echo securiser($u['prenom'] . ' ' . $u['nom']); ?></td>
                            <td><?php echo securiser($u['email']); ?></td>
                            <td><span class="badge badge-info"><?php echo securiser($u['role']); ?></span></td>
                            <td><?php echo securiser($u['telephone'] ?? '-'); ?></td>
                            <td>
                                <?php if ($u['actif']): ?>
                                    <span class="badge badge-success">Actif</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Inactif</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $u['derniere_connexion'] ? date('d/m/Y H:i', strtotime($u['derniere_connexion'])) : '-'; ?></td>
                            <td>
                                <button onclick="editUser(<?php echo $u['id']; ?>)" class="btn btn-sm">Modifier</button>
                                <!-- Ajout bouton réinitialiser mot de passe -->
                                <form method="POST" style="display:inline;" onsubmit="return confirm('Réinitialiser le mot de passe?');">
                                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                    <input type="hidden" name="action" value="reinitialiser_mdp">
                                    <input type="hidden" name="id" value="<?php echo $u['id']; ?>">
                                    <button type="submit" class="btn btn-sm btn-warning">Réinit. MDP</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Modal création utilisateur -->
        <div id="modal-user" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.7); z-index:1000; padding:40px;">
            <div style="max-width:600px; margin:0 auto; background:white; border-radius:24px; padding:40px; max-height:90vh; overflow-y:auto;">
                <h2 style="margin-bottom:24px;">Nouvel utilisateur</h2>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    <input type="hidden" name="action" value="creer_utilisateur">
                    
                    <div class="form-group">
                        <label>Matricule *</label>
                        <input type="text" name="matricule" required maxlength="20" placeholder="Ex: PROF001">
                    </div>
                    
                    <div class="form-group">
                        <label>Nom *</label>
                        <input type="text" name="nom" required pattern="[A-Za-zÀ-ÿ\s\-]+" maxlength="100">
                    </div>
                    
                    <div class="form-group">
                        <label>Prénom *</label>
                        <input type="text" name="prenom" required pattern="[A-Za-zÀ-ÿ\s\-]+" maxlength="100">
                    </div>
                    
                    <div class="form-group">
                        <label>Email *</label>
                        <input type="email" name="email" required maxlength="150">
                    </div>
                    
                    <div class="form-group">
                        <label>Téléphone</label>
                        <input type="tel" name="telephone" placeholder="01-23-45-67-89" maxlength="20">
                    </div>
                    
                    <div class="form-group">
                        <label>Rôle *</label>
                        <select name="role" required>
                            <option value="">Sélectionner...</option>
                            <option value="Professeur">Professeur</option>
                            <option value="Assistante">Assistante</option>
                            <option value="Directeur">Directeur</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Mot de passe *</label>
                        <input type="password" name="mot_de_passe" required minlength="8" maxlength="255">
                        <small style="color:#64748b;">Minimum 8 caractères</small>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" onclick="document.getElementById('modal-user').style.display='none'" class="btn btn-secondary">Annuler</button>
                        <button type="submit" class="btn btn-primary">Créer</button>
                    </div>
                </form>
            </div>
        </div>
        
        <?php elseif ($tab === 'salles'): ?>
        <div class="card">
            <div class="card-header">
                <h2>Gestion des Salles</h2>
                <button onclick="document.getElementById('modal-salle').style.display='block'" class="btn btn-primary btn-sm">+ Nouvelle salle</button>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Nom</th>
                            <th>Bâtiment</th>
                            <th>Capacité</th>
                            <th>Équipements</th>
                            <th>Statut</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($salles as $s): ?>
                        <tr>
                            <td><strong><?php echo securiser($s['nom']); ?></strong></td>
                            <td><?php echo securiser($s['batiment'] ?? '-'); ?></td>
                            <td><?php echo $s['capacite']; ?> places</td>
                            <td><?php echo securiser($s['equipements'] ?? '-'); ?></td>
                            <td>
                                <?php if ($s['disponible']): ?>
                                    <span class="badge badge-success">Disponible</span>
                                <?php else: ?>
                                    <span class="badge badge-warning">Indisponible</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Modal création salle -->
        <div id="modal-salle" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.7); z-index:1000; padding:40px;">
            <div style="max-width:600px; margin:0 auto; background:white; border-radius:24px; padding:40px;">
                <h2 style="margin-bottom:24px;">Nouvelle salle</h2>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    <input type="hidden" name="action" value="creer_salle">
                    
                    <div class="form-group">
                        <label>Nom de la salle *</label>
                        <input type="text" name="nom" required maxlength="50">
                    </div>
                    
                    <div class="form-group">
                        <label>Bâtiment</label>
                        <input type="text" name="batiment" maxlength="50">
                    </div>
                    
                    <div class="form-group">
                        <label>Capacité</label>
                        <input type="number" name="capacite" min="1" max="500" value="30">
                    </div>
                    
                    <div class="form-group">
                        <label>Équipements</label>
                        <textarea name="equipements" rows="3" maxlength="500"></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" onclick="document.getElementById('modal-salle').style.display='none'" class="btn btn-secondary">Annuler</button>
                        <button type="submit" class="btn btn-primary">Créer</button>
                    </div>
                </form>
            </div>
        </div>
        
        <?php elseif ($tab === 'matieres'): ?>
        <div class="card">
            <div class="card-header">
                <h2>Gestion des Matières</h2>
                <button onclick="document.getElementById('modal-matiere').style.display='block'" class="btn btn-primary btn-sm">+ Nouvelle matière</button>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Nom</th>
                            <th>Description</th>
                            <th>Statut</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($matieres as $m): ?>
                        <tr>
                            <td><strong><?php echo securiser($m['code']); ?></strong></td>
                            <td><?php echo securiser($m['nom']); ?></td>
                            <td><?php echo securiser($m['description'] ?? '-'); ?></td>
                            <td>
                                <?php if ($m['actif']): ?>
                                    <span class="badge badge-success">Active</span>
                                <?php else: ?>
                                    <span class="badge badge-warning">Inactive</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Modal création matière -->
        <div id="modal-matiere" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.7); z-index:1000; padding:40px;">
            <div style="max-width:600px; margin:0 auto; background:white; border-radius:24px; padding:40px;">
                <h2 style="margin-bottom:24px;">Nouvelle matière</h2>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    <input type="hidden" name="action" value="creer_matiere">
                    
                    <div class="form-group">
                        <label>Code *</label>
                        <input type="text" name="code" required maxlength="20" pattern="[A-Z0-9]+">
                    </div>
                    
                    <div class="form-group">
                        <label>Nom *</label>
                        <input type="text" name="nom" required maxlength="150">
                    </div>
                    
                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="description" rows="3" maxlength="500"></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" onclick="document.getElementById('modal-matiere').style.display='none'" class="btn btn-secondary">Annuler</button>
                        <button type="submit" class="btn btn-primary">Créer</button>
                    </div>
                </form>
            </div>
        </div>
        
        <?php elseif ($tab === 'parametres'): ?>
        <div class="card">
            <div class="card-header">
                <h2>Paramètres du Système</h2>
                <p style="color: #64748b; margin: 8px 0 0 0;">Configuration globale de l'application</p>
            </div>
            <div class="card-body">
                <?php foreach ($parametres as $param): ?>
                <form method="POST" style="border-bottom: 2px solid #f1f5f9; padding: 24px 0;">
                    <input type="hidden" name="csrf_token" value="<?php echo genererTokenCSRF(); ?>">
                    <input type="hidden" name="action" value="modifier_parametre">
                    <input type="hidden" name="cle" value="<?php echo securiser($param['cle']); ?>">
                    
                    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px;">
                        <div style="flex: 1; min-width: 300px;">
                            <strong style="display: block; margin-bottom: 6px; font-size: 16px;"><?php echo securiser($param['cle']); ?></strong>
                            <p style="color: #64748b; margin: 0; font-size: 14px;"><?php echo securiser($param['description'] ?? ''); ?></p>
                        </div>
                        <div style="display: flex; gap: 12px; align-items: center;">
                            <input type="text" name="valeur" value="<?php echo securiser($param['valeur']); ?>" style="width: 200px; padding: 12px 16px; border: 2px solid #e2e8f0; border-radius: 12px;">
                            <button type="submit" class="btn btn-primary btn-sm">Modifier</button>
                        </div>
                    </div>
                </form>
                <?php endforeach; ?>
            </div>
        </div>
        
        <?php elseif ($tab === 'logs'): ?>
        <div class="card">
            <div class="card-header">
                <h2>Logs d'Activité</h2>
                <span class="badge badge-info"><?php echo count($logs); ?> dernières entrées</span>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date/Heure</th>
                            <th>Utilisateur</th>
                            <th>Action</th>
                            <th>Table</th>
                            <th>IP</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo date('d/m/Y H:i:s', strtotime($log['date_action'])); ?></td>
                            <td><?php echo $log['utilisateur_id'] ? securiser($log['prenom'] . ' ' . $log['nom']) : 'Système'; ?></td>
                            <td>
                                <span class="badge <?php echo strpos($log['action'], 'ALERTE') !== false ? 'badge-danger' : 'badge-info'; ?>">
                                    <?php echo securiser($log['action']); ?>
                                </span>
                            </td>
                            <td><?php echo securiser($log['table_concernee'] ?? '-'); ?></td>
                            <td><small><?php echo securiser($log['adresse_ip'] ?? '-'); ?></small></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>
