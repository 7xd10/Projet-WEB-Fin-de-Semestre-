<?php
require_once 'config.php';

// Rediriger si déjà connecté
if (estConnecte()) {
    header('Location: index.php');
    exit;
}

$erreur = '';
$message = '';

// Message de session expirée
if (isset($_GET['session_expiree']) || isset($_GET['timeout'])) {
    $message = "Votre session a expiré. Veuillez vous reconnecter.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember_me = isset($_POST['remember_me']);
    
    if (empty($email) || empty($password)) {
        $erreur = "Veuillez remplir tous les champs.";
    } else {
        $verif_tentatives = verifierTentativesConnexion($email);
        if ($verif_tentatives['bloque']) {
            $erreur = $verif_tentatives['message'];
        } else {
            $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE email = ?");
            $stmt->execute([$email]);
            $utilisateur = $stmt->fetch();
            
            if ($utilisateur && md5($password) === $utilisateur['mot_de_passe']) {
                if (isset($utilisateur['actif']) && !$utilisateur['actif']) {
                    $erreur = "Votre compte a été désactivé. Veuillez contacter l'administrateur.";
                    enregistrerTentativeEchouee($email, $_SERVER['REMOTE_ADDR']);
                } else {
                    session_regenerate_id(true);
                    
                    $_SESSION['user_id'] = $utilisateur['id'];
                    $_SESSION['user_nom'] = $utilisateur['nom'];
                    $_SESSION['user_prenom'] = $utilisateur['prenom'];
                    $_SESSION['user_email'] = $utilisateur['email'];
                    $_SESSION['user_role'] = $utilisateur['role'];
                    $_SESSION['last_activity'] = time();
                    
                    // For compatibility
                    $_SESSION['utilisateur_id'] = $utilisateur['id'];
                    $_SESSION['utilisateur_nom'] = $utilisateur['nom'];
                    $_SESSION['utilisateur_prenom'] = $utilisateur['prenom'];
                    $_SESSION['utilisateur_role'] = strtolower($utilisateur['role']);
                    
                    $stmt = $pdo->prepare("UPDATE utilisateurs SET derniere_connexion = NOW() WHERE id = ?");
                    $stmt->execute([$utilisateur['id']]);
                    
                    if ($remember_me) {
                        $token = bin2hex(random_bytes(32));
                        $token_hash = hash('sha256', $token);
                        $expiration = date('Y-m-d H:i:s', strtotime('+30 days'));
                        
                        $stmt = $pdo->prepare("UPDATE utilisateurs SET remember_token = ?, remember_token_expiration = ? WHERE id = ?");
                        $stmt->execute([$token_hash, $expiration, $utilisateur['id']]);
                        
                        setcookie('remember_token', $token, time() + (30 * 24 * 60 * 60), '/', '', false, true);
                        setcookie('remember_user', $utilisateur['id'], time() + (30 * 24 * 60 * 60), '/', '', false, true);
                    }
                    
                    logActivity($utilisateur['id'], 'CONNEXION', 'utilisateurs', $utilisateur['id']);
                    header('Location: index.php');
                    exit;
                }
            } else {
                $erreur = "Email ou mot de passe incorrect.";
                enregistrerTentativeEchouee($email, $_SERVER['REMOTE_ADDR']);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - Gestion des Séances</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Added specific styles for the split-screen login page as requested */
        :root {
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --bg-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        body.login-page {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            font-family: 'Inter', sans-serif;
            background: #fff;
        }
        .login-sidebar {
            flex: 1;
            background: linear-gradient(135deg, #003366 0%, #004080 100%);
            color: white;
            padding: 60px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        @media (max-width: 900px) {
            .login-sidebar { display: none; }
        }
        .login-sidebar-content {
            position: relative;
            z-index: 2;
        }
        .login-logo-box {
            width: 60px;
            height: 60px;
            background: white;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 40px;
            padding: 5px;
        }
        .login-sidebar h1 {
            font-size: 48px;
            font-weight: 700;
            margin-bottom: 10px;
            letter-spacing: -1px;
        }
        .login-sidebar .subtitle {
            font-size: 20px;
            opacity: 0.9;
            margin-bottom: 40px;
            text-transform: uppercase;
        }
        .feature-list {
            list-style: none;
            padding: 0;
            margin-bottom: 60px;
        }
        .feature-item {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            font-size: 16px;
        }
        .feature-item svg {
            margin-right: 15px;
            color: #fff;
        }
        .stats-box {
            background: rgba(255,255,255,0.1);
            border-radius: 16px;
            padding: 30px;
            display: flex;
            justify-content: space-between;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.2);
        }
        .stat-item { text-align: center; }
        .stat-value { font-size: 24px; font-weight: 700; display: block; }
        .stat-label { font-size: 12px; opacity: 0.8; text-transform: uppercase; }
        
        .login-main {
            width: 500px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px;
        }
        @media (max-width: 900px) {
            .login-main { width: 100%; }
        }
        .login-form-container {
            width: 100%;
            max-width: 400px;
        }
        .login-form-container h2 {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 10px;
            color: #1e293b;
        }
        .login-form-container .form-desc {
            color: #64748b;
            margin-bottom: 30px;
        }
        .form-group { margin-bottom: 20px; }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #334155;
            font-size: 14px;
        }
        .input-with-icon {
            position: relative;
        }
        .input-with-icon svg {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
        }
        .input-with-icon.password-toggle-wrapper {
            position: relative;
        }
        .input-with-icon.password-toggle-wrapper button {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            padding: 0;
        }
        .form-group input {
            width: 100%;
            padding: 12px 12px 12px 40px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 15px;
            transition: all 0.2s;
            box-sizing: border-box;
        }
        .form-group input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
        }
        .checkbox-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        .checkbox-label {
            display: flex;
            align-items: center;
            font-size: 14px;
            color: #64748b;
            cursor: pointer;
        }
        .checkbox-label input {
            margin-right: 8px;
        }
        .forgot-link {
            font-size: 14px;
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
        }
        .btn-login {
            width: 100%;
            padding: 14px;
            background: #003366;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: transform 0.2s;
        }
        .btn-login:hover {
            transform: translateY(-1px);
        }
        .btn-login svg {
            margin-left: 10px;
        }
        .alert {
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 24px;
            font-size: 14px;
            display: flex;
            align-items: center;
        }
        .alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
        .alert-info { background: #e0f2fe; color: #075985; border: 1px solid #bae6fd; }
    </style>
</head>
<body class="login-page">
    <div class="login-sidebar">
        <div class="login-sidebar-content">
            <div class="login-logo-box">
                <!-- Correction du chemin vers le logo pour utiliser la fonction asset() et garantir l'affichage -->
                <img src="<?php echo asset('assets/images/uemf_logo.jpg'); ?>" alt="UEMF Logo" style="width: 100%; height: auto; display: block;" onerror="this.src='public/images/uemf-logo.jpg'">
            </div>
            <h1>Gestion des Séances</h1>
            <p class="subtitle">EUROMED UNIVERSITY OF FES</p>
            
            <ul class="feature-list">
                <li class="feature-item">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                    Gestion simplifiée des demandes
                </li>
                <li class="feature-item">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                    Calendrier interactif en temps réel
                </li>
                <li class="feature-item">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                    Suivi complet et notifications
                </li>
                <li class="feature-item">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                    Sécurité renforcée
                </li>
            </ul>
            
            <div class="stats-box">
                <div class="stat-item">
                    <span class="stat-value">500+</span>
                    <span class="stat-label">Demandes traitées</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value">98%</span>
                    <span class="stat-label">Satisfaction</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value">24/7</span>
                    <span class="stat-label">Disponibilité</span>
                </div>
            </div>
        </div>
    </div>
    
    <div class="login-main">
        <div class="login-form-container">
            <h2>Connexion</h2>
            <p class="form-desc">Accédez à votre espace personnel</p>
            
            <?php if ($message): ?>
                <div class="alert alert-info"><?php echo securiser($message); ?></div>
            <?php endif; ?>

            <?php if ($erreur): ?>
                <div class="alert alert-error">
                    <svg style="margin-right: 10px;" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                    <?php echo securiser($erreur); ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label for="email">Adresse email</label>
                    <div class="input-with-icon">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                        <!-- Removed pre-filled value for email -->
                        <input type="email" id="email" name="email" required placeholder="nom.prenom@univ-euromed.ma">
                    </div>
                </div>

                <div class="form-group">
                    <label for="password">Mot de passe</label>
                    <div class="input-with-icon password-toggle-wrapper">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                        <!-- Removed pre-filled value for password -->
                        <input type="password" id="password" name="password" required placeholder="••••••••">
                        <button type="button" class="password-toggle-btn" onclick="togglePasswordVisibility('password')">
                            <svg id="eye-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                        </button>
                    </div>
                </div>

                <div class="checkbox-row">
                    <label class="checkbox-label">
                        <input type="checkbox" name="remember_me">
                        <span>Se souvenir de moi</span>
                    </label>
                    <a href="mot_de_passe_oublie.php" class="forgot-link">Mot de passe oublié ?</a>
                </div>

                <button type="submit" class="btn-login">
                    Se connecter
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                </button>
            </form>
            
            <div style="margin-top: 40px; text-align: center; color: #64748b; font-size: 14px;">
                <p>Vos données sont protégées et sécurisées</p>
            </div>
        </div>
    </div>

    <script>
        function togglePasswordVisibility(id) {
            const input = document.getElementById(id);
            const icon = document.querySelector('.password-toggle-btn svg');
            if (input.type === 'password') {
                input.type = 'text';
                icon.innerHTML = '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8 11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line>';
            } else {
                input.type = 'password';
                icon.innerHTML = '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
            }
        }
    </script>
</body>
</html>
