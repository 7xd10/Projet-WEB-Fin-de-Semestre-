<?php
require_once 'config.php';
verifierConnexion();

$user_id = $_SESSION['user_id'];
$role = $_SESSION['user_role'];

$afficher_alerte_securite = isset($_SESSION['mot_de_passe_faible']) && $_SESSION['mot_de_passe_faible'] === true;

if (isset($_POST['ignorer_alerte'])) {
    unset($_SESSION['mot_de_passe_faible']);
    header('Location: index.php');
    exit;
}

// Statistiques selon le rôle
if ($role === 'Professeur') {
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN statut_directeur = 'En attente' THEN 1 ELSE 0 END) as en_attente,
            SUM(CASE WHEN statut_directeur = 'Validé' THEN 1 ELSE 0 END) as valide,
            SUM(CASE WHEN statut_assistante = 'Refusé' OR statut_directeur = 'Refusé' THEN 1 ELSE 0 END) as refuse
        FROM demandes WHERE professeur_id = ?
    ");
    $stmt->execute([$user_id]);
    $stats = $stmt->fetch();
    
    $stmt = $pdo->prepare("SELECT * FROM demandes WHERE professeur_id = ? ORDER BY date_creation DESC LIMIT 5");
    $stmt->execute([$user_id]);
    $demandes = $stmt->fetchAll();
    
} elseif ($role === 'Assistante') {
    $stmt = $pdo->query("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN statut_assistante = 'En attente' THEN 1 ELSE 0 END) as en_attente,
            SUM(CASE WHEN statut_assistante = 'Validé' THEN 1 ELSE 0 END) as valide,
            SUM(CASE WHEN statut_assistante = 'Refusé' THEN 1 ELSE 0 END) as refuse
        FROM demandes
    ");
    $stats = $stmt->fetch();
    
    $stmt = $pdo->query("
        SELECT d.*, u.nom, u.prenom 
        FROM demandes d 
        JOIN utilisateurs u ON d.professeur_id = u.id 
        WHERE d.statut_assistante = 'En attente' 
        ORDER BY d.date_creation DESC LIMIT 5
    ");
    $demandes = $stmt->fetchAll();
    
} else {
    $stmt = $pdo->query("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN statut_directeur = 'En attente' AND statut_assistante = 'Validé' THEN 1 ELSE 0 END) as en_attente,
            SUM(CASE WHEN statut_directeur = 'Validé' THEN 1 ELSE 0 END) as valide,
            SUM(CASE WHEN statut_directeur = 'Refusé' THEN 1 ELSE 0 END) as refuse
        FROM demandes
    ");
    $stats = $stmt->fetch();
    
    $stmt = $pdo->query("
        SELECT d.*, u.nom, u.prenom 
        FROM demandes d 
        JOIN utilisateurs u ON d.professeur_id = u.id 
        WHERE d.statut_assistante = 'Validé' AND d.statut_directeur = 'En attente'
        ORDER BY d.date_validation_assistante DESC LIMIT 5
    ");
    $demandes = $stmt->fetchAll();
}

$stmt = $pdo->prepare("SELECT COUNT(*) as nb FROM notifications WHERE utilisateur_id = ? AND lu = 0");
$stmt->execute([$user_id]);
$notif = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord - Gestion des Séances</title>
    <!-- Updated CSS link to use assets/css/style.css for consistency -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
   <?php include 'includes/header.php'; ?>

    <div class="container">
        <!-- Alerte de sécurité pour mot de passe faible -->
        <?php if ($afficher_alerte_securite): ?>
            <div class="alert-security">
                <div class="alert-icon">⚠️</div>
                <div class="alert-content">
                    <strong>Alerte de sécurité : Changez votre mot de passe</strong>
                    <p>Le mot de passe que vous utilisez a été détecté lors d'une violation de données et est vulnérable. Pour protéger votre compte, veuillez le modifier immédiatement.</p>
                    <a href="profil.php" class="btn btn-warning btn-sm">Changer mon mot de passe</a>
                    <form method="POST" action="index.php" style="display:inline;">
                        <input type="hidden" name="ignorer_alerte" value="1">
                        <button type="submit" class="btn btn-secondary btn-sm">Ignorer pour le moment</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
        
        <div class="page-header">
            <div>
                <h1>Tableau de bord</h1>
                <p>Bienvenue, <?php echo securiser($_SESSION['user_prenom']); ?></p>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card stat-total">
                <h3><?php echo $stats['total']; ?></h3>
                <p>Total des demandes</p>
            </div>
            <div class="stat-card stat-pending">
                <h3><?php echo $stats['en_attente']; ?></h3>
                <p>En attente</p>
            </div>
            <div class="stat-card stat-approved">
                <h3><?php echo $stats['valide']; ?></h3>
                <p>Validées</p>
            </div>
            <div class="stat-card stat-rejected">
                <h3><?php echo $stats['refuse']; ?></h3>
                <p>Refusées</p>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h2>Demandes récentes</h2>
                <a href="demandes.php" class="btn btn-secondary">Voir tout</a>
            </div>
            <div class="card-body">
                <?php if (count($demandes) > 0): ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <?php if ($role !== 'Professeur'): ?>
                                    <th>Professeur</th>
                                <?php endif; ?>
                                <th>Ancien jour</th>
                                <th>Nouveau jour</th>
                                <th>Statut</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($demandes as $d): ?>
                                <tr>
                                    <td>#<?php echo $d['id']; ?></td>
                                    <?php if ($role !== 'Professeur'): ?>
                                        <td><?php echo securiser($d['prenom'] . ' ' . $d['nom']); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo securiser(date('d/m/Y', strtotime($d['date_seance_originale'])) . ' ' . date('H:i', strtotime($d['heure_debut_originale']))); ?></td>
                                    <td><?php echo $d['date_seance_nouvelle'] ? securiser(date('d/m/Y', strtotime($d['date_seance_nouvelle'])) . ' ' . date('H:i', strtotime($d['heure_debut_nouvelle']))) : '-'; ?></td>
                                    <td>
                                        <?php
                                        if ($d['statut_directeur'] === 'Validé') {
                                            echo '<span class="badge badge-success">Validé</span>';
                                        } elseif ($d['statut_assistante'] === 'Refusé' || $d['statut_directeur'] === 'Refusé') {
                                            echo '<span class="badge badge-danger">Refusé</span>';
                                        } elseif ($d['statut_assistante'] === 'Validé') {
                                            echo '<span class="badge badge-info">Validé (Assistante)</span>';
                                        } else {
                                            echo '<span class="badge badge-warning">En attente</span>';
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo date('d/m/Y', strtotime($d['date_creation'])); ?></td>
                                    <td><a href="detail_demande.php?id=<?php echo $d['id']; ?>" class="btn btn-sm">Voir</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="text-center">Aucune demande à afficher</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
