<?php
require_once 'config.php';

if (isset($_COOKIE['remember_token'])) {
    setcookie('remember_token', '', [
        'expires' => time() - 3600,
        'path' => '/',
        'domain' => '',
        'secure' => false,
        'httponly' => true,
        'samesite' => 'Strict'
    ]);
}

if (isset($_COOKIE['remember_user'])) {
    setcookie('remember_user', '', [
        'expires' => time() - 3600,
        'path' => '/',
        'domain' => '',
        'secure' => false,
        'httponly' => true,
        'samesite' => 'Strict'
    ]);
}

// Supprimer le token de la base de données si l'utilisateur est connecté
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("UPDATE utilisateurs SET remember_token = NULL, remember_token_expiration = NULL WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    
    logActivity($_SESSION['user_id'], 'DECONNEXION', 'utilisateurs', $_SESSION['user_id']);
}

session_destroy();
header('Location: login.php');
exit;
