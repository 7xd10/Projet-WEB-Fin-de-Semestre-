<?php
$page_title = 'Gestion des utilisateurs';
require_once '../config/init.php';
protegerPageRole('directeur');

$pdo = getDatabase();
$succes = '';
$erreur = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifierTokenCSRF($_POST['csrf_token'] ?? '')) {
        $erreur = "Token CSRF invalide.";
    } else {
        $action = nettoyer($_POST['action'] ?? '');
        
        if ($action === 'creer_utilisateur') {
            $matricule = nettoyer($_POST['matricule'] ?? '');
            $nom = nettoyer($_POST['nom'] ?? '');
            $prenom = nettoyer($_POST['prenom'] ?? '');
            $email = nettoyer($_POST['email'] ?? '');
            $role = nettoyer($_POST['role'] ?? '');
            $mot_de_passe = $_POST['mot_de_passe'] ?? '';
            $telephone = nettoyer($_POST['telephone'] ?? '');
            $bureau = nettoyer($_POST['bureau'] ?? '');
            
            if (empty($matricule) || empty($nom) || empty($prenom) || empty($email) || empty($role) || empty($mot_de_passe)) {
                $erreur = "Tous les champs obligatoires doivent être remplis.";
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $erreur = "Email invalide.";
            } elseif (!in_array($role, ['Professeur', 'Assistante', 'Directeur'])) {
                $erreur = "Rôle invalide.";
            } elseif (strlen($mot_de_passe) < 8) {
                $erreur = "Le mot de passe doit contenir au moins 8 caractères.";
            } else {
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO utilisateurs (matricule, nom, prenom, email, mot_de_passe, role, telephone, bureau, actif) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
                    ");
                    $stmt->execute([$matricule, $nom, $prenom, $email, md5($mot_de_passe), $role, $telephone, $bureau]);
                    
                    $user_id_created = $pdo->lastInsertId();
                    loggerActivite($_SESSION['utilisateur_id'], 'creation_utilisateur', $user_id_created);
                    
                    $succes = "Utilisateur créé avec succès.";
                } catch (PDOException $e) {
                    if ($e->getCode() == 23000) {
                        $erreur = "Ce matricule ou cet email existe déjà.";
                    } else {
                        $erreur = "Erreur lors de la création: " . $e->getMessage();
                    }
                }
            }
        }
        
        elseif ($action === 'modifier_utilisateur') {
            $user_id = (int)$_POST['user_id'];
            $nom = nettoyer($_POST['nom'] ?? '');
            $prenom = nettoyer($_POST['prenom'] ?? '');
            $telephone = nettoyer($_POST['telephone'] ?? '');
            $bureau = nettoyer($_POST['bureau'] ?? '');
            $role = nettoyer($_POST['role'] ?? '');
            
            $stmt = $pdo->prepare("UPDATE utilisateurs SET nom = ?, prenom = ?, telephone = ?, bureau = ?, role = ? WHERE id = ?");
            $stmt->execute([$nom, $prenom, $telephone, $bureau, $role, $user_id]);
            
            loggerActivite($_SESSION['utilisateur_id'], 'modification_utilisateur', $user_id);
            $succes = "Utilisateur modifié avec succès.";
        }
        
        elseif ($action === 'supprimer_utilisateur') {
            $user_id = (int)$_POST['user_id'];
            
            if ($user_id === (int)$_SESSION['utilisateur_id']) {
                $erreur = "Vous ne pouvez pas supprimer votre propre compte.";
            } else {
                $stmt = $pdo->prepare("DELETE FROM utilisateurs WHERE id = ?");
                $stmt->execute([$user_id]);
                
                loggerActivite($_SESSION['utilisateur_id'], 'suppression_utilisateur', $user_id);
                $succes = "Utilisateur supprimé définitivement.";
            }
        }
        
        elseif ($action === 'reinitialiser_mdp') {
            $user_id = (int)$_POST['user_id'];
            $nouveau_mdp = bin2hex(random_bytes(4));
            
            $stmt = $pdo->prepare("UPDATE utilisateurs SET mot_de_passe = ?, tentatives_connexion = 0, date_blocage = NULL WHERE id = ?");
            $stmt->execute([md5($nouveau_mdp), $user_id]);
            
            $stmt_user = $pdo->prepare("SELECT email, prenom, nom FROM utilisateurs WHERE id = ?");
            $stmt_user->execute([$user_id]);
            $user = $stmt_user->fetch();
            
            if ($user) {
                envoyerEmailNotification($user['email'], 'Réinitialisation de mot de passe', 
                    "Votre mot de passe a été réinitialisé par le directeur. Nouveau mot de passe temporaire: $nouveau_mdp. Veuillez le changer dès votre prochaine connexion.");
            }
            
            loggerActivite($_SESSION['utilisateur_id'], 'reinitialisation_mdp', $user_id);
            $succes = "Le mot de passe de " . echapper($user['prenom'] . ' ' . $user['nom']) . " a été réinitialisé. <br>Nouveau mot de passe : <span class='password-highlight'>$nouveau_mdp</span>";
        }
        
        elseif ($action === 'desactiver_utilisateur') {
            $user_id = (int)$_POST['user_id'];
            $raison = nettoyer($_POST['raison_desactivation'] ?? '');
            
            $stmt = $pdo->prepare("UPDATE utilisateurs SET actif = 0 WHERE id = ?");
            $stmt->execute([$user_id]);
            
            loggerActivite($_SESSION['utilisateur_id'], 'desactivation_utilisateur', $user_id);
            $succes = "Utilisateur désactivé avec succès.";
        }
        
        elseif ($action === 'reactiver_utilisateur') {
            $user_id = (int)$_POST['user_id'];
            
            $stmt = $pdo->prepare("UPDATE utilisateurs SET actif = 1, tentatives_connexion = 0, date_blocage = NULL WHERE id = ?");
            $stmt->execute([$user_id]);
            
            loggerActivite($_SESSION['utilisateur_id'], 'reactivation_utilisateur', $user_id);
            $succes = "Utilisateur réactivé avec succès.";
        }
    }
}

// Récupération des utilisateurs
$utilisateurs = $pdo->query("
    SELECT u.*, 
           (SELECT COUNT(*) FROM logs_activite WHERE utilisateur_id = u.id) as nb_actions,
           (SELECT COUNT(*) FROM demandes WHERE professeur_id = u.id) as nb_demandes
    FROM utilisateurs u 
    ORDER BY u.actif DESC, u.role, u.nom, u.prenom
")->fetchAll();

$csrf_token = genererTokenCSRF();
include '../includes/header.php';
?>

<main class="container">
    <div class="page-header">
        <h1>👥 Gestion des Utilisateurs</h1>
        <button onclick="document.getElementById('modal-create-user').style.display='flex'" class="btn btn-primary">
            ➕ Créer un utilisateur
        </button>
    </div>
    
    <?php if ($erreur): ?>
        <div class="alert alert-error"><?php echo echapper($erreur); ?></div>
    <?php endif; ?>
    
    <?php if ($succes): ?>
        <div class="alert alert-success"><?php echo $succes; ?></div>
    <?php endif; ?>
    
    <!-- Statistiques globales -->
    <div class="stats-grid" style="margin-bottom: 24px;">
        <div class="stat-card">
            <h3><?php echo count(array_filter($utilisateurs, fn($u) => $u['actif'])); ?></h3>
            <p>Utilisateurs actifs</p>
        </div>
        <div class="stat-card">
            <h3><?php echo count(array_filter($utilisateurs, fn($u) => $u['role'] === 'Professeur')); ?></h3>
            <p>Professeurs</p>
        </div>
        <div class="stat-card">
            <h3><?php echo count(array_filter($utilisateurs, fn($u) => $u['role'] === 'Assistante')); ?></h3>
            <p>Assistantes</p>
        </div>
        <div class="stat-card">
            <h3><?php echo count(array_filter($utilisateurs, fn($u) => !$u['actif'])); ?></h3>
            <p>Comptes désactivés</p>
        </div>
    </div>
    
    <div class="card">
        <div class="card-header">
            <h2>Liste des utilisateurs</h2>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Matricule</th>
                        <th>Nom complet</th>
                        <th>Email</th>
                        <th>Rôle</th>
                        <th>Téléphone</th>
                        <th>Statut</th>
                        <th>Dernière connexion</th>
                        <th>Activité</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($utilisateurs as $u): ?>
                    <tr style="<?php echo !$u['actif'] ? 'opacity: 0.5;' : ''; ?>">
                        <td><strong><?php echo echapper($u['matricule']); ?></strong></td>
                        <td><?php echo echapper($u['prenom'] . ' ' . $u['nom']); ?></td>
                        <td><?php echo echapper($u['email']); ?></td>
                        <td>
                            <span class="badge badge-<?php 
                                echo $u['role'] === 'Directeur' ? 'error' : 
                                     ($u['role'] === 'Assistante' ? 'info' : 'success'); 
                            ?>">
                                <?php echo echapper($u['role']); ?>
                            </span>
                        </td>
                        <td><?php echo echapper($u['telephone'] ?? '-'); ?></td>
                        <td>
                            <?php if ($u['actif']): ?>
                                <span class="badge badge-success">✓ Actif</span>
                            <?php else: ?>
                                <span class="badge badge-secondary">✗ Désactivé</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo $u['derniere_connexion'] ? date('d/m/Y H:i', strtotime($u['derniere_connexion'])) : 'Jamais'; ?></td>
                        <td>
                            <a href="?user_id=<?php echo $u['id']; ?>#historique" class="btn btn-sm btn-secondary">
                                📊 <?php echo $u['nb_actions']; ?> actions
                            </a>
                        </td>
                        <td style="display: flex; gap: 8px; flex-wrap: wrap;">
                            <button onclick="modifierUtilisateur(<?php echo $u['id']; ?>, '<?php echo echapper($u['nom']); ?>', '<?php echo echapper($u['prenom']); ?>', '<?php echo echapper($u['telephone']); ?>', '<?php echo echapper($u['bureau']); ?>', '<?php echo echapper($u['role']); ?>')" 
                                    class="btn btn-sm btn-primary">✏️ Modifier</button>
                            
                            <form method="POST" style="display: inline;" onsubmit="return confirm('Réinitialiser le mot de passe?');">
                                <input type="hidden" name="csrf_token" value="<?php echo echapper($csrf_token); ?>">
                                <input type="hidden" name="action" value="reinitialiser_mdp">
                                <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                                <button type="submit" class="btn btn-sm btn-warning">🔑 Réinit. MDP</button>
                            </form>
                            
                            <?php if ($u['actif']): ?>
                                <button onclick="desactiverUtilisateur(<?php echo $u['id']; ?>, '<?php echo echapper($u['prenom'] . ' ' . $u['nom']); ?>')" 
                                        class="btn btn-sm btn-danger">🚫 Désactiver</button>
                            <?php else: ?>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="csrf_token" value="<?php echo echapper($csrf_token); ?>">
                                    <input type="hidden" name="action" value="reactiver_utilisateur">
                                    <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                                    <button type="submit" class="btn btn-sm btn-success">✓ Réactiver</button>
                                </form>
                            <?php endif; ?>
                            
                            <form method="POST" style="display: inline;" onsubmit="return confirm('⚠️ Êtes-vous sûr de vouloir supprimer définitivement cet utilisateur ? Cette action est irréversible.');">
                                <input type="hidden" name="csrf_token" value="<?php echo echapper($csrf_token); ?>">
                                <input type="hidden" name="action" value="supprimer_utilisateur">
                                <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                                <button type="submit" class="btn btn-sm btn-error">🗑️ Supprimer</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Section historique d'activité pour l'utilisateur sélectionné -->
    <?php if (isset($_GET['user_id'])): ?>
    <?php
        $user_id_selected = (int)$_GET['user_id'];
        $stmt_user = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
        $stmt_user->execute([$user_id_selected]);
        $user_selected = $stmt_user->fetch();
        
        $stmt_logs = $pdo->prepare("
            SELECT l.* FROM logs_activite l 
            WHERE l.utilisateur_id = ? 
            ORDER BY l.date_action DESC 
            LIMIT 50
        ");
        $stmt_logs->execute([$user_id_selected]);
        $logs = $stmt_logs->fetchAll();
    ?>
    
    <div id="historique" class="card" style="margin-top: 24px;">
        <div class="card-header">
            <h2>📜 Historique d'activité: <?php echo echapper($user_selected['prenom'] . ' ' . $user_selected['nom']); ?></h2>
            <a href="<?php echo BASE_URL; ?>/pages/gestion_utilisateurs.php" class="btn btn-secondary btn-sm">Fermer</a>
        </div>
        <div class="card-body">
            <?php if (count($logs) > 0): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Action</th>
                            <th>Table</th>
                            <th>ID</th>
                            <th>IP</th>
                            <th>User Agent</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo date('d/m/Y H:i:s', strtotime($log['date_action'])); ?></td>
                            <td>
                                <span class="badge badge-info">
                                    <?php echo echapper($log['action']); ?>
                                </span>
                            </td>
                            <td><?php echo echapper($log['table_concernee'] ?? '-'); ?></td>
                            <td><?php echo echapper($log['enregistrement_id'] ?? '-'); ?></td>
                            <td><?php echo echapper($log['adresse_ip'] ?? '-'); ?></td>
                            <td style="font-size: 12px; max-width: 200px; overflow: hidden; text-overflow: ellipsis;">
                                <?php echo echapper($log['user_agent'] ?? '-'); ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="no-data">Aucune activité enregistrée.</p>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</main>

<!-- Modal création utilisateur -->
<div id="modal-create-user" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); z-index: 1000; align-items: center; justify-content: center;">
    <div style="max-width: 600px; width: 90%; background: white; border-radius: 16px; padding: 32px; max-height: 90vh; overflow-y: auto;">
        <h2 style="margin-bottom: 24px;">➕ Créer un nouvel utilisateur</h2>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo echapper($csrf_token); ?>">
            <input type="hidden" name="action" value="creer_utilisateur">
            
            <div class="form-group">
                <label>Matricule *</label>
                <input type="text" name="matricule" required maxlength="20" placeholder="Ex: PROF001">
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Nom *</label>
                    <input type="text" name="nom" required maxlength="100">
                </div>
                
                <div class="form-group">
                    <label>Prénom *</label>
                    <input type="text" name="prenom" required maxlength="100">
                </div>
            </div>
            
            <div class="form-group">
                <label>Email *</label>
                <input type="email" name="email" required maxlength="150">
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Téléphone</label>
                    <input type="tel" name="telephone" placeholder="01-23-45-67-89" maxlength="20">
                </div>
                
                <div class="form-group">
                    <label>Bureau</label>
                    <input type="text" name="bureau" placeholder="A201" maxlength="50">
                </div>
            </div>
            
            <div class="form-group">
                <label>Rôle *</label>
                <select name="role" required>
                    <option value="">-- Sélectionner --</option>
                    <option value="Professeur">Professeur</option>
                    <option value="Assistante">Assistante</option>
                    <option value="Directeur">Directeur</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Mot de passe *</label>
                <input type="password" name="mot_de_passe" required minlength="8" maxlength="255">
                <small style="color: #64748b;">Minimum 8 caractères</small>
            </div>
            
            <div class="form-actions" style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 24px;">
                <button type="button" onclick="document.getElementById('modal-create-user').style.display='none'" class="btn btn-secondary">Annuler</button>
                <button type="submit" class="btn btn-primary">Créer l'utilisateur</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal modification utilisateur -->
<div id="modal-edit-user" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); z-index: 1000; align-items: center; justify-content: center;">
    <div style="max-width: 600px; width: 90%; background: white; border-radius: 16px; padding: 32px;">
        <h2 style="margin-bottom: 24px;">✏️ Modifier l'utilisateur</h2>
        <form method="POST" id="form-edit-user">
            <input type="hidden" name="csrf_token" value="<?php echo echapper($csrf_token); ?>">
            <input type="hidden" name="action" value="modifier_utilisateur">
            <input type="hidden" name="user_id" id="edit_user_id">
            
            <div class="form-row">
                <div class="form-group">
                    <label>Nom *</label>
                    <input type="text" name="nom" id="edit_nom" required maxlength="100">
                </div>
                
                <div class="form-group">
                    <label>Prénom *</label>
                    <input type="text" name="prenom" id="edit_prenom" required maxlength="100">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Téléphone</label>
                    <input type="tel" name="telephone" id="edit_telephone" maxlength="20">
                </div>
                
                <div class="form-group">
                    <label>Bureau</label>
                    <input type="text" name="bureau" id="edit_bureau" maxlength="50">
                </div>
            </div>

            <div class="form-group">
                <label>Rôle *</label>
                <select name="role" id="edit_role" required>
                    <option value="Professeur">Professeur</option>
                    <option value="Assistante">Assistante</option>
                    <option value="Directeur">Directeur</option>
                </select>
            </div>
            
            <div class="form-actions" style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 24px;">
                <button type="button" onclick="document.getElementById('modal-edit-user').style.display='none'" class="btn btn-secondary">Annuler</button>
                <button type="submit" class="btn btn-primary">Enregistrer</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal désactivation utilisateur -->
<div id="modal-deactivate-user" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); z-index: 1000; align-items: center; justify-content: center;">
    <div style="max-width: 500px; width: 90%; background: white; border-radius: 16px; padding: 32px;">
        <h2 style="margin-bottom: 16px; color: #dc2626;">⚠️ Désactiver l'utilisateur</h2>
        <p id="deactivate-message" style="margin-bottom: 24px; color: #64748b;"></p>
        <form method="POST" id="form-deactivate-user">
            <input type="hidden" name="csrf_token" value="<?php echo echapper($csrf_token); ?>">
            <input type="hidden" name="action" value="desactiver_utilisateur">
            <input type="hidden" name="user_id" id="deactivate_user_id">
            
            <div class="form-group">
                <label>Raison de la désactivation (optionnel)</label>
                <textarea name="raison_desactivation" rows="3" placeholder="Ex: Départ, congé longue durée..."></textarea>
            </div>
            
            <div class="form-actions" style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 24px;">
                <button type="button" onclick="document.getElementById('modal-deactivate-user').style.display='none'" class="btn btn-secondary">Annuler</button>
                <button type="submit" class="btn btn-danger">Désactiver</button>
            </div>
        </form>
    </div>
</div>

<script>
function modifierUtilisateur(id, nom, prenom, tel, bureau, role) {
    document.getElementById('edit_user_id').value = id;
    document.getElementById('edit_nom').value = nom;
    document.getElementById('edit_prenom').value = prenom;
    document.getElementById('edit_telephone').value = tel;
    document.getElementById('edit_bureau').value = bureau;
    document.getElementById('edit_role').value = role;
    document.getElementById('modal-edit-user').style.display = 'flex';
}

function desactiverUtilisateur(id, nom) {
    document.getElementById('deactivate_user_id').value = id;
    document.getElementById('deactivate-message').textContent = 
        'Êtes-vous sûr de vouloir désactiver le compte de ' + nom + ' ? Cette action peut être annulée ultérieurement.';
    document.getElementById('modal-deactivate-user').style.display = 'flex';
}
</script>

<?php include '../includes/footer.php'; ?>
