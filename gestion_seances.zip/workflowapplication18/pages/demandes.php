<?php
$page_title = 'Mes demandes';
require_once '../config/init.php';
protegerPage();

$pdo = getDatabase();
$role = $_SESSION['utilisateur_role'];
$utilisateur_id = $_SESSION['utilisateur_id'];

$message_succes = '';
$message_erreur = '';

if (isset($_GET['action']) && $_GET['action'] === 'supprimer' && isset($_GET['id'])) {
    if (!verifierTokenCSRF($_GET['csrf_token'] ?? '')) {
        $message_erreur = "Token de sécurité invalide.";
    } else {
        $demande_id = (int)$_GET['id'];
        
        $stmt = $pdo->prepare("SELECT * FROM demandes WHERE id = ? AND professeur_id = ?");
        $stmt->execute([$demande_id, $utilisateur_id]);
        $demande = $stmt->fetch();
        
        if (!$demande) {
            $message_erreur = "Demande introuvable.";
        } elseif ($demande['statut_assistante'] !== 'En attente') {
            $message_erreur = "Impossible de supprimer une demande déjà traitée par l'assistante.";
        } else {
            if ($demande['piece_jointe'] && file_exists('../uploads/justificatifs/' . $demande['piece_jointe'])) {
                unlink('../uploads/justificatifs/' . $demande['piece_jointe']);
            }
            
            $stmt = $pdo->prepare("DELETE FROM demandes WHERE id = ?");
            if ($stmt->execute([$demande_id])) {
                loggerActivite($utilisateur_id, 'suppression_demande', $demande_id);
                $message_succes = "La demande a été supprimée avec succès.";
            } else {
                $message_erreur = "Erreur lors de la suppression.";
            }
        }
    }
}

$filtre_statut = isset($_GET['statut']) ? nettoyer($_GET['statut']) : '';
$filtre_type = isset($_GET['type']) ? nettoyer($_GET['type']) : '';

if ($role === 'Professeur') {
    $sql = "SELECT * FROM demandes WHERE professeur_id = ?";
    $params = [$utilisateur_id];
} else {
    $sql = "SELECT d.*, u.nom, u.prenom, u.email 
            FROM demandes d 
            JOIN utilisateurs u ON d.professeur_id = u.id 
            WHERE 1=1";
    $params = [];
    
    if ($role === 'Assistante' && empty($filtre_statut)) {
        $sql .= " AND d.statut_assistante IN ('En attente', 'Validé', 'Info demandée', 'Alternative proposée')";
    } elseif ($role === 'Directeur' && empty($filtre_statut)) {
        $sql .= " AND d.statut_assistante = 'Validé' AND d.statut_directeur IN ('En attente', 'Validé')";
    }
}

if ($filtre_statut) {
    $sql .= " AND " . ($role === 'Professeur' ? '' : 'd.') . "statut_assistante = ?";
    $params[] = $filtre_statut;
}

if ($filtre_type) {
    $sql .= " AND " . ($role === 'Professeur' ? '' : 'd.') . "type_demande = ?";
    $params[] = $filtre_type;
}

$sql .= " ORDER BY " . ($role === 'Professeur' ? '' : 'd.') . "date_creation DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$demandes = $stmt->fetchAll();

$csrf_token = genererTokenCSRF();

include '../includes/header.php';
?>

<main class="container">
    <div class="page-header">
        <h1>
            <?php 
            if ($role === 'Professeur') {
                echo 'Mes demandes';
            } else {
                echo 'Toutes les demandes';
            }
            ?>
        </h1>
        <?php if ($role === 'Professeur'): ?>
            <a href="<?php echo BASE_URL; ?>/pages/nouvelle_demande.php" class="btn btn-primary">➕ Nouvelle demande</a>
        <?php endif; ?>
    </div>
    
    <?php if ($message_succes): ?>
        <div class="alert alert-success"><?php echo echapper($message_succes); ?></div>
    <?php endif; ?>
    
    <?php if ($message_erreur): ?>
        <div class="alert alert-error"><?php echo echapper($message_erreur); ?></div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-header">
            <h2>Filtres</h2>
        </div>
        <form method="GET" action="" class="filters-form">
            <div class="form-row">
                <div class="form-group">
                    <label for="statut">Statut</label>
                    <select id="statut" name="statut">
                        <option value="">Tous</option>
                        <option value="En attente" <?php echo $filtre_statut === 'En attente' ? 'selected' : ''; ?>>En attente</option>
                        <option value="Validé" <?php echo $filtre_statut === 'Validé' ? 'selected' : ''; ?>>Validé</option>
                        <option value="Refusé" <?php echo $filtre_statut === 'Refusé' ? 'selected' : ''; ?>>Refusé</option>
                        <option value="Info demandée" <?php echo $filtre_statut === 'Info demandée' ? 'selected' : ''; ?>>Info demandée</option>
                        <option value="Alternative proposée" <?php echo $filtre_statut === 'Alternative proposée' ? 'selected' : ''; ?>>Alternative proposée</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="type">Type</label>
                    <select id="type" name="type">
                        <option value="">Tous</option>
                        <option value="modification" <?php echo $filtre_type === 'modification' ? 'selected' : ''; ?>>Modification</option>
                        <option value="annulation" <?php echo $filtre_type === 'annulation' ? 'selected' : ''; ?>>Annulation</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Filtrer</button>
                    <a href="<?php echo BASE_URL; ?>/pages/demandes.php" class="btn btn-secondary">Réinitialiser</a>
                </div>
            </div>
        </form>
    </div>
    
    <div class="card">
        <div class="table-responsive">
            <?php if (count($demandes) > 0): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <?php if ($role !== 'Professeur'): ?>
                                <th>Professeur</th>
                            <?php endif; ?>
                            <th>Type</th>
                            <th>Matière</th>
                            <th>Date séance</th>
                            <th>Statut</th>
                            <?php if ($role === 'Professeur'): ?>
                                <th>Brouillon</th>
                                <th>Pièce jointe</th>
                            <?php endif; ?>
                            <th>Date création</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($demandes as $demande): ?>
                            <tr>
                                <td>#<?php echo echapper($demande['id']); ?></td>
                                <?php if ($role !== 'Professeur'): ?>
                                    <td><?php echo echapper($demande['prenom'] . ' ' . $demande['nom']); ?></td>
                                <?php endif; ?>
                                <td>
                                    <span class="badge badge-<?php echo $demande['type_demande'] === 'modification' ? 'info' : 'warning'; ?>">
                                        <?php echo echapper(ucfirst($demande['type_demande'] ?? 'N/A')); ?>
                                    </span>
                                </td>
                                <td><?php echo echapper($demande['matiere']); ?></td>
                                <td><?php echo echapper(date('d/m/Y', strtotime($demande['date_seance_originale']))); ?></td>
                                <td>
                                    <?php
                                    $statut_classes = [
                                        'En attente' => 'warning',
                                        'Validé' => 'success',
                                        'Refusé' => 'error',
                                        'Info demandée' => 'info',
                                        'Alternative proposée' => 'info'
                                    ];
                                    $statut = $demande['statut_assistante'];
                                    ?>
                                    <span class="badge badge-<?php echo $statut_classes[$statut] ?? 'secondary'; ?>">
                                        <?php echo echapper($statut); ?>
                                    </span>
                                </td>
                                <?php if ($role === 'Professeur'): ?>
                                    <td>
                                        <?php if ($demande['est_brouillon']): ?>
                                            <span class="badge badge-secondary">📝 Oui</span>
                                        <?php else: ?>
                                            <span class="badge badge-success">✓ Non</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($demande['piece_jointe']): ?>
                                            <span class="badge badge-info">📎 Oui</span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">-</span>
                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>
                                <td><?php echo echapper(date('d/m/Y H:i', strtotime($demande['date_creation']))); ?></td>
                                <td style="display: flex; gap: 8px; flex-wrap: wrap;">
                                    <a href="<?php echo BASE_URL; ?>/pages/details_demande.php?id=<?php echo echapper($demande['id']); ?>" class="btn btn-sm btn-secondary">👁️ Détails</a>
                                    
                                    <?php if ($role === 'Professeur' && $demande['est_brouillon']): ?>
                                        <a href="<?php echo BASE_URL; ?>/pages/modifier_demande.php?id=<?php echo echapper($demande['id']); ?>" class="btn btn-sm btn-primary">✏️ Modifier</a>
                                    <?php endif; ?>
                                    
                                    <!-- Ajout du bouton de suppression visible pour les demandes en attente -->
                                    <?php if ($role === 'Professeur' && $demande['statut_assistante'] === 'En attente'): ?>
                                        <a href="<?php echo BASE_URL; ?>/pages/demandes.php?action=supprimer&id=<?php echo echapper($demande['id']); ?>&csrf_token=<?php echo echapper($csrf_token); ?>" 
                                           class="btn btn-sm btn-danger" 
                                           onclick="return confirm('⚠️ Êtes-vous sûr de vouloir supprimer cette demande ?')"
                                           style="background: #ef4444; color: white;">
                                            🗑️ Supprimer
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="no-data">Aucune demande trouvée.</p>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php include '../includes/footer.php'; ?>
