<?php
$page_title = 'Modifier la demande';
require_once '../config.php';
protegerPageRole('professeur');

$demande_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$pdo = getDatabase();

// Récupérer la demande
$stmt = $pdo->prepare("SELECT * FROM demandes WHERE id = ? AND professeur_id = ? AND est_brouillon = 1");
$stmt->execute([$demande_id, $_SESSION['utilisateur_id']]);
$demande = $stmt->fetch();

if (!$demande) {
    rediriger('/pages/demandes.php?erreur=demande_introuvable');
}

$erreur = '';
$succes = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifierTokenCSRF($_POST['csrf_token'] ?? '')) {
        $erreur = "Token de sécurité invalide.";
    } else {
        $type_demande = nettoyer($_POST['type_demande'] ?? '');
        $date_seance_originale = nettoyer($_POST['date_seance_originale'] ?? '');
        $heure_debut_originale = nettoyer($_POST['heure_debut_originale'] ?? '');
        $heure_fin_originale = nettoyer($_POST['heure_fin_originale'] ?? '');
        $salle_originale = nettoyer($_POST['salle_originale'] ?? '');
        $matiere = nettoyer($_POST['matiere'] ?? '');
        $niveau = nettoyer($_POST['niveau'] ?? '');
        $raison = nettoyer($_POST['raison'] ?? '');
        $est_brouillon = isset($_POST['enregistrer_brouillon']) ? 1 : 0;
        
        $date_seance_nouvelle = $type_demande === 'modification' ? nettoyer($_POST['date_seance_nouvelle'] ?? '') : null;
        $heure_debut_nouvelle = $type_demande === 'modification' ? nettoyer($_POST['heure_debut_nouvelle'] ?? '') : null;
        $heure_fin_nouvelle = $type_demande === 'modification' ? nettoyer($_POST['heure_fin_nouvelle'] ?? '') : null;
        $salle_nouvelle = $type_demande === 'modification' ? nettoyer($_POST['salle_nouvelle'] ?? '') : null;
        
        // Gestion upload nouvelle pièce jointe
        $piece_jointe = $demande['piece_jointe'];
        if (isset($_FILES['piece_jointe']) && $_FILES['piece_jointe']['error'] === UPLOAD_ERR_OK) {
            $file_tmp = $_FILES['piece_jointe']['tmp_name'];
            $file_name = $_FILES['piece_jointe']['name'];
            $file_size = $_FILES['piece_jointe']['size'];
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            
            $allowed_ext = ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'];
            $max_size = 5 * 1024 * 1024;
            
            if (!in_array($file_ext, $allowed_ext)) {
                $erreur = "Format de fichier non autorisé.";
            } elseif ($file_size > $max_size) {
                $erreur = "Le fichier est trop volumineux (max 5 MB).";
            } else {
                $upload_dir = '../uploads/justificatifs/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                
                // Supprimer l'ancienne pièce jointe
                if ($piece_jointe && file_exists($upload_dir . $piece_jointe)) {
                    unlink($upload_dir . $piece_jointe);
                }
                
                $new_filename = uniqid('justif_') . '_' . time() . '.' . $file_ext;
                $upload_path = $upload_dir . $new_filename;
                
                if (move_uploaded_file($file_tmp, $upload_path)) {
                    $piece_jointe = $new_filename;
                } else {
                    $erreur = "Erreur lors de l'upload du fichier.";
                }
            }
        }
        
        if (empty($erreur)) {
            $stmt = $pdo->prepare("
                UPDATE demandes SET
                    type_demande = ?,
                    date_seance_originale = ?,
                    heure_debut_originale = ?,
                    heure_fin_originale = ?,
                    salle_originale = ?,
                    matiere = ?,
                    niveau = ?,
                    date_seance_nouvelle = ?,
                    heure_debut_nouvelle = ?,
                    heure_fin_nouvelle = ?,
                    salle_nouvelle = ?,
                    raison = ?,
                    piece_jointe = ?,
                    est_brouillon = ?,
                    date_modification = NOW()
                WHERE id = ? AND professeur_id = ?
            ");
            
            $stmt->execute([
                $type_demande,
                $date_seance_originale,
                $heure_debut_originale,
                $heure_fin_originale,
                $salle_originale,
                $matiere,
                $niveau,
                $date_seance_nouvelle,
                $heure_debut_nouvelle,
                $heure_fin_nouvelle,
                $salle_nouvelle,
                $raison,
                $piece_jointe,
                $est_brouillon,
                $demande_id,
                $_SESSION['utilisateur_id']
            ]);
            
            // Si la demande est soumise (plus un brouillon), créer notification
            if (!$est_brouillon) {
                $stmt_assistante = $pdo->query("SELECT id FROM utilisateurs WHERE role = 'Assistante' LIMIT 1");
                $assistante = $stmt_assistante->fetch();
                
                if ($assistante) {
                    $message = "Demande #$demande_id modifiée et soumise par " . $_SESSION['utilisateur_prenom'] . " " . $_SESSION['utilisateur_nom'];
                    $stmt_notif = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
                    $stmt_notif->execute([$assistante['id'], $demande_id, $message]);
                }
                
                envoyerEmailNotification($_SESSION['utilisateur_email'], 'Demande soumise', 
                    "Votre demande #$demande_id a été modifiée et soumise avec succès.");
            }
            
            loggerActivite($_SESSION['utilisateur_id'], $est_brouillon ? 'modification_brouillon' : 'soumission_brouillon', $demande_id);
            
            $succes = $est_brouillon ? "Brouillon modifié avec succès." : "Demande soumise avec succès.";
        }
    }
}

$csrf_token = genererTokenCSRF();
include '../includes/header.php';
?>

<main class="container">
    <div class="page-header">
        <h1>Modifier la demande #<?php echo echapper($demande_id); ?></h1>
        <a href="<?php echo BASE_URL; ?>/pages/demandes.php" class="btn btn-secondary">Retour</a>
    </div>
    
    <?php if ($erreur): ?>
        <div class="alert alert-error"><?php echo echapper($erreur); ?></div>
    <?php endif; ?>
    
    <?php if ($succes): ?>
        <div class="alert alert-success"><?php echo echapper($succes); ?></div>
    <?php endif; ?>
    
    <div class="card">
        <form method="POST" action="" class="form" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?php echo echapper($csrf_token); ?>">
            
            <div class="form-section">
                <h3>Type de demande</h3>
                <div class="form-group">
                    <label>
                        <input type="radio" name="type_demande" value="modification" required <?php echo $demande['type_demande'] === 'modification' ? 'checked' : ''; ?>>
                        <span>Modification de séance</span>
                    </label>
                    <label>
                        <input type="radio" name="type_demande" value="annulation" required <?php echo $demande['type_demande'] === 'annulation' ? 'checked' : ''; ?>>
                        <span>Annulation de séance</span>
                    </label>
                </div>
            </div>
            
            <div class="form-section">
                <h3>Informations de la séance actuelle</h3>
                <div class="form-row">
                    <div class="form-group">
                        <label for="matiere">Matière *</label>
                        <input type="text" id="matiere" name="matiere" required value="<?php echo echapper($demande['matiere']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="niveau">Niveau *</label>
                        <input type="text" id="niveau" name="niveau" required value="<?php echo echapper($demande['niveau']); ?>">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="date_seance_originale">Date de la séance *</label>
                        <input type="date" id="date_seance_originale" name="date_seance_originale" required value="<?php echo echapper($demande['date_seance_originale']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="salle_originale">Salle *</label>
                        <input type="text" id="salle_originale" name="salle_originale" required value="<?php echo echapper($demande['salle_originale']); ?>">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="heure_debut_originale">Heure de début *</label>
                        <input type="time" id="heure_debut_originale" name="heure_debut_originale" required value="<?php echo echapper($demande['heure_debut_originale']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="heure_fin_originale">Heure de fin *</label>
                        <input type="time" id="heure_fin_originale" name="heure_fin_originale" required value="<?php echo echapper($demande['heure_fin_originale']); ?>">
                    </div>
                </div>
            </div>
            
            <div class="form-section modification-fields">
                <h3>Nouvelles informations (pour modification uniquement)</h3>
                <div class="form-row">
                    <div class="form-group">
                        <label for="date_seance_nouvelle">Nouvelle date</label>
                        <input type="date" id="date_seance_nouvelle" name="date_seance_nouvelle" value="<?php echo echapper($demande['date_seance_nouvelle'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="salle_nouvelle">Nouvelle salle</label>
                        <input type="text" id="salle_nouvelle" name="salle_nouvelle" value="<?php echo echapper($demande['salle_nouvelle'] ?? ''); ?>">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="heure_debut_nouvelle">Nouvelle heure de début</label>
                        <input type="time" id="heure_debut_nouvelle" name="heure_debut_nouvelle" value="<?php echo echapper($demande['heure_debut_nouvelle'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="heure_fin_nouvelle">Nouvelle heure de fin</label>
                        <input type="time" id="heure_fin_nouvelle" name="heure_fin_nouvelle" value="<?php echo echapper($demande['heure_fin_nouvelle'] ?? ''); ?>">
                    </div>
                </div>
            </div>
            
            <div class="form-section">
                <h3>Raison de la demande</h3>
                <div class="form-group">
                    <label for="raison">Expliquez la raison de votre demande *</label>
                    <textarea id="raison" name="raison" required rows="5"><?php echo echapper($demande['raison']); ?></textarea>
                </div>
                
                <div class="form-group">
                    <label for="piece_jointe">Pièce justificative</label>
                    <?php if ($demande['piece_jointe']): ?>
                        <p style="margin-bottom: 8px;">
                            Fichier actuel: <a href="<?php echo BASE_URL; ?>/uploads/justificatifs/<?php echo echapper($demande['piece_jointe']); ?>" target="_blank">Télécharger</a>
                        </p>
                    <?php endif; ?>
                    <input type="file" id="piece_jointe" name="piece_jointe" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx">
                    <small style="color: #64748b;">Formats acceptés: PDF, JPG, PNG, DOC, DOCX (max 5 MB)</small>
                </div>
            </div>
            
            <div class="form-actions">
                <a href="<?php echo BASE_URL; ?>/pages/demandes.php" class="btn btn-secondary">Annuler</a>
                <button type="submit" name="enregistrer_brouillon" class="btn btn-outline">Enregistrer comme brouillon</button>
                <button type="submit" class="btn btn-primary">Soumettre la demande</button>
            </div>
        </form>
    </div>
</main>

<?php include '../includes/footer.php'; ?>
