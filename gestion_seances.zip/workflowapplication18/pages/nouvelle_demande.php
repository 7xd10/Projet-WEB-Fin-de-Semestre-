<?php
$page_title = 'Nouvelle demande';
require_once '../config/init.php';
protegerPageRole('professeur');

$pdo = getDatabase();
$erreur = '';
$succes = '';

$stmt_seances = $pdo->prepare("
    SELECT e.*, m.nom as matiere_nom, s.nom as salle_nom 
    FROM emploi_temps e
    LEFT JOIN matieres m ON e.matiere = m.code
    LEFT JOIN salles s ON e.salle = s.nom
    WHERE e.professeur_id = ? AND e.date_seance >= CURDATE()
    ORDER BY e.date_seance, e.heure_debut
");
$stmt_seances->execute([$_SESSION['utilisateur_id']]);
$seances_planifiees = $stmt_seances->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifierTokenCSRF($_POST['csrf_token'] ?? '')) {
        $erreur = "Token de sécurité invalide.";
    } else {
        $type_demande = nettoyer($_POST['type_demande'] ?? '');
        
        $seance_id = isset($_POST['seance_existante']) && !empty($_POST['seance_existante']) ? (int)$_POST['seance_existante'] : null;
        
        if ($seance_id) {
            $stmt_seance = $pdo->prepare("SELECT * FROM emploi_temps WHERE id = ? AND professeur_id = ?");
            $stmt_seance->execute([$seance_id, $_SESSION['utilisateur_id']]);
            $seance = $stmt_seance->fetch();
            
            if ($seance) {
                $date_seance_originale = $seance['date_seance'];
                $heure_debut_originale = $seance['heure_debut'];
                $heure_fin_originale = $seance['heure_fin'];
                $salle_originale = $seance['salle'];
                $matiere = $seance['matiere'];
                $niveau = $seance['groupe'] ?? 'Non spécifié';
            } else {
                $erreur = "Séance non trouvée";
            }
        } else {
            $date_seance_originale = nettoyer($_POST['date_seance_originale'] ?? '');
            $heure_debut_originale = nettoyer($_POST['heure_debut_originale'] ?? '');
            $heure_fin_originale = nettoyer($_POST['heure_fin_originale'] ?? '');
            $salle_originale = nettoyer($_POST['salle_originale'] ?? '');
            $matiere = nettoyer($_POST['matiere'] ?? '');
            $niveau = nettoyer($_POST['niveau'] ?? '');
        }
        
        $raison = nettoyer($_POST['raison'] ?? '');
        
        $est_brouillon = isset($_POST['enregistrer_brouillon']) ? 1 : 0;
        
        $date_seance_nouvelle = $type_demande === 'modification' ? nettoyer($_POST['date_seance_nouvelle'] ?? '') : null;
        $heure_debut_nouvelle = $type_demande === 'modification' ? nettoyer($_POST['heure_debut_nouvelle'] ?? '') : null;
        $heure_fin_nouvelle = $type_demande === 'modification' ? nettoyer($_POST['heure_fin_nouvelle'] ?? '') : null;
        $salle_nouvelle = $type_demande === 'modification' ? nettoyer($_POST['salle_nouvelle'] ?? '') : null;
        
        $piece_jointe = null;
        if (isset($_FILES['piece_jointe']) && $_FILES['piece_jointe']['error'] === UPLOAD_ERR_OK) {
            $file_tmp = $_FILES['piece_jointe']['tmp_name'];
            $file_name = $_FILES['piece_jointe']['name'];
            $file_size = $_FILES['piece_jointe']['size'];
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            
            $allowed_ext = ['pdf', 'jpg', 'jpeg', 'png'];
            $max_size = 5 * 1024 * 1024; // 5 MB
            
            if (!in_array($file_ext, $allowed_ext)) {
                $erreur = "Format de fichier non autorisé. Formats acceptés: PDF, JPG, PNG.";
            } elseif ($file_size > $max_size) {
                $erreur = "Le fichier est trop volumineux (max 5 MB).";
            } else {
                $upload_dir = '../uploads/justificatifs/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                $new_filename = uniqid('justif_') . '_' . time() . '.' . $file_ext;
                $upload_path = $upload_dir . $new_filename;
                
                if (move_uploaded_file($file_tmp, $upload_path)) {
                    $piece_jointe = $new_filename;
                } else {
                    $erreur = "Erreur lors de l'upload du fichier.";
                }
            }
        }
        
        if (empty($erreur)) {
            if (strlen($raison) < 20) {
                $erreur = "Le motif doit contenir au moins 20 caractères.";
            } elseif (empty($type_demande) || empty($date_seance_originale) || empty($heure_debut_originale) || 
                empty($heure_fin_originale) || empty($salle_originale) || empty($matiere) || 
                empty($niveau)) {
                $erreur = "Tous les champs obligatoires doivent être remplis.";
            } elseif (!in_array($type_demande, ['modification', 'annulation'])) {
                $erreur = "Type de demande invalide.";
            } elseif (!$est_brouillon && strtotime($date_seance_originale) < strtotime('today')) {
                $erreur = "La date de la séance doit être dans le futur.";
            } elseif ($type_demande === 'modification' && !$est_brouillon && (empty($date_seance_nouvelle) || empty($heure_debut_nouvelle) || empty($heure_fin_nouvelle) || empty($salle_nouvelle))) {
                $erreur = "Pour une modification, les nouvelles informations sont obligatoires.";
            } else {
                $conflit_detecte = false;
                $message_conflit = '';
                
                if ($type_demande === 'modification' && !$est_brouillon && $date_seance_nouvelle && $heure_debut_nouvelle && $heure_fin_nouvelle && $salle_nouvelle) {
                    $stmt_conflit_salle = $pdo->prepare("
                        SELECT COUNT(*) as nb FROM emploi_temps 
                        WHERE date_seance = ? 
                        AND salle = ? 
                        AND (
                            (heure_debut <= ? AND heure_fin > ?) OR
                            (heure_debut < ? AND heure_fin >= ?) OR
                            (heure_debut >= ? AND heure_fin <= ?)
                        )
                        AND disponible = FALSE
                    ");
                    $stmt_conflit_salle->execute([
                        $date_seance_nouvelle, 
                        $salle_nouvelle,
                        $heure_debut_nouvelle, $heure_debut_nouvelle,
                        $heure_fin_nouvelle, $heure_fin_nouvelle,
                        $heure_debut_nouvelle, $heure_fin_nouvelle
                    ]);
                    $conflit_salle = $stmt_conflit_salle->fetch();
                    
                    if ($conflit_salle['nb'] > 0) {
                        $conflit_detecte = true;
                        $message_conflit .= "⚠️ La salle $salle_nouvelle est déjà occupée à cette date et heure. ";
                    }
                    
                    $stmt_conflit_prof = $pdo->prepare("
                        SELECT COUNT(*) as nb FROM emploi_temps 
                        WHERE date_seance = ? 
                        AND professeur_id = ? 
                        AND (
                            (heure_debut <= ? AND heure_fin > ?) OR
                            (heure_debut < ? AND heure_fin >= ?) OR
                            (heure_debut >= ? AND heure_fin <= ?)
                        )
                        AND disponible = FALSE
                    ");
                    $stmt_conflit_prof->execute([
                        $date_seance_nouvelle, 
                        $_SESSION['utilisateur_id'],
                        $heure_debut_nouvelle, $heure_debut_nouvelle,
                        $heure_fin_nouvelle, $heure_fin_nouvelle,
                        $heure_debut_nouvelle, $heure_fin_nouvelle
                    ]);
                    $conflit_prof = $stmt_conflit_prof->fetch();
                    
                    if ($conflit_prof['nb'] > 0) {
                        $conflit_detecte = true;
                        $message_conflit .= "⚠️ Vous avez déjà un cours programmé à cette date et heure. ";
                    }
                }
                
                if ($conflit_detecte && !$est_brouillon) {
                    $erreur = $message_conflit . "Veuillez choisir une autre date/heure ou sauvegarder comme brouillon.";
                } else {
                    try {
                        $stmt = $pdo->prepare("
                            INSERT INTO demandes (
                                professeur_id, type_demande, date_seance_originale, 
                                heure_debut_originale, heure_fin_originale, salle_originale,
                                matiere, niveau, date_seance_nouvelle, heure_debut_nouvelle,
                                heure_fin_nouvelle, salle_nouvelle, raison, piece_jointe, est_brouillon,
                                disponibilite_verifiee
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ");
                        
                        $stmt->execute([
                            $_SESSION['utilisateur_id'],
                            $type_demande,
                            $date_seance_originale,
                            $heure_debut_originale,
                            $heure_fin_originale,
                            $salle_originale,
                            $matiere,
                            $niveau,
                            $date_seance_nouvelle,
                            $heure_debut_nouvelle,
                            $heure_fin_nouvelle,
                            $salle_nouvelle,
                            $raison,
                            $piece_jointe,
                            $est_brouillon,
                            !$conflit_detecte ? 1 : 0
                        ]);
                        
                        $demande_id = $pdo->lastInsertId();
                        
                        if (!$est_brouillon) {
                            $stmt_assistante = $pdo->query("SELECT id FROM utilisateurs WHERE role = 'Assistante' LIMIT 1");
                            $assistante = $stmt_assistante->fetch();
                            
                            if ($assistante) {
                                $message = "Nouvelle demande de " . $_SESSION['utilisateur_prenom'] . " " . $_SESSION['utilisateur_nom'] . " - " . ucfirst($type_demande) . " de séance";
                                $stmt_notif = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
                                $stmt_notif->execute([$assistante['id'], $demande_id, $message]);
                            }
                            
                            envoyerEmailNotification($_SESSION['utilisateur_email'], 'Demande soumise', 
                                "Votre demande #$demande_id a été soumise avec succès et est en attente de traitement.");
                        }
                        
                        loggerActivite($_SESSION['utilisateur_id'], $est_brouillon ? 'creation_brouillon' : 'creation_demande', $demande_id);
                        
                        $succes = $est_brouillon ? "Brouillon enregistré avec succès. Vous pouvez le modifier à tout moment." : "Demande créée avec succès. Elle sera examinée par l'assistante administrative.";
                        
                    } catch (PDOException $e) {
                        error_log("Erreur lors de la création de la demande: " . $e->getMessage());
                        $erreur = "Une erreur est survenue. Veuillez réessayer.";
                    }
                }
            }
        }
    }
}

$csrf_token = genererTokenCSRF();
include '../includes/header.php';
?>

<main class="container">
    <div class="page-header">
        <h1>📝 Nouvelle demande de changement/annulation</h1>
        <p>Remplissez le formulaire pour soumettre votre demande</p>
    </div>
    
    <?php if ($erreur): ?>
        <div class="alert alert-error" style="padding: 16px; background: #fee; border-left: 4px solid #f00; border-radius: 8px; margin-bottom: 20px;">
            ❌ <?php echo echapper($erreur); ?>
        </div>
    <?php endif; ?>
    
    <?php if ($succes): ?>
        <div class="alert alert-success" style="padding: 16px; background: #efe; border-left: 4px solid #0a0; border-radius: 8px; margin-bottom: 20px;">
            ✅ <?php echo echapper($succes); ?>
        </div>
    <?php endif; ?>
    
    <div class="card">
        <form method="POST" action="" class="form" enctype="multipart/form-data" id="formDemande">
            <input type="hidden" name="csrf_token" value="<?php echo echapper($csrf_token); ?>">
            
            <div class="form-section">
                <h3 style="margin-bottom: 16px; font-size: 20px; color: #1e293b;">Type de demande</h3>
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 10px; padding: 12px; border: 2px solid #cbd5e1; border-radius: 8px; cursor: pointer; margin-bottom: 10px;">
                        <input type="radio" name="type_demande" value="modification" required checked>
                        <span style="font-weight: 500;">✏️ Modification de séance</span>
                    </label>
                    <label style="display: flex; align-items: center; gap: 10px; padding: 12px; border: 2px solid #cbd5e1; border-radius: 8px; cursor: pointer;">
                        <input type="radio" name="type_demande" value="annulation" required>
                        <span style="font-weight: 500;">❌ Annulation de séance</span>
                    </label>
                </div>
            </div>
            
            <div class="form-section" style="background: #f8fafc; padding: 24px; border-radius: 12px; border: 2px solid #e2e8f0; margin-top: 20px;">
                <h3 style="color: #1e293b; margin-bottom: 16px;">📋 Sélectionner une séance planifiée</h3>
                <p style="color: #64748b; margin-bottom: 16px; font-size: 14px;">
                    Vous pouvez sélectionner une séance existante depuis votre emploi du temps ou remplir manuellement les informations.
                </p>
                
                <div class="form-group">
                    <label for="seance_existante" style="font-weight: 600; display: block; margin-bottom: 8px;">Séance planifiée (optionnel)</label>
                    <select id="seance_existante" name="seance_existante" style="width: 100%; padding: 12px; border-radius: 8px; border: 2px solid #cbd5e1; font-size: 15px;">
                        <option value="">-- Saisir manuellement --</option>
                        <?php foreach ($seances_planifiees as $seance): ?>
                            <option value="<?php echo $seance['id']; ?>" 
                                    data-date="<?php echo $seance['date_seance']; ?>"
                                    data-debut="<?php echo $seance['heure_debut']; ?>"
                                    data-fin="<?php echo $seance['heure_fin']; ?>"
                                    data-salle="<?php echo $seance['salle']; ?>"
                                    data-matiere="<?php echo echapper($seance['matiere']); ?>"
                                    data-groupe="<?php echo echapper($seance['groupe'] ?? ''); ?>">
                                <?php 
                                echo date('d/m/Y', strtotime($seance['date_seance'])) . ' • ' . 
                                     date('H:i', strtotime($seance['heure_debut'])) . '-' . 
                                     date('H:i', strtotime($seance['heure_fin'])) . ' • ' . 
                                     echapper($seance['matiere']) . ' • Salle ' . echapper($seance['salle']);
                                ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group" style="margin-top: 16px;">
                    <label for="recherche_date" style="font-weight: 600; display: block; margin-bottom: 8px;">🔍 Rechercher par date</label>
                    <input type="date" id="recherche_date" style="width: 100%; padding: 12px; border-radius: 8px; border: 2px solid #cbd5e1;">
                    <small style="color: #64748b; display: block; margin-top: 8px;">
                        Filtrer les séances par date pour faciliter la sélection
                    </small>
                </div>
            </div>
            
            <div class="form-section" style="margin-top: 20px;">
                <h3>Informations de la séance actuelle</h3>
                <div class="form-row">
                    <div class="form-group">
                        <label for="matiere">Matière *</label>
                        <input type="text" id="matiere" name="matiere" required maxlength="100" 
                               style="width: 100%; padding: 12px; border: 2px solid #cbd5e1; border-radius: 8px;"
                               value="<?php echo isset($_POST['matiere']) ? echapper($_POST['matiere']) : ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="niveau">Niveau/Groupe *</label>
                        <input type="text" id="niveau" name="niveau" required maxlength="50" 
                               style="width: 100%; padding: 12px; border: 2px solid #cbd5e1; border-radius: 8px;"
                               value="<?php echo isset($_POST['niveau']) ? echapper($_POST['niveau']) : ''; ?>">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="date_seance_originale">Date de la séance *</label>
                        <input type="date" id="date_seance_originale" name="date_seance_originale" required 
                               style="width: 100%; padding: 12px; border: 2px solid #cbd5e1; border-radius: 8px;"
                               min="<?php echo date('Y-m-d'); ?>" 
                               value="<?php echo isset($_POST['date_seance_originale']) ? echapper($_POST['date_seance_originale']) : ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="salle_originale">Salle *</label>
                        <input type="text" id="salle_originale" name="salle_originale" required maxlength="50" 
                               style="width: 100%; padding: 12px; border: 2px solid #cbd5e1; border-radius: 8px;"
                               placeholder="Ex: B205"
                               value="<?php echo isset($_POST['salle_originale']) ? echapper($_POST['salle_originale']) : ''; ?>">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="heure_debut_originale">Heure de début *</label>
                        <input type="time" id="heure_debut_originale" name="heure_debut_originale" required 
                               style="width: 100%; padding: 12px; border: 2px solid #cbd5e1; border-radius: 8px;"
                               value="<?php echo isset($_POST['heure_debut_originale']) ? echapper($_POST['heure_debut_originale']) : ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="heure_fin_originale">Heure de fin *</label>
                        <input type="time" id="heure_fin_originale" name="heure_fin_originale" required 
                               style="width: 100%; padding: 12px; border: 2px solid #cbd5e1; border-radius: 8px;"
                               value="<?php echo isset($_POST['heure_fin_originale']) ? echapper($_POST['heure_fin_originale']) : ''; ?>">
                    </div>
                </div>
            </div>
            
            <div class="form-section modification-fields" style="margin-top: 20px;">
                <h3>Nouvelles informations (pour modification uniquement)</h3>
                <p style="color: #64748b; margin-bottom: 16px; font-size: 14px;">
                    ⚠️ Le système vérifiera automatiquement les conflits de salle et d'emploi du temps
                </p>
                <div class="form-row">
                    <div class="form-group">
                        <label for="date_seance_nouvelle">Nouvelle date</label>
                        <input type="date" id="date_seance_nouvelle" name="date_seance_nouvelle" 
                               style="width: 100%; padding: 12px; border: 2px solid #cbd5e1; border-radius: 8px;"
                               min="<?php echo date('Y-m-d'); ?>" 
                               value="<?php echo isset($_POST['date_seance_nouvelle']) ? echapper($_POST['date_seance_nouvelle']) : ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="salle_nouvelle">Nouvelle salle</label>
                        <input type="text" id="salle_nouvelle" name="salle_nouvelle" maxlength="50" 
                               style="width: 100%; padding: 12px; border: 2px solid #cbd5e1; border-radius: 8px;"
                               placeholder="Ex: B205"
                               value="<?php echo isset($_POST['salle_nouvelle']) ? echapper($_POST['salle_nouvelle']) : ''; ?>">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="heure_debut_nouvelle">Nouvelle heure de début</label>
                        <input type="time" id="heure_debut_nouvelle" name="heure_debut_nouvelle" 
                               style="width: 100%; padding: 12px; border: 2px solid #cbd5e1; border-radius: 8px;"
                               value="<?php echo isset($_POST['heure_debut_nouvelle']) ? echapper($_POST['heure_debut_nouvelle']) : ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="heure_fin_nouvelle">Nouvelle heure de fin</label>
                        <input type="time" id="heure_fin_nouvelle" name="heure_fin_nouvelle" 
                               style="width: 100%; padding: 12px; border: 2px solid #cbd5e1; border-radius: 8px;"
                               value="<?php echo isset($_POST['heure_fin_nouvelle']) ? echapper($_POST['heure_fin_nouvelle']) : ''; ?>">
                    </div>
                </div>
                
                <div id="conflit-indicator" style="display: none; padding: 16px; border-radius: 8px; margin-top: 16px;"></div>
            </div>
            
            <div class="form-section" style="margin-top: 20px;">
                <h3>Raison et justificatifs</h3>
                <div class="form-group">
                    <label for="raison">Expliquez la raison de votre demande * (minimum 20 caractères)</label>
                    <textarea id="raison" name="raison" required rows="5" maxlength="1000" 
                              style="width: 100%; padding: 12px; border: 2px solid #cbd5e1; border-radius: 8px; resize: vertical;"
                              placeholder="Expliquez la raison de votre demande..."><?php echo isset($_POST['raison']) ? echapper($_POST['raison']) : ''; ?></textarea>
                    <small id="compteur-raison" style="display: block; margin-top: 8px; font-weight: 600; color: #64748b;">
                        0 / 20 caractères minimum
                    </small>
                </div>
                
                <div class="form-group" style="margin-top: 24px; padding: 24px; background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%); border-radius: 12px; border: 3px dashed #22c55e; box-shadow: 0 2px 8px rgba(34, 197, 94, 0.1);">
                    <label for="piece_jointe" style="font-weight: 700; color: #166534; display: flex; align-items: center; gap: 8px; margin-bottom: 12px; font-size: 18px;">
                        📎 Ajouter une pièce justificative (optionnel)
                    </label>
                    <input type="file" id="piece_jointe" name="piece_jointe" accept=".pdf,.jpg,.jpeg,.png" 
                           style="width: 100%; padding: 16px; border: 2px solid #22c55e; border-radius: 8px; background: white; font-size: 15px; cursor: pointer; font-weight: 500;">
                    <div style="margin-top: 14px; padding: 12px; background: white; border-radius: 8px; border: 1px solid #86efac;">
                        <p style="color: #166534; margin: 0 0 8px 0; font-weight: 600; font-size: 14px;">📋 Informations importantes :</p>
                        <ul style="color: #166534; margin: 0; padding-left: 20px; line-height: 1.8; font-size: 14px;">
                            <li><strong>Formats acceptés:</strong> PDF, JPG, JPEG, PNG</li>
                            <li><strong>Taille maximum:</strong> 5 MB</li>
                            <li><strong>Exemples:</strong> Certificat médical, convocation administrative, justificatif officiel</li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <div class="form-actions" style="display: flex; gap: 16px; justify-content: flex-end; align-items: center; margin-top: 40px; padding-top: 30px; border-top: 3px solid #e2e8f0;">
                <a href="<?php echo BASE_URL; ?>/pages/demandes.php" 
                   style="display: inline-block; padding: 16px 28px; background: #f1f5f9; color: #475569; border: 2px solid #cbd5e1; border-radius: 10px; text-decoration: none; font-weight: 700; font-size: 16px; transition: all 0.3s; box-shadow: 0 2px 4px rgba(0,0,0,0.1); cursor: pointer;"
                   onmouseover="this.style.background='#e2e8f0'" 
                   onmouseout="this.style.background='#f1f5f9'">
                    ❌ Annuler
                </a>
                
                <button type="submit" name="enregistrer_brouillon" value="1"
                        style="padding: 16px 32px; background: white; color: #0ea5e9; border: 3px solid #0ea5e9; border-radius: 10px; font-weight: 700; cursor: pointer; font-size: 16px; transition: all 0.3s; box-shadow: 0 2px 8px rgba(14, 165, 233, 0.2);"
                        onmouseover="this.style.background='#e0f2fe'" 
                        onmouseout="this.style.background='white'">
                    💾 Enregistrer comme brouillon
                </button>
                
                <button type="submit" name="soumettre_demande" value="1"
                        style="padding: 16px 36px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 10px; font-weight: 700; cursor: pointer; font-size: 16px; box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4); transition: all 0.3s;"
                        onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 8px 25px rgba(102, 126, 234, 0.5)'" 
                        onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 6px 20px rgba(102, 126, 234, 0.4)'">
                    ✉️ Soumettre la demande
                </button>
            </div>
        </form>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const typeRadios = document.querySelectorAll('input[name="type_demande"]');
    const modifFields = document.querySelector('.modification-fields');
    
    typeRadios.forEach(function(radio) {
        radio.addEventListener('change', function() {
            if (this.value === 'modification') {
                modifFields.style.display = 'block';
            } else {
                modifFields.style.display = 'none';
            }
        });
    });
    
    const seanceSelect = document.getElementById('seance_existante');
    if (seanceSelect) {
        seanceSelect.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            if (this.value && selectedOption.dataset.date) {
                document.getElementById('date_seance_originale').value = selectedOption.dataset.date || '';
                document.getElementById('heure_debut_originale').value = selectedOption.dataset.debut || '';
                document.getElementById('heure_fin_originale').value = selectedOption.dataset.fin || '';
                document.getElementById('salle_originale').value = selectedOption.dataset.salle || '';
                document.getElementById('matiere').value = selectedOption.dataset.matiere || '';
                document.getElementById('niveau').value = selectedOption.dataset.groupe || '';
            }
        });
    }
    
    const rechercheDate = document.getElementById('recherche_date');
    if (rechercheDate) {
        rechercheDate.addEventListener('change', function() {
            const date = this.value;
            const select = document.getElementById('seance_existante');
            const options = select.getElementsByTagName('option');
            
            for (let i = 1; i < options.length; i++) {
                const optionDate = options[i].dataset.date;
                if (!date || optionDate === date) {
                    options[i].style.display = 'block';
                } else {
                    options[i].style.display = 'none';
                }
            }
        });
    }
    
    const raisonTextarea = document.getElementById('raison');
    const compteur = document.getElementById('compteur-raison');
    
    if (raisonTextarea && compteur) {
        raisonTextarea.addEventListener('keyup', function() {
            const count = this.value.length;
            
            if (count < 20) {
                compteur.textContent = count + ' / 20 caractères minimum ⚠️';
                compteur.style.color = '#dc2626';
                compteur.style.fontWeight = '700';
                this.style.borderColor = '#fca5a5';
                this.style.background = '#fef2f2';
            } else {
                compteur.textContent = count + ' caractères ✅';
                compteur.style.color = '#16a34a';
                compteur.style.fontWeight = '700';
                this.style.borderColor = '#86efac';
                this.style.background = '#f0fdf4';
            }
        });
        
        if (raisonTextarea.value.length > 0) {
            raisonTextarea.dispatchEvent(new Event('keyup'));
        }
    }
});
</script>

<?php include '../includes/footer.php'; ?>
