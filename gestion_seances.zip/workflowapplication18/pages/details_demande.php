<?php
$page_title = 'Détails de la demande';
require_once '../config/init.php';
protegerPage();

$pdo = getDatabase();
$role = $_SESSION['utilisateur_role'];
$utilisateur_id = $_SESSION['utilisateur_id'];

$demande_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($role === 'professeur') {
    $stmt = $pdo->prepare("SELECT * FROM demandes WHERE id = ? AND professeur_id = ?");
    $stmt->execute([$demande_id, $utilisateur_id]);
} else {
    $stmt = $pdo->prepare("
        SELECT d.*, u.nom, u.prenom, u.email, u.departement, u.telephone 
        FROM demandes d 
        JOIN utilisateurs u ON d.professeur_id = u.id 
        WHERE d.id = ?
    ");
    $stmt->execute([$demande_id]);
}

$demande = $stmt->fetch();

$erreur = '';
$succes = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifierTokenCSRF($_POST['csrf_token'] ?? '')) {
        $erreur = "Token de sécurité invalide.";
    } else {
        $action = nettoyer($_POST['action'] ?? '');
        $commentaire = nettoyer($_POST['commentaire'] ?? '');
        
        if ($role === 'professeur' && $action === 'annuler' && $demande['statut_assistante'] === 'En attente') {
            $motif_annulation = nettoyer($_POST['motif_annulation'] ?? '');
            
            if (empty($motif_annulation)) {
                $erreur = "Le motif d'annulation est obligatoire.";
            } else {
                $stmt = $pdo->prepare("
                    UPDATE demandes 
                    SET annule = 1, motif_annulation = ?, date_annulation = NOW()
                    WHERE id = ? AND professeur_id = ?
                ");
                $stmt->execute([$motif_annulation, $demande_id, $utilisateur_id]);
                
                $stmt_ass = $pdo->query("SELECT id FROM utilisateurs WHERE role = 'assistante' LIMIT 1");
                $assistante = $stmt_ass->fetch();
                if ($assistante) {
                    $message = "La demande #" . $demande_id . " a été annulée par le professeur";
                    $stmt_notif = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
                    $stmt_notif->execute([$assistante['id'], $demande_id, $message]);
                }
                
                loggerActivite($utilisateur_id, 'annulation_demande', $demande_id);
                $succes = "Demande annulée avec succès.";
            }
        }
        
        elseif ($role === 'assistante' && $demande['statut_assistante'] === 'En attente') {
            if ($action === 'valider') {
                $stmt = $pdo->prepare("
                    UPDATE demandes 
                    SET statut_assistante = 'Validé', 
                        commentaire_assistante = ?,
                        date_validation_assistante = NOW()
                    WHERE id = ?
                ");
                $stmt->execute([$commentaire, $demande_id]);
                
                $stmt_dir = $pdo->query("SELECT id FROM utilisateurs WHERE role = 'directeur' LIMIT 1");
                $directeur = $stmt_dir->fetch();
                if ($directeur) {
                    $message = "Nouvelle demande validée par l'assistante - Demande #" . $demande_id;
                    $stmt_notif = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
                    $stmt_notif->execute([$directeur['id'], $demande_id, $message]);
                }
                
                $message_prof = "Votre demande #" . $demande_id . " a été validée par l'assistante et transmise au directeur";
                $stmt_notif = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
                $stmt_notif->execute([$demande['professeur_id'], $demande_id, $message_prof]);
                
                envoyerEmailNotification($demande['email'], 'Demande validée', 
                    "Votre demande #$demande_id a été validée par l'assistante et transmise au directeur pour approbation finale.");
                
                loggerActivite($utilisateur_id, 'validation_assistante', $demande_id);
                $succes = "Demande validée avec succès.";
                
            } elseif ($action === 'refuser') {
                $stmt = $pdo->prepare("
                    UPDATE demandes 
                    SET statut_assistante = 'Refusé', 
                        commentaire_assistante = ?,
                        date_validation_assistante = NOW()
                    WHERE id = ?
                ");
                $stmt->execute([$commentaire, $demande_id]);
                
                $message_prof = "Votre demande #" . $demande_id . " a été refusée par l'assistante";
                $stmt_notif = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
                $stmt_notif->execute([$demande['professeur_id'], $demande_id, $message_prof]);
                
                envoyerEmailNotification($demande['email'], 'Demande refusée', 
                    "Votre demande #$demande_id a été refusée. Raison: $commentaire");
                
                loggerActivite($utilisateur_id, 'refus_assistante', $demande_id);
                $succes = "Demande refusée.";
                
            } 
            elseif ($action === 'demander_info') {
                $info_demandee = nettoyer($_POST['info_demandee'] ?? '');
                
                if (empty($info_demandee)) {
                    $erreur = "Veuillez préciser les informations demandées.";
                } else {
                    $stmt = $pdo->prepare("
                        UPDATE demandes 
                        SET statut_assistante = 'Info demandée', 
                            info_supplementaire_demandee = ?
                        WHERE id = ?
                    ");
                    $stmt->execute([$info_demandee, $demande_id]);
                    
                    $message_prof = "L'assistante demande des informations supplémentaires pour la demande #" . $demande_id;
                    $stmt_notif = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
                    $stmt_notif->execute([$demande['professeur_id'], $demande_id, $message_prof]);
                    
                    envoyerEmailNotification($demande['email'], 'Informations requises', 
                        "L'assistante demande des informations supplémentaires pour votre demande #$demande_id: $info_demandee");
                    
                    loggerActivite($utilisateur_id, 'demande_info', $demande_id);
                    $succes = "Demande d'informations envoyée au professeur.";
                }
            }
            elseif ($action === 'proposer_alternative') {
                $date_alt = nettoyer($_POST['date_alternative'] ?? '');
                $heure_debut_alt = nettoyer($_POST['heure_debut_alternative'] ?? '');
                $heure_fin_alt = nettoyer($_POST['heure_fin_alternative'] ?? '');
                $salle_alt = nettoyer($_POST['salle_alternative'] ?? '');
                $commentaire_alt = nettoyer($_POST['commentaire_alternative'] ?? '');
                
                if (empty($date_alt) || empty($heure_debut_alt) || empty($heure_fin_alt) || empty($salle_alt)) {
                    $erreur = "Tous les champs de l'alternative sont obligatoires.";
                } else {
                    $stmt = $pdo->prepare("
                        UPDATE demandes 
                        SET statut_assistante = 'Alternative proposée',
                            alternative_proposee = ?,
                            date_alternative = ?,
                            heure_debut_alternative = ?,
                            heure_fin_alternative = ?,
                            salle_alternative = ?
                        WHERE id = ?
                    ");
                    $stmt->execute([
                        $commentaire_alt,
                        $date_alt,
                        $heure_debut_alt,
                        $heure_fin_alt,
                        $salle_alt,
                        $demande_id
                    ]);
                    
                    $message_prof = "L'assistante propose une alternative pour la demande #" . $demande_id;
                    $stmt_notif = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
                    $stmt_notif->execute([$demande['professeur_id'], $demande_id, $message_prof]);
                    
                    envoyerEmailNotification($demande['email'], 'Alternative proposée', 
                        "L'assistante propose une alternative pour votre demande #$demande_id: $date_alt de $heure_debut_alt à $heure_fin_alt en salle $salle_alt.");
                    
                    loggerActivite($utilisateur_id, 'proposition_alternative', $demande_id);
                    $succes = "Alternative proposée au professeur.";
                }
            }
        }
        
        elseif ($role === 'directeur' && $demande['statut_assistante'] === 'Validé') {
            if ($action === 'valider') {
                $stmt = $pdo->prepare("
                    UPDATE demandes 
                    SET statut_directeur = 'Validé', 
                        commentaire_directeur = ?,
                        date_validation_directeur = NOW()
                    WHERE id = ?
                ");
                $stmt->execute([$commentaire, $demande_id]);
                
                $message_prof = "Votre demande #" . $demande_id . " a été validée par le directeur";
                $stmt_notif = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
                $stmt_notif->execute([$demande['professeur_id'], $demande_id, $message_prof]);
                
                $stmt_ass = $pdo->query("SELECT id FROM utilisateurs WHERE role = 'assistante' LIMIT 1");
                $assistante = $stmt_ass->fetch();
                if ($assistante) {
                    $message_ass = "La demande #" . $demande_id . " a été validée par le directeur";
                    $stmt_notif = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
                    $stmt_notif->execute([$assistante['id'], $demande_id, $message_ass]);
                }
                
                envoyerEmailNotification($demande['email'], 'Demande approuvée', 
                    "Votre demande #$demande_id a été approuvée par le directeur. Votre changement de séance est validé.");
                
                loggerActivite($utilisateur_id, 'validation_directeur', $demande_id);
                $succes = "Demande validée avec succès.";
                
            } elseif ($action === 'refuser') {
                $stmt = $pdo->prepare("
                    UPDATE demandes 
                    SET statut_directeur = 'Refusé', 
                        commentaire_directeur = ?,
                        date_validation_directeur = NOW()
                    WHERE id = ?
                ");
                $stmt->execute([$commentaire, $demande_id]);
                
                $message_prof = "Votre demande #" . $demande_id . " a été refusée par le directeur";
                $stmt_notif = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
                $stmt_notif->execute([$demande['professeur_id'], $demande_id, $message_prof]);
                
                envoyerEmailNotification($demande['email'], 'Demande refusée', 
                    "Votre demande #$demande_id a été refusée par le directeur. Raison: $commentaire");
                
                loggerActivite($utilisateur_id, 'refus_directeur', $demande_id);
                $succes = "Demande refusée.";
            }
        }
        
        if ($role === 'professeur') {
            $stmt = $pdo->prepare("SELECT * FROM demandes WHERE id = ? AND professeur_id = ?");
            $stmt->execute([$demande_id, $utilisateur_id]);
        } else {
            $stmt = $pdo->prepare("
                SELECT d.*, u.nom, u.prenom, u.email, u.departement, u.telephone 
                FROM demandes d 
                JOIN utilisateurs u ON d.professeur_id = u.id 
                WHERE d.id = ?
            ");
            $stmt->execute([$demande_id]);
        }
        $demande = $stmt->fetch();
    }
}

if (!$demande) {
    header('Location: ' . BASE_URL . '/pages/demandes.php');
    exit;
}

$csrf_token = genererTokenCSRF();
include '../includes/header.php';
?>

<main class="container">
    <div class="page-header">
        <h1>Demande #<?php echo echapper($demande['id']); ?></h1>
        <div>
            <a href="<?php echo BASE_URL; ?>/pages/demandes.php" class="btn btn-secondary">Retour à la liste</a>
            <?php if ($role === 'professeur' && $demande['statut_assistante'] === 'En attente'): ?>
                <a href="<?php echo BASE_URL; ?>/pages/demandes.php?action=supprimer&id=<?php echo echapper($demande['id']); ?>&csrf_token=<?php echo echapper(genererTokenCSRF()); ?>" 
                   class="btn btn-danger" 
                   onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette demande ? Cette action est irréversible.')">
                    Supprimer la demande
                </a>
            <?php endif; ?>
            <?php if ($role === 'professeur' && $demande['est_brouillon']): ?>
                <a href="<?php echo BASE_URL; ?>/pages/modifier_demande.php?id=<?php echo echapper($demande['id']); ?>" class="btn btn-primary">Modifier le brouillon</a>
            <?php endif; ?>
        </div>
    </div>
    
    <?php if ($erreur): ?>
        <div class="alert alert-error"><?php echo echapper($erreur); ?></div>
    <?php endif; ?>
    
    <?php if ($succes): ?>
        <div class="alert alert-success"><?php echo echapper($succes); ?></div>
    <?php endif; ?>
    
    <div class="demande-details">
        <div class="card">
            <div class="card-header">
                <h2>Informations générales</h2>
                <?php if ($demande['est_brouillon']): ?>
                    <span class="badge badge-secondary" style="margin-left: 16px;">Brouillon</span>
                <?php endif; ?>
            </div>
            <div class="demande-info">
                <?php if ($role !== 'professeur'): ?>
                    <div class="info-group">
                        <strong>Professeur:</strong>
                        <span><?php echo echapper($demande['prenom'] . ' ' . $demande['nom']); ?></span>
                    </div>
                    <div class="info-group">
                        <strong>Email:</strong>
                        <span><?php echo echapper($demande['email']); ?></span>
                    </div>
                    <div class="info-group">
                        <strong>Téléphone:</strong>
                        <span><?php echo echapper($demande['telephone'] ?? 'Non renseigné'); ?></span>
                    </div>
                    <div class="info-group">
                        <strong>Département:</strong>
                        <span><?php echo echapper($demande['departement']); ?></span>
                    </div>
                <?php endif; ?>
                
                <div class="info-group">
                    <strong>Type de demande:</strong>
                    <span class="badge badge-<?php echo $demande['type_demande'] === 'modification' ? 'info' : 'warning'; ?>">
                        <?php echo echapper(ucfirst($demande['type_demande'] ?? 'N/A')); ?>
                    </span>
                </div>
                
                <div class="info-group">
                    <strong>Matière:</strong>
                    <span><?php echo echapper($demande['matiere']); ?></span>
                </div>
                
                <div class="info-group">
                    <strong>Date de création:</strong>
                    <span><?php echo echapper(date('d/m/Y à H:i', strtotime($demande['date_creation']))); ?></span>
                </div>
                
                <div class="info-group">
                    <strong>Statut (Assistante):</strong>
                    <?php
                    $statut_classes = [
                        'En attente' => 'warning',
                        'Validé' => 'success',
                        'Refusé' => 'error',
                        'Info demandée' => 'info',
                        'Alternative proposée' => 'info'
                    ];
                    ?>
                    <span class="badge badge-<?php echo $statut_classes[$demande['statut_assistante']] ?? 'secondary'; ?>">
                        <?php echo echapper($demande['statut_assistante']); ?>
                    </span>
                </div>
                
                <?php if ($role === 'directeur' || ($role === 'assistante' && $demande['statut_assistante'] === 'Validé')): ?>
                    <div class="info-group">
                        <strong>Statut (Directeur):</strong>
                        <span class="badge badge-<?php echo $statut_classes[$demande['statut_directeur']] ?? 'secondary'; ?>">
                            <?php echo echapper($demande['statut_directeur']); ?>
                        </span>
                    </div>
                <?php endif; ?>
                
                <?php if ($demande['piece_jointe']): ?>
                    <div class="info-group" style="grid-column: 1 / -1;">
                        <strong>Pièce justificative:</strong>
                        <a href="<?php echo BASE_URL; ?>/uploads/justificatifs/<?php echo echapper($demande['piece_jointe']); ?>" 
                           target="_blank" class="btn btn-sm btn-primary" style="margin-left: 12px;">
                            📎 Télécharger la pièce jointe
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h2>Séance originale</h2>
            </div>
            <div class="demande-info">
                <!-- Fixed database field names from ancienne_date to date_seance_originale -->
                <div class="info-group">
                    <strong>Date:</strong>
                    <span><?php echo echapper(date('d/m/Y', strtotime($demande['date_seance_originale']))); ?></span>
                </div>
                <div class="info-group">
                    <strong>Horaire:</strong>
                    <span><?php echo echapper(date('H:i', strtotime($demande['heure_debut_originale']))); ?> - <?php echo echapper(date('H:i', strtotime($demande['heure_fin_originale']))); ?></span>
                </div>
                <div class="info-group">
                    <strong>Salle:</strong>
                    <span><?php echo echapper($demande['salle_originale']); ?></span>
                </div>
                <div class="info-group">
                    <strong>Niveau:</strong>
                    <span><?php echo echapper($demande['niveau']); ?></span>
                </div>
            </div>
        </div>
        
        <?php if ($demande['type_demande'] === 'modification' && $demande['date_seance_nouvelle']): ?>
        <div class="card">
            <div class="card-header">
                <h2>Nouvelle séance proposée</h2>
            </div>
            <div class="demande-info">
                <!-- Fixed database field names from nouvelle_date to date_seance_nouvelle -->
                <div class="info-group">
                    <strong>Date:</strong>
                    <span><?php echo echapper(date('d/m/Y', strtotime($demande['date_seance_nouvelle']))); ?></span>
                </div>
                <div class="info-group">
                    <strong>Horaire:</strong>
                    <span><?php echo echapper(date('H:i', strtotime($demande['heure_debut_nouvelle']))); ?> - <?php echo echapper(date('H:i', strtotime($demande['heure_fin_nouvelle']))); ?></span>
                </div>
                <div class="info-group">
                    <strong>Salle:</strong>
                    <span><?php echo echapper($demande['salle_nouvelle']); ?></span>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="card">
            <div class="card-header">
                <h2>Raison de la demande</h2>
            </div>
            <div class="card-body">
                <p><?php echo nl2br(echapper($demande['raison'])); ?></p>
            </div>
        </div>
        
        <?php if ($demande['info_supplementaire_demandee']): ?>
        <div class="card">
            <div class="card-header">
                <h2>Informations supplémentaires demandées</h2>
            </div>
            <div class="card-body">
                <p><?php echo nl2br(echapper($demande['info_supplementaire_demandee'])); ?></p>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($demande['alternative_proposee']): ?>
        <div class="card">
            <div class="card-header">
                <h2>Alternative proposée par l'assistante</h2>
            </div>
            <div class="card-body">
                <p><strong>Commentaire:</strong> <?php echo nl2br(echapper($demande['alternative_proposee'])); ?></p>
                <?php if ($demande['date_alternative']): ?>
                    <div class="demande-info" style="margin-top: 16px;">
                        <div class="info-group">
                            <strong>Date:</strong>
                            <span><?php echo echapper(date('d/m/Y', strtotime($demande['date_alternative']))); ?></span>
                        </div>
                        <div class="info-group">
                            <strong>Horaire:</strong>
                            <span><?php echo echapper(date('H:i', strtotime($demande['heure_debut_alternative']))); ?> - <?php echo echapper(date('H:i', strtotime($demande['heure_fin_alternative']))); ?></span>
                        </div>
                        <div class="info-group">
                            <strong>Salle:</strong>
                            <span><?php echo echapper($demande['salle_alternative']); ?></span>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($demande['commentaire_assistante']): ?>
        <div class="card">
            <div class="card-header">
                <h2>Commentaire de l'assistante</h2>
            </div>
            <div class="card-body">
                <p><?php echo nl2br(echapper($demande['commentaire_assistante'])); ?></p>
                <?php if ($demande['date_validation_assistante']): ?>
                    <p style="margin-top: 8px; color: #64748b; font-size: 0.875rem;">
                        <em>Traité le <?php echo echapper(date('d/m/Y à H:i', strtotime($demande['date_validation_assistante']))); ?></em>
                    </p>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($demande['commentaire_directeur']): ?>
        <div class="card">
            <div class="card-header">
                <h2>Commentaire du directeur</h2>
            </div>
            <div class="card-body">
                <p><?php echo nl2br(echapper($demande['commentaire_directeur'])); ?></p>
                <?php if ($demande['date_validation_directeur']): ?>
                    <p style="margin-top: 8px; color: #64748b; font-size: 0.875rem;">
                        <em>Traité le <?php echo echapper(date('d/m/Y à H:i', strtotime($demande['date_validation_directeur']))); ?></em>
                    </p>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($demande['annule']): ?>
        <div class="card" style="border-color: #ef4444;">
            <div class="card-header" style="background: #fef2f2; color: #b91c1c;">
                <h2>Demande annulée</h2>
            </div>
            <div class="card-body">
                <p><strong>Motif d'annulation:</strong> <?php echo nl2br(echapper($demande['motif_annulation'])); ?></p>
                <?php if ($demande['date_annulation']): ?>
                    <p style="margin-top: 8px; color: #64748b; font-size: 0.875rem;">
                        <em>Annulée le <?php echo echapper(date('d/m/Y à H:i', strtotime($demande['date_annulation']))); ?></em>
                    </p>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Actions section for professor, assistant and director -->
        <?php if ($role === 'professeur' && $demande['statut_assistante'] === 'En attente' && !$demande['annule']): ?>
        <div class="card">
            <div class="card-header">
                <h2>Actions</h2>
            </div>
            <div class="card-body">
                <form method="POST" action="" class="form">
                    <input type="hidden" name="csrf_token" value="<?php echo echapper($csrf_token); ?>">
                    <input type="hidden" name="action" value="annuler">
                    
                    <div class="form-group">
                        <label for="motif_annulation">Motif d'annulation de la demande *</label>
                        <textarea id="motif_annulation" name="motif_annulation" required rows="4" maxlength="500"></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-danger">Annuler la demande</button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($role === 'assistante' && $demande['statut_assistante'] === 'En attente' && !$demande['annule']): ?>
        <div class="card">
            <div class="card-header">
                <h2>Actions de l'assistante</h2>
            </div>
            <div class="card-body">
                <!-- Demander des informations -->
                <form method="POST" action="" class="form" style="margin-bottom: 24px; padding-bottom: 24px; border-bottom: 1px solid #e2e8f0;">
                    <input type="hidden" name="csrf_token" value="<?php echo echapper($csrf_token); ?>">
                    <input type="hidden" name="action" value="demander_info">
                    
                    <h3 style="margin-bottom: 16px;">Demander des informations supplémentaires</h3>
                    <div class="form-group">
                        <label for="info_demandee">Précisez les informations requises *</label>
                        <textarea id="info_demandee" name="info_demandee" required rows="3" maxlength="500"></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-info">Demander des informations</button>
                </form>
                
                <!-- Proposer une alternative -->
                <form method="POST" action="" class="form" style="margin-bottom: 24px; padding-bottom: 24px; border-bottom: 1px solid #e2e8f0;">
                    <input type="hidden" name="csrf_token" value="<?php echo echapper($csrf_token); ?>">
                    <input type="hidden" name="action" value="proposer_alternative">
                    
                    <h3 style="margin-bottom: 16px;">Proposer une alternative</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="date_alternative">Date alternative *</label>
                            <input type="date" id="date_alternative" name="date_alternative" required min="<?php echo date('Y-m-d'); ?>">
                        </div>
                        <div class="form-group">
                            <label for="salle_alternative">Salle alternative *</label>
                            <input type="text" id="salle_alternative" name="salle_alternative" required maxlength="50">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="heure_debut_alternative">Heure de début *</label>
                            <input type="time" id="heure_debut_alternative" name="heure_debut_alternative" required>
                        </div>
                        <div class="form-group">
                            <label for="heure_fin_alternative">Heure de fin *</label>
                            <input type="time" id="heure_fin_alternative" name="heure_fin_alternative" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="commentaire_alternative">Commentaire</label>
                        <textarea id="commentaire_alternative" name="commentaire_alternative" rows="3" maxlength="500"></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-info">Proposer une alternative</button>
                </form>
                
                <!-- Valider ou refuser -->
                <form method="POST" action="" class="form">
                    <input type="hidden" name="csrf_token" value="<?php echo echapper($csrf_token); ?>">
                    
                    <h3 style="margin-bottom: 16px;">Validation ou refus</h3>
                    <div class="form-group">
                        <label for="commentaire">Commentaire</label>
                        <textarea id="commentaire" name="commentaire" rows="4" maxlength="500"></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" name="action" value="valider" class="btn btn-success">Valider</button>
                        <button type="submit" name="action" value="refuser" class="btn btn-danger">Refuser</button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($role === 'directeur' && $demande['statut_assistante'] === 'Validé' && $demande['statut_directeur'] === 'En attente'): ?>
        <div class="card">
            <div class="card-header">
                <h2>Validation du directeur</h2>
            </div>
            <div class="card-body">
                <form method="POST" action="" class="form">
                    <input type="hidden" name="csrf_token" value="<?php echo echapper($csrf_token); ?>">
                    
                    <div class="form-group">
                        <label for="commentaire">Commentaire</label>
                        <textarea id="commentaire" name="commentaire" rows="4" maxlength="500"></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" name="action" value="valider" class="btn btn-success">Approuver</button>
                        <button type="submit" name="action" value="refuser" class="btn btn-danger">Refuser</button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>
</main>

<?php include '../includes/footer.php'; ?>
