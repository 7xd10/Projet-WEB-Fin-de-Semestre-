<?php
$page_title = 'Notifications';
require_once '../config/init.php';
protegerPage();

$pdo = getDatabase();
$utilisateur_id = $_SESSION['utilisateur_id'];

// Marquer les notifications comme lues si demandé
if (isset($_GET['marquer_lu']) && isset($_GET['id'])) {
    $notif_id = (int)$_GET['id'];
    $stmt = $pdo->prepare("UPDATE notifications SET lu = 1 WHERE id = ? AND utilisateur_id = ?");
    $stmt->execute([$notif_id, $utilisateur_id]);
    rediriger('/pages/notifications.php');
}

// Marquer toutes comme lues
if (isset($_GET['marquer_tout_lu'])) {
    $stmt = $pdo->prepare("UPDATE notifications SET lu = 1 WHERE utilisateur_id = ?");
    $stmt->execute([$utilisateur_id]);
    rediriger('/pages/notifications.php');
}

// Récupérer les notifications
$stmt = $pdo->prepare("
    SELECT n.*, d.type_demande, d.matiere, d.statut
    FROM notifications n
    JOIN demandes d ON n.demande_id = d.id
    WHERE n.utilisateur_id = ?
    ORDER BY n.date_creation DESC
    LIMIT 50
");
$stmt->execute([$utilisateur_id]);
$notifications_list = $stmt->fetchAll();

include '../includes/header.php';
?>

<main class="container">
    <div class="page-header">
        <h1>Notifications</h1>
        <?php if (count($notifications_list) > 0): ?>
            <a href="?marquer_tout_lu=1" class="btn btn-secondary">Tout marquer comme lu</a>
        <?php endif; ?>
    </div>
    
    <div class="card">
        <?php if (count($notifications_list) > 0): ?>
            <div class="notifications-list">
                <?php foreach ($notifications_list as $notif): ?>
                    <div class="notification-item <?php echo $notif['lu'] ? '' : 'unread'; ?>">
                        <div class="notification-icon">
                            <?php if (!$notif['lu']): ?>
                                <span class="notification-badge"></span>
                            <?php endif; ?>
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M15 17H20L18.5951 15.5951C18.2141 15.2141 18 14.6973 18 14.1585V11C18 8.38757 16.3304 6.16509 14 5.34142V5C14 3.89543 13.1046 3 12 3C10.8954 3 10 3.89543 10 5V5.34142C7.66962 6.16509 6 8.38757 6 11V14.1585C6 14.6973 5.78595 15.2141 5.40493 15.5951L4 17H9M15 17V18C15 19.6569 13.6569 21 12 21C10.3431 21 9 19.6569 9 18V17M15 17H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </div>
                        
                        <div class="notification-content">
                            <p class="notification-message"><?php echo echapper($notif['message']); ?></p>
                            <span class="notification-date"><?php echo echapper(date('d/m/Y à H:i', strtotime($notif['date_creation']))); ?></span>
                        </div>
                        
                        <div class="notification-actions">
                            <a href="/pages/details_demande.php?id=<?php echo echapper($notif['demande_id']); ?>" class="btn btn-sm btn-secondary">Voir</a>
                            <?php if (!$notif['lu']): ?>
                                <a href="?marquer_lu=1&id=<?php echo echapper($notif['id']); ?>" class="btn btn-sm btn-secondary">Marquer lu</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="no-data">Aucune notification.</p>
        <?php endif; ?>
    </div>
</main>

<?php include '../includes/footer.php'; ?>
