<footer class="footer">
        <div class="footer-container">
            <p>&copy; <?php echo date('Y'); ?> Université Euromed de Fès - Tous droits réservés</p>
            <p class="footer-version">Version <?php echo defined('APP_VERSION') ? echapper(APP_VERSION) : '1.0.0'; ?></p>
        </div>
    </footer>
</body>
</html>
