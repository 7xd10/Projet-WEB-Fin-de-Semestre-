<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo isset($page_title) ? echapper($page_title) . ' - ' : ''; ?>UEMF Gestion des Séances</title>
    <!-- Ensure CSS path is correct using BASE_URL -->
    <link rel="stylesheet" href="<?php echo asset('assets/css/style.css'); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <nav class="navbar">
        <div class="navbar-container">
            <div class="navbar-brand">
                <a href="<?php echo BASE_URL; ?>/index.php" style="text-decoration: none; color: inherit; display: flex; align-items: center; gap: 12px;">
                    <!-- Ensure logo path is correct using BASE_URL -->
                    <img src="<?php echo asset('assets/images/uemf_logo.jpg'); ?>" alt="UEMF Logo" style="height: 45px; width: auto; background: white; border-radius: 4px; padding: 2px;" onerror="this.src='<?php echo asset('public/images/uemf-logo.jpg'); ?>'">
                    <div>
                        <h1 style="font-size: 18px; line-height: 1.1; margin: 0; color: white;">Gestion des Séances</h1>
                        <span class="navbar-subtitle" style="font-size: 10px; color: rgba(255,255,255,0.8);">EUROMED UNIVERSITY OF FES</span>
                    </div>
                </a>
            </div>
            
            <ul class="navbar-menu">
                <li><a href="<?php echo BASE_URL; ?>/index.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : ''; ?>">Tableau de bord</a></li>
                
                <?php if (isset($_SESSION['user_role'])): ?>
                    <?php if (strtolower($_SESSION['user_role']) === 'professeur'): ?>
                        <li><a href="<?php echo BASE_URL; ?>/nouvelle_demande.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'nouvelle_demande.php' ? 'active' : ''; ?>">Nouvelle demande</a></li>
                    <?php endif; ?>
                    
                    <!-- Simplified paths to root as per user file structure -->
                    <li><a href="<?php echo BASE_URL; ?>/demandes.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'demandes.php' ? 'active' : ''; ?>">Mes demandes</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/calendrier.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'calendrier.php' ? 'active' : ''; ?>">Calendrier</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/notifications.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'notifications.php' ? 'active' : ''; ?>">Notifications</a></li>
                        
                        <?php 
                        if (isset($_SESSION['utilisateur_id'])):
                            $pdo = getDatabase();
                            $stmt = $pdo->prepare("SELECT COUNT(*) as nb FROM notifications WHERE utilisateur_id = ? AND lu = 0");
                            $stmt->execute([$_SESSION['utilisateur_id']]);
                            $notif = $stmt->fetch();
                            if ($notif && $notif['nb'] > 0):
                        ?>
                            <span class="badge badge-error"><?php echo (int)$notif['nb']; ?></span>
                        <?php 
                            endif;
                        endif; 
                        ?>
                    </a></li>
                    
                    <!-- Restricted access to Directeur ONLY as requested -->
                    <?php if (isset($_SESSION['user_role']) && strtolower($_SESSION['user_role']) === 'directeur'): ?>
                        <li><a href="<?php echo BASE_URL; ?>/pages/gestion_utilisateurs.php" class="<?php echo strpos($_SERVER['PHP_SELF'], 'gestion_utilisateurs.php') !== false ? 'active' : ''; ?>">Gestion utilisateurs</a></li>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['user_role']) && (strtolower($_SESSION['user_role']) === 'directeur' || strtolower($_SESSION['user_role']) === 'assistante')): ?>
                        <li><a href="<?php echo BASE_URL; ?>/statistiques.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'statistiques.php' ? 'active' : ''; ?>">Statistiques</a></li>
                    <?php endif; ?>
                <?php endif; ?>
                <li><a href="<?php echo BASE_URL; ?>/profil.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'profil.php' ? 'active' : ''; ?>">Profil</a></li>
            </ul>
            
            <?php if (isset($_SESSION['utilisateur_id'])): ?>
            <div class="navbar-user">
                <div class="user-info">
                    <span class="user-name"><?php echo echapper($_SESSION['utilisateur_prenom'] . ' ' . $_SESSION['utilisateur_nom']); ?></span>
                    <span class="user-role"><?php echo echapper(ucfirst($_SESSION['utilisateur_role'])); ?></span>
                </div>
                <a href="<?php echo BASE_URL; ?>/logout.php" class="btn btn-secondary btn-sm">Déconnexion</a>
            </div>
            <?php endif; ?>
        </div>
    </nav>
