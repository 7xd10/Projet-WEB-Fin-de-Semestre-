<?php
require_once 'config.php';

$error = '';
$message = '';
$token = $_GET['token'] ?? '';

// Vérifier si le token est valide
if (empty($token)) {
    $error = "Token manquant";
} else {
    $stmt = $pdo->prepare("SELECT id, nom, prenom, email FROM utilisateurs 
                          WHERE remember_token = ? 
                          AND remember_token_expiration > NOW() 
                          AND actif = 1");
    $stmt->execute([$token]);
    $user = $stmt->fetch();

    if (!$user) {
        $error = "Ce lien est invalide ou a expiré";
    }
}

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$error) {
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';

    if (empty($password) || empty($confirm)) {
        $error = "Veuillez remplir tous les champs";
    } elseif (strlen($password) < 8) {
        $error = "Le mot de passe doit contenir au moins 8 caractères";
    } elseif ($password !== $confirm) {
        $error = "Les mots de passe ne correspondent pas";
    } else {
        // Mettre à jour le mot de passe
        $hash = md5($password); // Utilisez password_hash() pour plus de sécurité
        
        $stmt = $pdo->prepare("UPDATE utilisateurs 
                             SET mot_de_passe = ?, 
                                 remember_token = NULL, 
                                 remember_token_expiration = NULL,
                                 tentatives_connexion = 0,
                                 date_blocage = NULL
                             WHERE id = ?");
        
        if ($stmt->execute([$hash, $user['id']])) {
            // Logger l'activité
            if (function_exists('logActivity')) {
                logActivity($user['id'], 'MOT_DE_PASSE_CHANGE_VIA_RESET', 'utilisateurs', $user['id']);
            }
            
            $message = "Mot de passe changé avec succès !";
        } else {
            $error = "Erreur lors du changement de mot de passe";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Nouveau mot de passe</title>
<style>
body {
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    margin: 0;
    padding: 20px;
}
.container {
    background: white;
    padding: 40px;
    border-radius: 12px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.2);
    width: 100%;
    max-width: 420px;
}
h1 {
    text-align: center;
    margin-bottom: 10px;
    color: #333;
    font-size: 28px;
}
.subtitle {
    text-align: center;
    color: #666;
    margin-bottom: 30px;
    font-size: 14px;
}
.user-info {
    background: #f5f5f5;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 25px;
    text-align: center;
}
.user-info strong {
    color: #667eea;
}
input {
    width: 100%;
    padding: 14px;
    margin: 10px 0;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    box-sizing: border-box;
    font-size: 15px;
    transition: border 0.3s;
}
input:focus {
    outline: none;
    border-color: #667eea;
}
button {
    width: 100%;
    padding: 14px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
    font-weight: 500;
    margin-top: 10px;
    transition: transform 0.2s, box-shadow 0.2s;
}
button:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
}
button:active {
    transform: translateY(0);
}
.error {
    background: #ffebee;
    color: #c62828;
    padding: 15px;
    border-radius: 8px;
    margin: 15px 0;
    text-align: center;
    border-left: 4px solid #c62828;
}
.success {
    background: #e8f5e9;
    color: #2e7d32;
    padding: 15px;
    border-radius: 8px;
    margin: 15px 0;
    text-align: center;
    border-left: 4px solid #2e7d32;
}
.back-link {
    text-align: center;
    margin-top: 25px;
}
.back-link a {
    color: #667eea;
    text-decoration: none;
    font-size: 14px;
    transition: color 0.3s;
    display: inline-block;
    padding: 10px 20px;
    background: #f5f5f5;
    border-radius: 6px;
}
.back-link a:hover {
    color: #764ba2;
    background: #e8f5e9;
}
.icon {
    text-align: center;
    font-size: 48px;
    margin-bottom: 20px;
}
.password-hint {
    font-size: 12px;
    color: #666;
    margin-top: 5px;
}
</style>
</head>
<body>

<div class="container">
    <div class="icon">🔑</div>
    <h1>Nouveau mot de passe</h1>

    <?php if ($error && empty($user)): ?>
        <div class="error">❌ <?= htmlspecialchars($error) ?></div>
        <div class="back-link">
            <a href="mot_de_passe_oublie.php">← Demander un nouveau lien</a>
        </div>
    <?php elseif ($message): ?>
        <div class="success">✅ <?= htmlspecialchars($message) ?></div>
        <div class="back-link">
            <a href="login.php">Se connecter →</a>
        </div>
    <?php else: ?>
        <p class="subtitle">Créez un nouveau mot de passe sécurisé</p>
        
        <div class="user-info">
            Compte : <strong><?= htmlspecialchars($user['nom'] . ' ' . $user['prenom']) ?></strong><br>
            <small><?= htmlspecialchars($user['email']) ?></small>
        </div>

        <?php if ($error): ?>
            <div class="error">❌ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="post">
            <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
            
            <input 
                type="password" 
                name="password" 
                placeholder="Nouveau mot de passe" 
                required
                minlength="8"
                autocomplete="new-password"
            >
            <div class="password-hint">Au moins 8 caractères</div>
            
            <input 
                type="password" 
                name="confirm" 
                placeholder="Confirmer le mot de passe" 
                required
                minlength="8"
                autocomplete="new-password"
            >
            
            <button type="submit">✓ Changer mon mot de passe</button>
        </form>

        <div class="back-link">
            <a href="login.php">← Annuler</a>
        </div>
    <?php endif; ?>
</div>

<script>
// Validation en temps réel
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    if (!form) return;
    
    const password = document.querySelector('input[name="password"]');
    const confirm = document.querySelector('input[name="confirm"]');
    
    confirm.addEventListener('input', function() {
        if (this.value && password.value !== this.value) {
            this.setCustomValidity('Les mots de passe ne correspondent pas');
        } else {
            this.setCustomValidity('');
        }
    });
});
</script>

</body>
</html>