<?php
require_once 'config.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $validation_email = validerEntree($email, 'email');
    if (!$validation_email['valide']) {
        $erreur = $validation_email['message'];
    }
    elseif ($password !== $confirm_password) {
        $erreur = "Les mots de passe ne correspondent pas";
    } else {
        $verification_mdp = verifierForceMotDePasse($password);
        if (!$verification_mdp['valide']) {
            $erreur = "Mot de passe trop faible:<br>- " . implode("<br>- ", $verification_mdp['erreurs']);
        } else {
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription - Gestion des Séances</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .password-strength {
            margin-top: 8px;
            padding: 8px;
            border-radius: 4px;
            font-size: 13px;
        }
        .password-strength.weak {
            background: #fee;
            color: #c00;
        }
        .password-strength.medium {
            background: #ffeaa7;
            color: #d63031;
        }
        .password-strength.strong {
            background: #d4edda;
            color: #155724;
        }
        .password-requirements {
            margin-top: 8px;
            font-size: 12px;
            color: #666;
        }
        .password-requirements ul {
            margin: 4px 0;
            padding-left: 20px;
        }
        .password-requirements li {
            margin: 2px 0;
        }
        .password-requirements li.met {
            color: #28a745;
        }
    </style>
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <h1>Créer un compte</h1>
                <p>Rejoignez la plateforme de gestion des séances</p>
            </div>

            <?php if ($succes): ?>
                <div class="alert alert-success">
                    <strong>Succès!</strong> <?php echo $succes; ?>
                    <br><a href="login.php" style="color: #155724; text-decoration: underline;">Se connecter</a>
                </div>
            <?php endif; ?>

            <?php if ($erreur): ?>
                <div class="alert alert-error">
                    <strong>Erreur!</strong> <?php echo $erreur; ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="login-form" id="inscriptionForm">
                <div class="form-row">
                    <div class="form-group">
                        <label for="nom">Nom *</label>
                        <input type="text" id="nom" name="nom" required value="<?php echo isset($_POST['nom']) ? securiser($_POST['nom']) : ''; ?>">
                    </div>
                    <div class="form-group">
                        <label for="prenom">Prénom *</label>
                        <input type="text" id="prenom" name="prenom" required value="<?php echo isset($_POST['prenom']) ? securiser($_POST['prenom']) : ''; ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label for="email">Email *</label>
                    <input type="email" id="email" name="email" required value="<?php echo isset($_POST['email']) ? securiser($_POST['email']) : ''; ?>">
                </div>

                <div class="form-group">
                    <label for="password">Mot de passe *</label>
                    <input type="password" id="password" name="password" required oninput="checkPasswordStrength()">
                    <div id="password-strength" class="password-strength" style="display: none;"></div>
                    <div class="password-requirements">
                        <strong>Le mot de passe doit contenir:</strong>
                        <ul id="requirements">
                            <li id="req-length">Au moins 8 caractères</li>
                            <li id="req-upper">Au moins une majuscule</li>
                            <li id="req-lower">Au moins une minuscule</li>
                            <li id="req-number">Au moins un chiffre</li>
                            <li id="req-special">Au moins un caractère spécial (!@#$%^&*...)</li>
                        </ul>
                    </div>
                </div>

                <div class="form-group">
                    <label for="confirm_password">Confirmer le mot de passe *</label>
                    <input type="password" id="confirm_password" name="confirm_password" required>
                </div>

                <div class="form-group">
                    <label for="role">Rôle *</label>
                    <select id="role" name="role" required>
                        <option value="">-- Sélectionner un rôle --</option>
                        <option value="Professeur" <?php echo (isset($_POST['role']) && $_POST['role'] === 'Professeur') ? 'selected' : ''; ?>>Professeur</option>
                        <option value="Assistante" <?php echo (isset($_POST['role']) && $_POST['role'] === 'Assistante') ? 'selected' : ''; ?>>Assistante</option>
                        <option value="Directeur" <?php echo (isset($_POST['role']) && $_POST['role'] === 'Directeur') ? 'selected' : ''; ?>>Directeur</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary btn-block">S'inscrire</button>
            </form>

            <div class="login-footer">
                <p>Vous avez déjà un compte ? <a href="login.php">Se connecter</a></p>
            </div>
        </div>
    </div>

    <script>
        function checkPasswordStrength() {
            const password = document.getElementById('password').value;
            const strengthDiv = document.getElementById('password-strength');
            
            if (password.length === 0) {
                strengthDiv.style.display = 'none';
                return;
            }
            
            strengthDiv.style.display = 'block';
            
            let strength = 0;
            const requirements = {
                length: password.length >= 8,
                upper: /[A-Z]/.test(password),
                lower: /[a-z]/.test(password),
                number: /[0-9]/.test(password),
                special: /[!@#$%^&*(),.?":{}|<>]/.test(password)
            };
            
            // Mettre à jour l'affichage des exigences
            document.getElementById('req-length').classList.toggle('met', requirements.length);
            document.getElementById('req-upper').classList.toggle('met', requirements.upper);
            document.getElementById('req-lower').classList.toggle('met', requirements.lower);
            document.getElementById('req-number').classList.toggle('met', requirements.number);
            document.getElementById('req-special').classList.toggle('met', requirements.special);
            
            strength = Object.values(requirements).filter(Boolean).length;
            
            if (strength <= 2) {
                strengthDiv.className = 'password-strength weak';
                strengthDiv.textContent = 'Mot de passe faible';
            } else if (strength <= 4) {
                strengthDiv.className = 'password-strength medium';
                strengthDiv.textContent = 'Mot de passe moyen';
            } else {
                strengthDiv.className = 'password-strength strong';
                strengthDiv.textContent = 'Mot de passe fort';
            }
        }
        
        document.getElementById('inscriptionForm').addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Les mots de passe ne correspondent pas');
                return false;
            }
        });
    </script>
</body>
</html>
