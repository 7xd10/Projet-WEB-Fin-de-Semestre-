<?php 
require_once 'config.php';
verifierConnexion();

if ($_SESSION['user_role'] !== 'Professeur') {
    header('Location: index.php');
    exit;
}

$succes = '';
$erreur = '';
$id_seance_selectionnee = null;

$seances_planifiees = [];
try {
    $stmt = $pdo->prepare("
        SELECT id, date_seance, heure_debut, heure_fin, salle, matiere, groupe 
        FROM emploi_temps 
        WHERE professeur_id = ? 
        AND date_seance >= CURDATE()
        ORDER BY date_seance, heure_debut
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $seances_planifiees = $stmt->fetchAll();
} catch (PDOException $e) {
    $erreur = "Erreur lors du chargement des séances : " . $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type_demande = $_POST['type_demande'] ?? 'modification';
    $seance_id = intval($_POST['seance_id'] ?? 0);
    $is_new_session = ($type_demande === 'ajout');
    $matiere_new = trim($_POST['matiere_new'] ?? '');
    $groupe_new = trim($_POST['groupe_new'] ?? '');
    $date_originale_new = trim($_POST['date_originale_new'] ?? '');
    $heure_originale_new = trim($_POST['heure_originale_new'] ?? '');
    
    $nouvelle_date = trim($_POST['nouvelle_date'] ?? '');
    $nouvelle_heure_debut = trim($_POST['nouvelle_heure_debut'] ?? '');
    $nouvelle_heure_fin = trim($_POST['nouvelle_heure_fin'] ?? '');
    $nouvelle_salle = trim($_POST['nouvelle_salle'] ?? '');
    $motif = trim($_POST['motif'] ?? '');
    $est_brouillon = isset($_POST['enregistrer_brouillon']) ? 1 : 0;
    
    // Validation du motif (minimum 20 caractères)
    if (!$est_brouillon && strlen($motif) < 20) {
        $erreur = "Le motif doit contenir au minimum 20 caractères.";
    } elseif (!$is_new_session && $seance_id <= 0) {
        $erreur = "Veuillez sélectionner une séance à modifier ou annuler.";
    } elseif ($is_new_session && (empty($matiere_new) || empty($groupe_new) || empty($nouvelle_date))) {
        $erreur = "Veuillez remplir les informations de la nouvelle séance.";
    } elseif (!$est_brouillon && $type_demande === 'modification' && (empty($nouvelle_date) || empty($nouvelle_heure_debut) || empty($nouvelle_heure_fin) || empty($nouvelle_salle))) {
        $erreur = "Veuillez remplir tous les champs obligatoires pour une modification.";
    } else {
        // Récupérer les informations de la séance originale ou préparer pour nouvelle
        if (!$is_new_session) {
            $stmt = $pdo->prepare("SELECT * FROM emploi_temps WHERE id = ? AND professeur_id = ?");
            $stmt->execute([$seance_id, $_SESSION['user_id']]);
            $seance_originale = $stmt->fetch();
        } else {
            // Dummy original session data for "ajout"
            $seance_originale = [
                'date_seance' => $date_originale_new ?: date('Y-m-d'),
                'heure_debut' => $heure_originale_new ?: '00:00:00',
                'heure_fin' => $heure_originale_new ?: '00:00:00',
                'salle' => 'A définir',
                'matiere' => $matiere_new,
                'groupe' => $groupe_new
            ];
        }
        
        if (!$seance_originale && !$is_new_session) {
            $erreur = "Séance non trouvée.";
        } else {
            $conflit = false;
            if (!$est_brouillon && $type_demande === 'modification' && !empty($nouvelle_date) && !empty($nouvelle_heure_debut) && !empty($nouvelle_heure_fin)) {
                // Vérifier si la salle est disponible
                $stmt = $pdo->prepare("
                    SELECT COUNT(*) as nb FROM emploi_temps 
                    WHERE date_seance = ? 
                    AND salle = ? 
                    AND id != ?
                    AND (
                        (heure_debut <= ? AND heure_fin > ?) OR
                        (heure_debut < ? AND heure_fin >= ?) OR
                        (heure_debut >= ? AND heure_fin <= ?)
                    )
                ");
                $stmt->execute([
                    $nouvelle_date, $nouvelle_salle, $seance_id,
                    $nouvelle_heure_debut, $nouvelle_heure_debut,
                    $nouvelle_heure_fin, $nouvelle_heure_fin,
                    $nouvelle_heure_debut, $nouvelle_heure_fin
                ]);
                $resultat = $stmt->fetch();
                if ($resultat['nb'] > 0) {
                    $erreur = "CONFLIT : La salle $nouvelle_salle est déjà occupée à cet horaire.";
                    $conflit = true;
                }
                
                // Vérifier si le professeur est déjà en cours
                if (!$conflit) {
                    $stmt = $pdo->prepare("
                        SELECT COUNT(*) as nb FROM emploi_temps 
                        WHERE date_seance = ? 
                        AND professeur_id = ? 
                        AND id != ?
                        AND (
                            (heure_debut <= ? AND heure_fin > ?) OR
                            (heure_debut < ? AND heure_fin >= ?) OR
                            (heure_debut >= ? AND heure_fin <= ?)
                        )
                    ");
                    $stmt->execute([
                        $nouvelle_date, $_SESSION['user_id'], $seance_id,
                        $nouvelle_heure_debut, $nouvelle_heure_debut,
                        $nouvelle_heure_fin, $nouvelle_heure_fin,
                        $nouvelle_heure_debut, $nouvelle_heure_fin
                    ]);
                    $resultat = $stmt->fetch();
                    if ($resultat['nb'] > 0) {
                        $erreur = "CONFLIT : Vous avez déjà une séance planifiée à cet horaire.";
                        $conflit = true;
                    }
                }
            }
            
            if (!$conflit) {
                $piece_jointe = null;
                if (isset($_FILES['piece_jointe']) && $_FILES['piece_jointe']['error'] === UPLOAD_ERR_OK) {
                    $upload_result = validerUpload($_FILES['piece_jointe']);
                    if ($upload_result['success']) {
                        $dossier_upload = __DIR__ . '/uploads/';
                        if (!file_exists($dossier_upload)) {
                            mkdir($dossier_upload, 0755, true);
                        }
                        $chemin_complet = $dossier_upload . $upload_result['nom_unique'];
                        if (move_uploaded_file($_FILES['piece_jointe']['tmp_name'], $chemin_complet)) {
                            $piece_jointe = $upload_result['nom_unique'];
                        }
                    } else {
                        $erreur = $upload_result['message'];
                    }
                }
                
                if (empty($erreur)) {
                    $stmt = $pdo->prepare("
                        INSERT INTO demandes (
                            professeur_id, type_demande, 
                            date_seance_originale, heure_debut_originale, heure_fin_originale, salle_originale, 
                            matiere, niveau,
                            date_seance_nouvelle, heure_debut_nouvelle, heure_fin_nouvelle, salle_nouvelle,
                            raison, piece_jointe, est_brouillon, disponibilite_verifiee
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ");
                    
                    if ($stmt->execute([
                        $_SESSION['user_id'],
                        $type_demande === 'ajout' ? 'modification' : $type_demande, // map 'ajout' to 'modification' in DB
                        $seance_originale['date_seance'],
                        $seance_originale['heure_debut'],
                        $seance_originale['heure_fin'],
                        $seance_originale['salle'],
                        $seance_originale['matiere'] ?? 'Non spécifiée',
                        $seance_originale['groupe'] ?? 'Non spécifié',
                        ($type_demande === 'modification' || $type_demande === 'ajout') ? $nouvelle_date : null,
                        ($type_demande === 'modification' || $type_demande === 'ajout') ? $nouvelle_heure_debut : null,
                        ($type_demande === 'modification' || $type_demande === 'ajout') ? $nouvelle_heure_fin : null,
                        ($type_demande === 'modification' || $type_demande === 'ajout') ? $nouvelle_salle : null,
                        $motif,
                        $piece_jointe,
                        $est_brouillon,
                        $est_brouillon ? 0 : 1
                    ])) {
                        $demande_id = $pdo->lastInsertId();
                        
                        if (!$est_brouillon) {
                            $stmt = $pdo->prepare("SELECT id, email FROM utilisateurs WHERE role = 'Assistante' AND actif = 1");
                            $stmt->execute();
                            $assistantes = $stmt->fetchAll();
                            
                            foreach ($assistantes as $ass) {
                                $type_text = $type_demande === 'modification' ? 'modification' : 'annulation';
                                $msg = "Nouvelle demande de $type_text de séance (#" . $demande_id . ") de " . 
                                       $_SESSION['user_prenom'] . " " . $_SESSION['user_nom'];
                                $stmt = $pdo->prepare("INSERT INTO notifications (utilisateur_id, demande_id, message) VALUES (?, ?, ?)");
                                $stmt->execute([$ass['id'], $demande_id, $msg]);
                            }
                            
                            logActivity($_SESSION['user_id'], 'CREATION_DEMANDE', 'demandes', $demande_id, [
                                'type' => $type_demande,
                                'seance_originale' => $seance_id
                            ]);
                            
                            $succes = "Votre demande a été soumise avec succès et est en attente de validation.";
                        } else {
                            $succes = "Votre demande a été enregistrée comme brouillon. Vous pouvez la modifier avant de la soumettre.";
                        }
                    } else {
                        $erreur = "Une erreur est survenue lors de l'enregistrement de la demande.";
                    }
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nouvelle demande - Gestion des Séances</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .type-selector {
            display: flex;
            gap: 16px;
            margin-bottom: 24px;
        }
        .type-option {
            flex: 1;
            padding: 20px;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
        }
        .type-option:hover {
            border-color: #667eea;
            background: #f8f9ff;
        }
        .type-option.selected {
            border-color: #667eea;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .type-option input[type="radio"] {
            display: none;
        }
        .type-option-icon {
            font-size: 32px;
            margin-bottom: 8px;
        }
        .type-option-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 4px;
        }
        .type-option-desc {
            font-size: 14px;
            opacity: 0.8;
        }
        .nouvelle-seance-fields {
            display: none;
        }
        .nouvelle-seance-fields.active {
            display: block;
        }
        #ajout_fields {
            display: none;
            background: #f8fafc;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            border: 1px dashed #cbd5e1;
        }
    </style>
</head>
<body>
   <?php include 'includes/header.php'; ?>
    <div class="container">
        <div class="page-header">
            <h1>Nouvelle demande</h1>
            <p>Choisissez le type de demande et remplissez le formulaire</p>
        </div>

        <?php if ($succes): ?>
            <div class="alert alert-success">
                <strong>Succès!</strong> <?php echo securiser($succes); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($erreur): ?>
            <div class="alert alert-error">
                <strong>Erreur!</strong> <?php echo securiser($erreur); ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <form method="POST" enctype="multipart/form-data" class="form" id="demandeForm">
                <!-- Ajout du sélecteur de type de demande -->
                <div class="form-section">
                    <h3>Type de demande</h3>
                    <div class="type-selector">
                        <label class="type-option selected" for="type_modification">
                            <input type="radio" id="type_modification" name="type_demande" value="modification" checked onchange="updateTypeSelection()">
                            <div class="type-option-icon">🔄</div>
                            <div class="type-option-title">Modifier</div>
                            <div class="type-option-desc">Changer une séance existante</div>
                        </label>
                        <label class="type-option" for="type_ajout">
                            <input type="radio" id="type_ajout" name="type_demande" value="ajout" onchange="updateTypeSelection()">
                            <div class="type-option-icon">➕</div>
                            <div class="type-option-title">Ajouter</div>
                            <div class="type-option-desc">Proposer une nouvelle séance</div>
                        </label>
                        <label class="type-option" for="type_annulation">
                            <input type="radio" id="type_annulation" name="type_demande" value="annulation" onchange="updateTypeSelection()">
                            <div class="type-option-icon">❌</div>
                            <div class="type-option-title">Annuler</div>
                            <div class="type-option-desc">Supprimer une séance</div>
                        </label>
                    </div>
                </div>

                <!-- Ajout des champs pour ajouter une nouvelle séance -->
                <div id="ajout_fields" style="display: none; background: #f8fafc; padding: 20px; border-radius: 12px; margin-bottom: 24px; border: 1px dashed #cbd5e1;">
                    <h3>Informations de la nouvelle séance</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Matière *</label>
                            <input type="text" name="matiere_new" placeholder="Ex: Mathématiques">
                        </div>
                        <div class="form-group">
                            <label>Groupe / Niveau *</label>
                            <input type="text" name="groupe_new" placeholder="Ex: L1 Info G1">
                        </div>
                    </div>
                </div>

                <!-- Sélection de la séance (hidden when adding new) -->
                <div class="form-section" id="selection_seance_section">
                    <h3>Sélection de la séance</h3>
                    <div class="form-group">
                        <label for="recherche_date">Rechercher par date (optionnel)</label>
                        <input type="date" id="recherche_date" class="form-control" onchange="filtrerSeances()">
                    </div>
                    <div class="form-group">
                        <label for="seance_id">Séance planifiée *</label>
                        <select id="seance_id" name="seance_id" class="form-control" required onchange="remplirSeanceOriginale()">
                            <option value="">-- Sélectionnez une séance --</option>
                            <?php foreach ($seances_planifiees as $seance): ?>
                                <option value="<?php echo $seance['id']; ?>" 
                                        data-date="<?php echo $seance['date_seance']; ?>"
                                        data-heure-debut="<?php echo $seance['heure_debut']; ?>"
                                        data-heure-fin="<?php echo $seance['heure_fin']; ?>"
                                        data-salle="<?php echo securiser($seance['salle']); ?>"
                                        data-matiere="<?php echo securiser($seance['matiere'] ?? ''); ?>"
                                        data-groupe="<?php echo securiser($seance['groupe'] ?? ''); ?>">
                                    <?php 
                                        echo date('d/m/Y', strtotime($seance['date_seance'])) . ' - ';
                                        echo $seance['heure_debut'] . ' à ' . $seance['heure_fin'] . ' - ';
                                        echo securiser($seance['matiere'] ?? 'Matière non spécifiée') . ' - ';
                                        echo 'Salle ' . securiser($seance['salle']);
                                    ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div id="info_seance_originale" style="display: none; background: #e3f2fd; padding: 15px; border-radius: 6px; margin-top: 15px;">
                        <h4 style="margin-top: 0; color: #1976d2;">Informations de la séance actuelle</h4>
                        <p><strong>Date:</strong> <span id="info_date"></span></p>
                        <p><strong>Horaire:</strong> <span id="info_horaire"></span></p>
                        <p><strong>Salle:</strong> <span id="info_salle"></span></p>
                        <p><strong>Matière:</strong> <span id="info_matiere"></span></p>
                        <p><strong>Groupe:</strong> <span id="info_groupe"></span></p>
                    </div>
                </div>

                <!-- Section nouvelle séance visible uniquement pour les modifications -->
                <div class="form-section nouvelle-seance-fields active" id="nouvelle_seance_section">
                    <h3>Nouvelle séance souhaitée</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="nouvelle_date">Nouvelle date *</label>
                            <input type="date" id="nouvelle_date" name="nouvelle_date" class="form-control" 
                                   min="<?php echo date('Y-m-d'); ?>" onchange="verifierDisponibilite()">
                        </div>
                        <div class="form-group">
                            <label for="nouvelle_heure_debut">Heure de début *</label>
                            <input type="time" id="nouvelle_heure_debut" name="nouvelle_heure_debut" 
                                   class="form-control" onchange="verifierDisponibilite()">
                        </div>
                        <div class="form-group">
                            <label for="nouvelle_heure_fin">Heure de fin *</label>
                            <input type="time" id="nouvelle_heure_fin" name="nouvelle_heure_fin" 
                                   class="form-control" onchange="verifierDisponibilite()">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="nouvelle_salle">Nouvelle salle *</label>
                        <input type="text" id="nouvelle_salle" name="nouvelle_salle" class="form-control" 
                               placeholder="Ex: B205" onblur="verifierDisponibilite()">
                    </div>
                    
                    <div id="conflit_message" style="display: none;"></div>
                </div>

                <!-- Motif -->
                <div class="form-group">
                    <label for="motif">Motif détaillé de la demande * (minimum 20 caractères)</label>
                    <textarea id="motif" name="motif" rows="5" class="form-control" 
                              placeholder="Expliquez de manière détaillée la raison de votre demande..." 
                              oninput="compterCaracteres()" required></textarea>
                    <div id="char_counter" class="char-counter">0 / 20 caractères minimum</div>
                </div>

                <!-- Zone d'upload de pièce jointe -->
                <div class="upload-zone" onclick="document.getElementById('piece_jointe').click()">
                    <div class="upload-icon">📎</div>
                    <div class="upload-text">Cliquez pour ajouter une pièce jointe</div>
                    <div class="upload-info">Certificat médical, convocation, etc. (PDF, JPG, PNG - Max 5 Mo)</div>
                    <input type="file" id="piece_jointe" name="piece_jointe" 
                           accept=".pdf,.jpg,.jpeg,.png" style="display: none;" onchange="afficherNomFichier()">
                    <div id="nom_fichier" style="margin-top: 10px; color: #2e7d32; font-weight: 600;"></div>
                </div>

                <!-- Boutons d'action -->
                <div class="form-actions">
                    <a href="index.php" class="btn btn-secondary">Annuler</a>
                    <button type="submit" name="enregistrer_brouillon" class="btn btn-draft">
                        Enregistrer comme brouillon
                    </button>
                    <button type="submit" name="soumettre_demande" class="btn btn-primary" id="btn_soumettre">
                        Soumettre la demande
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function updateTypeSelection() {
            const types = document.querySelectorAll('input[name="type_demande"]');
            let selectedType = 'modification';
            
            types.forEach(t => {
                const label = t.closest('.type-option');
                if (t.checked) {
                    label.classList.add('selected');
                    selectedType = t.value;
                } else {
                    label.classList.remove('selected');
                }
            });
            
            const nouvelleSeanceSection = document.getElementById('nouvelle_seance_section');
            const selectionSeanceSection = document.getElementById('selection_seance_section');
            const ajoutFields = document.getElementById('ajout_fields');
            const seanceSelect = document.getElementById('seance_id');
            
            if (selectedType === 'annulation') {
                nouvelleSeanceSection.classList.remove('active');
                selectionSeanceSection.style.display = 'block';
                ajoutFields.style.display = 'none';
                seanceSelect.required = true;
            } else if (selectedType === 'ajout') {
                nouvelleSeanceSection.classList.add('active');
                selectionSeanceSection.style.display = 'none';
                ajoutFields.style.display = 'block';
                seanceSelect.required = false;
            } else {
                nouvelleSeanceSection.classList.add('active');
                selectionSeanceSection.style.display = 'block';
                ajoutFields.style.display = 'none';
                seanceSelect.required = true;
            }
        }
        
        function filtrerSeances() {
            const dateRecherche = document.getElementById('recherche_date').value;
            const selectSeance = document.getElementById('seance_id');
            const options = selectSeance.options;
            
            for (let i = 1; i < options.length; i++) {
                const optionDate = options[i].getAttribute('data-date');
                if (dateRecherche === '' || optionDate === dateRecherche) {
                    options[i].style.display = '';
                } else {
                    options[i].style.display = 'none';
                }
            }
        }
        
        function remplirSeanceOriginale() {
            const select = document.getElementById('seance_id');
            const option = select.options[select.selectedIndex];
            
            if (option.value) {
                const date = option.getAttribute('data-date');
                const heureDebut = option.getAttribute('data-heure-debut');
                const heureFin = option.getAttribute('data-heure-fin');
                const salle = option.getAttribute('data-salle');
                const matiere = option.getAttribute('data-matiere');
                const groupe = option.getAttribute('data-groupe');
                
                document.getElementById('info_date').textContent = new Date(date).toLocaleDateString('fr-FR');
                document.getElementById('info_horaire').textContent = heureDebut + ' - ' + heureFin;
                document.getElementById('info_salle').textContent = salle;
                document.getElementById('info_matiere').textContent = matiere;
                document.getElementById('info_groupe').textContent = groupe;
                document.getElementById('info_seance_originale').style.display = 'block';
            } else {
                document.getElementById('info_seance_originale').style.display = 'none';
            }
        }
        
        function verifierDisponibilite() {
            // Fonction pour vérifier la disponibilité (peut être améliorée avec AJAX)
            const conflitDiv = document.getElementById('conflit_message');
            conflitDiv.style.display = 'none';
        }
        
        function compterCaracteres() {
            const motif = document.getElementById('motif').value;
            const counter = document.getElementById('char_counter');
            const length = motif.length;
            
            counter.textContent = length + ' / 20 caractères minimum';
            
            if (length >= 20) {
                counter.style.color = '#2e7d32';
            } else {
                counter.style.color = '#d32f2f';
            }
        }
        
        function afficherNomFichier() {
            const input = document.getElementById('piece_jointe');
            const nomFichier = document.getElementById('nom_fichier');
            
            if (input.files.length > 0) {
                nomFichier.textContent = 'Fichier sélectionné: ' + input.files[0].name;
            } else {
                nomFichier.textContent = '';
            }
        }
    </script>
</body>
</html>
